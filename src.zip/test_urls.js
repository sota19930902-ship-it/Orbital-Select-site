const https = require('https');

const extraUrls = [
  'https://www.air-r.jp/products/list.php?name=Wism',
  'https://www.air-r.jp/products/list.php?name=Luma',
  'https://beaubelle.shop/?s=RECONTE',
  'https://lavita-shop.jp/?s=PH5',
  'https://www.receno.com/search/?keyword=AGRA',
  'https://flymee.jp/member/search/index/search_word:sofa/',
];

function checkUrl(urlStr) {
  return new Promise((resolve) => {
    try {
      const req = https.get(urlStr, { headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' } }, (res) => {
        resolve({ url: urlStr, status: res.statusCode, location: res.headers.location || null });
      });
      req.on('error', (err) => {
        resolve({ url: urlStr, status: 'ERROR: ' + err.message, location: null });
      });
      req.setTimeout(5000, () => {
        req.destroy();
        resolve({ url: urlStr, status: 'TIMEOUT', location: null });
      });
    } catch (e) {
      resolve({ url: urlStr, status: 'EXC: ' + e.message, location: null });
    }
  });
}

async function run() {
  console.log('Testing Extra URLs...');
  for (const u of extraUrls) {
    const res = await checkUrl(u);
    console.log(`${res.url} => Status: ${res.status} (Redirect: ${res.location})`);
  }
}

run();
