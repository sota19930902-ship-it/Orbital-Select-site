const https = require('https');

const candidates = [
  'https://images.unsplash.com/photo-1517991104123-1d56a6e81ed9?auto=format&fit=crop&w=1000&q=80',
  'https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?auto=format&fit=crop&w=1000&q=80',
  'https://images.unsplash.com/photo-1524484485831-a92ffc0de03f?auto=format&fit=crop&w=1000&q=80',
];

function checkUrl(urlStr) {
  return new Promise((resolve) => {
    try {
      const req = https.get(urlStr, { headers: { 'User-Agent': 'Mozilla/5.0' } }, (res) => {
        resolve({ url: urlStr, status: res.statusCode });
      });
      req.on('error', (err) => {
        resolve({ url: urlStr, status: 'ERROR: ' + err.message });
      });
      req.setTimeout(5000, () => {
        req.destroy();
        resolve({ url: urlStr, status: 'TIMEOUT' });
      });
    } catch (e) {
      resolve({ url: urlStr, status: 'EXC: ' + e.message });
    }
  });
}

async function run() {
  for (const u of candidates) {
    const res = await checkUrl(u);
    console.log(`${res.url} => Status: ${res.status}`);
  }
}

run();
