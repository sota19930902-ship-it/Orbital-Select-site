const fs = require('fs');

let content = fs.readFileSync('src/data/mockData.ts', 'utf8');

// Find the PRODUCTS array
const productsStart = content.indexOf('export const PRODUCTS: Product[] = [');
const orbitStart = content.indexOf('export const ORBIT_COLLECTIONS');

let productsSection = content.slice(productsStart, orbitStart);

// Remove ALL lv- product blocks (including multi-line)
// Strategy: find each { id: 'lv-...' ... }, block and remove it
let cleaned = productsSection;

// Use a state machine approach to remove lv- blocks
let result = '';
let i = 0;
while (i < cleaned.length) {
  // Check if we're at a block that starts with id: 'lv-'
  const blockStart = cleaned.indexOf("  {\n    id: 'lv-", i);
  if (blockStart === -1) {
    result += cleaned.slice(i);
    break;
  }
  // Add everything before this block
  result += cleaned.slice(i, blockStart);
  
  // Find the end of this block: look for next \n  { or \n]; or \n  // 
  let depth = 0;
  let j = blockStart;
  let inBlock = false;
  while (j < cleaned.length) {
    if (cleaned[j] === '{') {
      depth++;
      inBlock = true;
    } else if (cleaned[j] === '}') {
      depth--;
      if (inBlock && depth === 0) {
        // End of block - skip the trailing comma and newline
        j++;
        while (j < cleaned.length && (cleaned[j] === ',' || cleaned[j] === '\n')) {
          j++;
        }
        break;
      }
    }
    j++;
  }
  i = j;
}

// Also remove the La Vita section comments
result = result.replace(/\n  \/\/ ── La Vita Designer Lighting \(\d+ products\)\n/g, '\n');
result = result.replace(/\n  \/\/ La Vita Scraped Best-Selling Products\n/g, '\n');
result = result.replace(/\n  \/\/ La Vita Lighting Products\n/g, '\n');

// Verify: count lv- remaining
const lvRemaining = (result.match(/id:\s*'lv-/g) || []).length;
console.log(`After cleanup, lv- products remaining: ${lvRemaining}`);

// Rebuild the file
const newContent = content.slice(0, productsStart) + result + content.slice(orbitStart);
fs.writeFileSync('src/data/mockData.ts', newContent);
console.log('Cleaned up lv- products from mockData.ts');
