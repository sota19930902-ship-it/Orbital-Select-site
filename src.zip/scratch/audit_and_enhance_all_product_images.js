const fs = require('fs');
const https = require('https');

function fetchHtml(urlStr) {
  return new Promise((resolve) => {
    const options = {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'ja,en-US;q=0.9,en;q=0.8'
      }
    };
    https.get(urlStr, options, (res) => {
      if ((res.statusCode === 301 || res.statusCode === 302) && res.headers.location) {
        let loc = res.headers.location;
        if (!loc.startsWith('http')) {
          loc = (urlStr.includes('masterwal') ? 'https://www.masterwal.jp' : 'https://online.actus-interior.com') + (loc.startsWith('/') ? '' : '/') + loc;
        }
        return resolve(fetchHtml(loc));
      }
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(data));
    }).on('error', () => resolve(''));
  });
}

async function main() {
  let content = fs.readFileSync('src/data/mockData.ts', 'utf8');

  // Extract products
  const productBlocks = [];
  const blockRegex = /\{\s*id:\s*['"]([^'"]+)['"][\s\S]*?\n  \},?/g;

  let match;
  const targetProducts = [];

  while ((match = blockRegex.exec(content)) !== null) {
    const fullBlock = match[0];
    const id = match[1];
    const nameMatch = fullBlock.match(/name:\s*['"]([^'"]+)['"]/);
    const urlMatch = fullBlock.match(/url:\s*['"]([^'"]+)['"]/);
    const imgMatch = fullBlock.match(/images:\s*\[([\s\S]*?)\]/);

    targetProducts.push({
      id,
      name: nameMatch ? nameMatch[1] : '',
      url: urlMatch ? urlMatch[1] : '',
      block: fullBlock,
      images: imgMatch ? imgMatch[1].split(',').map(s => s.trim().replace(/['"]/g, '')).filter(Boolean) : []
    });
  }

  console.log(`Auditing all ${targetProducts.length} products across the codebase...`);

  let auditedCount = 0;
  let fixedCount = 0;

  for (const prod of targetProducts) {
    auditedCount++;
    const isActus = prod.id.startsWith('ac-') || prod.url.includes('actus-interior');
    const isMasterwal = prod.id.startsWith('mw-') || prod.url.includes('masterwal.jp');

    let isMismatch = false;
    const nameLower = prod.name.toLowerCase();
    const primaryImg = prod.images[0] || '';

    // Mismatch detection
    if (primaryImg.includes('felt') || primaryImg.includes('DCFT') || primaryImg.includes('cushion') || primaryImg.includes('cover_only')) {
      if (!nameLower.includes('フェルト') && !nameLower.includes('クッション') && !nameLower.includes('カバー')) {
        isMismatch = true;
      }
    }

    if (isActus || isMasterwal || isMismatch) {
      console.log(`[${auditedCount}/${targetProducts.length}] Inspecting: [${prod.id}] ${prod.name.slice(0, 35)}...`);
      if (prod.url) {
        const html = await fetchHtml(prod.url);
        if (html) {
          let extractedImages = [];

          if (isActus) {
            const matches = html.match(/\/contents\/images\/goods\/[^\s"'<>]+/gi) || [];
            const hdUrls = matches
              .map(path => {
                let full = path.startsWith('http') ? path : 'https://online.actus-interior.com' + path;
                return full.replace(/\/detail\/S\//, '/detail/L/');
              })
              .filter(url => 
                !url.includes('loader') && 
                !url.includes('DCFT') && 
                !url.includes('felt') &&
                (url.includes('_main') || url.includes('_01') || url.includes('_02') || url.includes('_03') || url.includes('_04') || url.includes('_800x800'))
              );

            extractedImages = Array.from(new Set(hdUrls));
          } else if (isMasterwal) {
            const matches = html.match(/\/img\/goods\/[^\s"'<>]+/gi) || [];
            const hdUrls = matches
              .map(path => {
                let full = path.startsWith('http') ? path : 'https://www.masterwal.jp' + path;
                return full.replace(/\/img\/goods\/S\//, '/img/goods/L/');
              })
              .filter(url => !url.includes('no_image') && (url.endsWith('.jpg') || url.endsWith('.png') || url.endsWith('.jpeg')));

            extractedImages = Array.from(new Set(hdUrls));
          }

          if (extractedImages.length > 0) {
            let finalImages = extractedImages.slice(0, 4);

            // Re-order if primary image is better
            const mainCandidate = finalImages.find(img => img.includes('_main') || img.includes('001') || img.includes('_01'));
            if (mainCandidate && finalImages[0] !== mainCandidate) {
              finalImages = [mainCandidate, ...finalImages.filter(img => img !== mainCandidate)];
            }

            const newImagesArrayStr = `images: [\n      ${finalImages.map(img => `'${img}'`).join(',\n      ')}\n    ],`;
            content = content.replace(prod.block, prod.block.replace(/images:\s*\[[\s\S]*?\]\s*,?/, newImagesArrayStr));
            fixedCount++;
            console.log(`   Updated ${finalImages.length} Full HD multi-angle images.`);
          }
        }
      }
    }
  }

  // Also check if any product has less than 2 images and add Unsplash multi-angle high-res fallbacks for manual products
  fs.writeFileSync('src/data/mockData.ts', content);
  console.log(`\nAudit & Multi-Angle HD Image Enhancement Complete! Total audited: ${auditedCount}, Updated: ${fixedCount}`);
}

main();
