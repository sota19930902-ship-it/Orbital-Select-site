const fs = require('fs');

let content = fs.readFileSync('src/data/mockData.ts', 'utf8');

const actusChairs = [
  {
    id: 'ac-2716743',
    name: 'ACTUS CARL HANSEN & SON | CH24 Yチェア (オーク無垢材)',
    subtitle: 'ハンス・J・ウェグナーの不朽の名作。アクタスで最も愛される北欧チェアの金字塔',
    brand: 'ACTUS',
    partnerBrandId: 'actus',
    category: 'chair',
    taste: 'nordic',
    room: 'dining',
    price: 156200,
    priceRangeId: '10to20',
    rating: 4.98,
    reviewCount: 128,
    images: ['https://online.actus-interior.com/contents/images/goods/detail/L/d64/2716743_main_800x800.jpg'],
    description: 'アクタス公式オンラインショップで絶大な人気を誇る北欧家具の巨匠ハンス・J・ウェグナーの代表作「CH24（Yチェア）」。美しい曲線の背もたれと手編みのペーパーコード座面が身体をやさしく包み込みます。',
    materials: ['オーク無垢材（ソープ仕上げ） / ナチュラルペーパーコード'],
    dimensions: 'W550 × D510 × H760 (SH450) mm',
    color: 'ナチュラルオーク / ペーパーコード',
    sizeCategory: 'ダイニングチェア',
    tags: ['アクタス', 'CH24', 'Yチェア', '北欧名作チェア', 'カールハンセン'],
    editorialComment: '後ろ姿まで美しいY字型の背もたれと、使い込むほどに馴染むペーパーコード。一生モノとして愛される究極の一脚。',
    pros: ['不朽の北欧モダンデザイン', '手編みペーパーコードの優しい座り心地', '一生モノの資産価値'],
    cons: ['人気アイテムのため納期の確認を推奨'],
    targetUser: '本格北欧インテリアや歴史的名作家具のある豊かな暮らしを求める方',
    shopLinks: [
      {
        name: 'ACTUS 公式ストア',
        label: 'ACTUS公式オンラインショップで見る',
        price: 156200,
        url: 'https://online.actus-interior.com/item/2716743/?utm_source=valuecommerce&utm_medium=affiliate&utm_campaign=vc',
        isOfficial: true,
      },
    ],
  },
  {
    id: 'ac-6006371',
    name: 'ACTUS Artek | スツール 60 (バーチ材)',
    subtitle: 'アルヴァ・アアルトによるフィンランドデザインの象徴。スタッキング可能な万能名作スツール',
    brand: 'ACTUS',
    partnerBrandId: 'actus',
    category: 'chair',
    taste: 'nordic',
    room: 'living',
    price: 31900,
    priceRangeId: 'under10',
    rating: 4.92,
    reviewCount: 94,
    images: ['https://online.actus-interior.com/contents/images/goods/detail/L/7bb/6006371_main1.jpg'],
    description: '1933年にアルヴァ・アアルトによってデザインされたアルテックのアイコン「スツール 60」。曲げ木のL-レッグ技法による高い堅牢性と、椅子・サイドテーブル・ディスプレイ台として多目的に活躍する万能美。',
    materials: ['バーチ無垢材（ナチュラルラッカー仕上げ）'],
    dimensions: 'W380 × D380 × H440 (座面φ380) mm',
    color: 'ナチュラルバーチ',
    sizeCategory: 'スツール',
    tags: ['アクタス', 'アルテック', 'スツール60', 'アアルト', '北欧スツール'],
    editorialComment: 'スタッキングして並べても絵になる幾何学的造形。椅子としてはもちろん、ソファ横のサイドテーブルやグリーン台としても最適です。',
    pros: ['万能な多機能性', 'スタッキング収納可能', '北欧モダンの洗練されたデザイン'],
    cons: ['組み立て式（簡単に組み立て可能）'],
    targetUser: '省スペースで多目的に使える上質な北欧スツールを探している方',
    shopLinks: [
      {
        name: 'ACTUS 公式ストア',
        label: 'ACTUS公式オンラインショップで見る',
        price: 31900,
        url: 'https://online.actus-interior.com/item/6006371/?utm_source=valuecommerce&utm_medium=affiliate&utm_campaign=vc',
        isOfficial: true,
      },
    ],
  },
  {
    id: 'ac-9564301',
    name: 'ACTUS WERNER | SHOEMAKER スツール 49cm (シューメーカー)',
    subtitle: '靴職人の座り心地から生まれたデンマーク伝統の立体座面無垢スツール',
    brand: 'ACTUS',
    partnerBrandId: 'actus',
    category: 'chair',
    taste: 'nordic',
    room: 'dining',
    price: 35200,
    priceRangeId: 'under10',
    rating: 4.94,
    reviewCount: 86,
    images: ['https://online.actus-interior.com/contents/images/goods/detail/L/LTb/9564301_main.jpg'],
    description: '人体工学に基づきお尻の形に合わせて削り出された独自の立体座面が特徴の「シューメーカー スツール」。アクタスロングセラー。',
    materials: ['ビーチ無垢材（無塗装ソープフィニッシュ可能）'],
    dimensions: 'W530 × D400 × H490 (SH460) mm',
    color: 'ナチュラルビーチ',
    sizeCategory: 'ダイニングスツール',
    tags: ['アクタス', 'シューメーカー', 'ワーナー', 'デンマーク製', '無垢スツール'],
    editorialComment: '長時間座っても疲れない立体成形座面。無垢材の手触りが毎日の暮らしに温もりを与えます。',
    pros: ['お尻にぴったりフィットする座り心地', '無垢材の木目', '持ち運びやすい軽量設計'],
    cons: ['定期的な専用お手入れを推奨'],
    targetUser: 'ダイニングやキッチンで手軽に座れるフィット感抜群のスツールをお探しの方',
    shopLinks: [
      {
        name: 'ACTUS 公式ストア',
        label: 'ACTUS公式オンラインショップで見る',
        price: 35200,
        url: 'https://online.actus-interior.com/item/9564301/?utm_source=valuecommerce&utm_medium=affiliate&utm_campaign=vc',
        isOfficial: true,
      },
    ],
  },
  {
    id: 'ac-2440572',
    name: 'ACTUS SIGNAL チェア (オーク無垢材 / カバーリング仕様)',
    subtitle: '無垢オークフレームと心地よいファブリック。アクタスオリジナルの上質ダイニングチェア',
    brand: 'ACTUS',
    partnerBrandId: 'actus',
    category: 'chair',
    taste: 'nordic',
    room: 'dining',
    price: 37400,
    priceRangeId: 'under10',
    rating: 4.89,
    reviewCount: 45,
    images: ['https://online.actus-interior.com/contents/images/goods/detail/L/b6f/2419727_01_SIGNAL_DC_OAK_SOLID_IV_02.jpg'],
    description: '細身の無垢オーク材フレームとファブリック座面が調和したアクタスオリジナルのSIGNALチェア。カバーリング仕様でお手入れも安心。',
    materials: ['オーク無垢材 / 布地（ファブリック）'],
    dimensions: 'W480 × D510 × H780 (SH440) mm',
    color: 'オーク / アイボリー',
    sizeCategory: 'ダイニングチェア',
    tags: ['アクタス', 'SIGNAL', 'ダイニングチェア', 'オーク無垢', 'カバーリング'],
    editorialComment: '軽やかな見た目としっかりとした背当たり。カバーを取り外してドライクリーニング可能。',
    pros: ['カバーリングで清潔さをキープ', '無垢オークの美しい質感', '軽量で扱いやすい'],
    cons: ['人気のため色柄バリエーション確認推奨'],
    targetUser: 'お手入れのしやすさと木の温もりを兼ね備えたダイニングチェアをお探しの方',
    shopLinks: [
      {
        name: 'ACTUS 公式ストア',
        label: 'ACTUS公式オンラインショップで見る',
        price: 37400,
        url: 'https://online.actus-interior.com/item/2440572/?utm_source=valuecommerce&utm_medium=affiliate&utm_campaign=vc',
        isOfficial: true,
      },
    ],
  }
];

// First, remove existing ac-2440572, ac-2716743, ac-6006371, ac-9564301 if present
actusChairs.forEach(chair => {
  const idRegex = new RegExp(`\\{\\s*id:\\s*['"]${chair.id}['"][\\s\\S]*?\\n  \\},?`, 'g');
  content = content.replace(idRegex, '');
});

const orbitPos = content.indexOf('export const ORBIT_COLLECTIONS');
const productStartPos = content.indexOf('export const PRODUCTS: Product[] = [');

let productSection = content.slice(productStartPos, orbitPos);
const productEndArrayPos = productSection.lastIndexOf('];');

const newChairCodeBlocks = actusChairs.map(chair => {
  return `  {
    id: '${chair.id}',
    name: '${chair.name.replace(/'/g, "\\'")}',
    subtitle: '${chair.subtitle}',
    brand: 'ACTUS',
    partnerBrandId: 'actus',
    category: 'chair',
    taste: '${chair.taste}',
    room: '${chair.room}',
    price: ${chair.price},
    priceRangeId: '${chair.priceRangeId}',
    rating: ${chair.rating},
    reviewCount: ${chair.reviewCount},
    images: ['${chair.images[0]}'],
    description: '${chair.description}',
    materials: ['${chair.materials[0]}'],
    dimensions: '${chair.dimensions}',
    color: '${chair.color}',
    sizeCategory: '${chair.sizeCategory}',
    tags: [${chair.tags.map(t => `'${t}'`).join(', ')}],
    editorialComment: '${chair.editorialComment}',
    pros: [${chair.pros.map(p => `'${p}'`).join(', ')}],
    cons: [${chair.cons.map(c => `'${c}'`).join(', ')}],
    targetUser: '${chair.targetUser}',
    shopLinks: [
      {
        name: 'ACTUS 公式ストア',
        label: 'ACTUS公式オンラインショップで見る',
        price: ${chair.price},
        url: '${chair.shopLinks[0].url}',
        isOfficial: true,
      },
    ],
  },`;
}).join('\n');

const cleanedProductSection = productSection.slice(0, productEndArrayPos) +
  `\n  // ACTUS Iconic HD Chair Collection\n` +
  newChairCodeBlocks +
  `\n];\n\n`;

const finalContent = content.slice(0, productStartPos) + cleanedProductSection + content.slice(orbitPos);

fs.writeFileSync('src/data/mockData.ts', finalContent);
console.log('Successfully registered 4 ACTUS iconic HD chairs into mockData.ts!');
