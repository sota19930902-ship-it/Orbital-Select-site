const fs = require('fs');

let content = fs.readFileSync('src/data/mockData.ts', 'utf8');

// 1. Delete all BeauBelle products (bb-...)
const productRegex = /\{\s*id:\s*['"]bb-[^'"]+['"][\s\S]*?\n  \},?/g;
content = content.replace(productRegex, '');

// 2. Delete BeauBelle brand from BRANDS array
const brandRegex = /\{\s*id:\s*['"]beaubelle['"][\s\S]*?\n  \},?/g;
content = content.replace(brandRegex, '');

// 3. Delete brand comparison with BeauBelle (beaubelle-vs-lavita)
const comparisonRegex = /\{\s*id:\s*['"]beaubelle-vs-lavita['"][\s\S]*?\n  \},?/g;
content = content.replace(comparisonRegex, '');

fs.writeFileSync('src/data/mockData.ts', content);
console.log('Successfully purged BeauBelle products, brand entry, and comparisons from mockData.ts!');
