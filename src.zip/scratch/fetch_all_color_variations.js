const fs = require('fs');
const https = require('https');

function fetchHtml(urlStr) {
  return new Promise((resolve) => {
    const options = {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'ja,en-US;q=0.9,en;q=0.8'
      }
    };
    https.get(urlStr, options, (res) => {
      if ((res.statusCode === 301 || res.statusCode === 302) && res.headers.location) {
        let loc = res.headers.location;
        if (!loc.startsWith('http')) {
          loc = (urlStr.includes('masterwal') ? 'https://www.masterwal.jp' : 
                (urlStr.includes('air-r') ? 'https://www.air-r.jp' : 'https://online.actus-interior.com')) + (loc.startsWith('/') ? '' : '/') + loc;
        }
        return resolve(fetchHtml(loc));
      }
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(data));
    }).on('error', () => resolve(''));
  });
}

async function main() {
  let content = fs.readFileSync('src/data/mockData.ts', 'utf8');

  // Find products with official URLs
  const productBlocks = [];
  const blockRegex = /\{\s*id:\s*['"]([^'"]+)['"][\s\S]*?\n  \},?/g;

  let match;
  const targetProducts = [];

  while ((match = blockRegex.exec(content)) !== null) {
    const fullBlock = match[0];
    const id = match[1];
    const nameMatch = fullBlock.match(/name:\s*['"]([^'"]+)['"]/);
    const urlMatch = fullBlock.match(/url:\s*['"]([^'"]+)['"]/);

    if (urlMatch) {
      targetProducts.push({
        id,
        name: nameMatch ? nameMatch[1] : '',
        url: urlMatch[1],
        block: fullBlock
      });
    }
  }

  console.log(`Scanning official detail pages of ${targetProducts.length} products for color variations...`);

  let updatedCount = 0;

  for (const prod of targetProducts) {
    if (!prod.url || !prod.url.startsWith('http')) continue;

    const isAirR = prod.url.includes('air-r.jp');
    const isActus = prod.url.includes('actus-interior.com');
    const isMasterwal = prod.url.includes('masterwal.jp');

    if (isAirR || isActus || isMasterwal) {
      console.log(`Fetching color variations for [${prod.id}] ${prod.name.slice(0, 35)}...`);
      const html = await fetchHtml(prod.url);
      if (!html) continue;

      let extractedImages = [];

      if (isAirR) {
        // Air Rhizome save_image URLs for color variations
        const matches = html.match(/\/upload\/save_image\/[^\s"'<>\)]+/gi) || [];
        const fullUrls = Array.from(new Set(matches.map(p => p.startsWith('http') ? p : 'https://www.air-r.jp' + p)))
          .filter(url => !url.includes('btn') && !url.includes('icon') && !url.includes('banner'));
        extractedImages = fullUrls.slice(0, 8);
      } else if (isActus) {
        // ACTUS color & variation images
        const matches = html.match(/\/contents\/images\/goods\/[^\s"'<>]+/gi) || [];
        const hdUrls = matches
          .map(path => {
            let full = path.startsWith('http') ? path : 'https://online.actus-interior.com' + path;
            return full.replace(/\/detail\/S\//, '/detail/L/').replace(/\/detail\/M\//, '/detail/L/');
          })
          .filter(url => 
            !url.includes('loader') && 
            !url.includes('DCFT') && 
            !url.includes('felt')
          );
        extractedImages = Array.from(new Set(hdUrls)).slice(0, 8);
      } else if (isMasterwal) {
        // MASTERWAL finish & color variation images
        const matches = html.match(/\/img\/goods\/[^\s"'<>]+/gi) || [];
        const hdUrls = matches
          .map(path => {
            let full = path.startsWith('http') ? path : 'https://www.masterwal.jp' + path;
            return full.replace(/\/img\/goods\/S\//, '/img/goods/L/');
          })
          .filter(url => !url.includes('no_image') && (url.endsWith('.jpg') || url.endsWith('.png') || url.endsWith('.jpeg')));
        extractedImages = Array.from(new Set(hdUrls)).slice(0, 8);
      }

      if (extractedImages.length > 1) {
        console.log(`   Found ${extractedImages.length} color/variation HD images.`);
        const newImagesArrayStr = `images: [\n      ${extractedImages.map(img => `'${img}'`).join(',\n      ')}\n    ],`;
        content = content.replace(prod.block, prod.block.replace(/images:\s*\[[\s\S]*?\]\s*,?/, newImagesArrayStr));
        updatedCount++;
      }
    }
  }

  fs.writeFileSync('src/data/mockData.ts', content);
  console.log(`\nSuccessfully updated ${updatedCount} products with color variation image galleries!`);
}

main();
