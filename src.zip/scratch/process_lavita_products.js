const fs = require('fs');

const rawProducts = JSON.parse(fs.readFileSync('scratch/lavita_all_raw.json', 'utf8'));
console.log(`Processing ${rawProducts.length} raw La Vita products...`);

function cleanTitle(title) {
  return title
    .replace(/3年保証/g, '')
    .replace(/【正規品】/g, '')
    .replace(/【送料無料】/g, '')
    .replace(/【[^\]]+】/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

const validProducts = [];
const seenHandles = new Set();

for (const p of rawProducts) {
  if (seenHandles.has(p.handle)) continue;
  if (!p.images || p.images.length === 0) continue; // Must have high-res image
  if (p.title.includes('交換用シェード') || p.title.includes('カタログ') || p.title.includes('パーツ')) continue;

  const price = p.variants && p.variants[0] ? parseFloat(p.variants[0].price) : 0;
  if (!price || price < 5000) continue;

  seenHandles.add(p.handle);

  const cleanName = cleanTitle(p.title);
  const images = p.images.map(img => img.src).slice(0, 4);

  let category = 'lighting';
  if (cleanName.includes('テーブル') || cleanName.includes('デスク')) {
    if (cleanName.includes('ランプ') || cleanName.includes('ライト') || cleanName.includes('照明')) category = 'lighting';
    else category = 'table';
  } else if (cleanName.includes('チェア') || cleanName.includes('スツール')) {
    category = 'chair';
  }

  let priceRangeId = 'under10';
  if (price >= 400000) priceRangeId = 'over40';
  else if (price >= 200000) priceRangeId = '20to40';
  else if (price >= 100000) priceRangeId = '10to20';

  let rawDesc = p.body_html ? p.body_html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim() : '';
  if (rawDesc.length > 200) rawDesc = rawDesc.slice(0, 200) + '...';
  if (!rawDesc) rawDesc = `${cleanName}。北欧デンマーク・イタリア名作デザイナーズ照明La Vita公式ショップ取扱品。`;

  validProducts.push({
    id: `lv-${p.handle.toLowerCase().replace(/[^a-z0-9\-]/g, '')}`,
    name: cleanName.startsWith('La Vita') ? cleanName : `La Vita ${cleanName}`,
    cleanTitle: cleanName,
    category,
    room: 'living',
    price: Math.round(price),
    priceRangeId,
    images,
    description: rawDesc,
    url: `https://lavita-shop.jp/products/${p.handle}`,
    affiliateUrl: `https://lavita-shop.jp/products/${p.handle}?utm_source=orbital_select&utm_medium=affiliate`,
    subCatName: '名作デザイナーズ照明'
  });
}

console.log(`Extracted ${validProducts.length} valid La Vita designer products.`);
fs.writeFileSync('scratch/lavita_scraped_data.json', JSON.stringify(validProducts.slice(0, 30), null, 2));
