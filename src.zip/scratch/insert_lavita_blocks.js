const fs = require('fs');

let content = fs.readFileSync('src/data/mockData.ts', 'utf8');
const blocks = fs.readFileSync('scratch/lavita_product_blocks.ts', 'utf8');

// Find the end of PRODUCTS array (the ]; right before ORBIT_COLLECTIONS)
const orbitStart = content.indexOf('export const ORBIT_COLLECTIONS');
const productsStart = content.indexOf('export const PRODUCTS: Product[] = [');

// Find the last ]; before orbitStart
let insertPos = content.lastIndexOf('];', orbitStart);

// Verify this is the products array end
const between = content.slice(insertPos, orbitStart).trim();
if (!between.startsWith('];')) {
  console.error('Could not find products array end');
  process.exit(1);
}

// Insert the blocks before the ];
const newContent = 
  content.slice(0, insertPos) +
  ',\n  // ── La Vita Designer Lighting Products (1185 items)\n' +
  blocks +
  '\n];\n\n' +
  content.slice(orbitStart);

fs.writeFileSync('src/data/mockData.ts', newContent);

// Verify
const lvCount = (newContent.match(/partnerBrandId: 'lavita'/g) || []).length;
console.log(`La Vita products registered: ${lvCount}`);
console.log('Done!');
