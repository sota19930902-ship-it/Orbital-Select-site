const fs = require('fs');
let c = fs.readFileSync('src/data/mockData.ts', 'utf8');

// Remove the rogue "]\n as Product[]);" line that's floating around
c = c.split('\n] as Product[]);\n').join('\n');
c = c.split('] as Product[]);\n').join('');
c = c.split('] as Product[]);').join('');

// Also fix any rogue "export\n" that appeared
// The broken export should be "export const ORBIT_COLLECTIONS"
// find "export\n\nexport const ORBIT" and fix
c = c.split('\nexport\n\nexport const ORBIT_COLLECTIONS').join('\n\nexport const ORBIT_COLLECTIONS');
c = c.split('\nexport\nexport const ORBIT_COLLECTIONS').join('\n\nexport const ORBIT_COLLECTIONS');

fs.writeFileSync('src/data/mockData.ts', c);

// Verify
const orbitPos = c.indexOf('export const ORBIT_COLLECTIONS');
const lvCount = (c.match(/partnerBrandId: 'lavita'/g)||[]).length;
console.log('ORBIT_COLLECTIONS at:', orbitPos > 0 ? 'found' : 'NOT FOUND');
console.log('La Vita products:', lvCount);
console.log('Stray ] as Product:', (c.match(/\] as Product/g)||[]).length);
