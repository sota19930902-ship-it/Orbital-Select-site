const fs = require('fs');

let content = fs.readFileSync('src/data/mockData.ts', 'utf8');

// Count lv- products before fix
const lvCount = (content.match(/id:\s*'lv-/g) || []).length;
console.log(`lv- products in file: ${lvCount}`);

// Check for undefined or broken entries
const undefinedMatch = content.match(/\bundefined\b/g);
console.log(`undefined occurrences: ${undefinedMatch ? undefinedMatch.length : 0}`);

// Remove any trailing comma issues after array items
// Fix: replace ,\n] with \n] in product arrays
content = content.replace(/,\s*\n(\s*\];\s*\n\s*export const ORBIT)/g, '\n$1');

fs.writeFileSync('src/data/mockData.ts', content);
console.log('Fixed trailing comma issues in mockData.ts');
