const fs = require('fs');
let c = fs.readFileSync('src/data/mockData.ts', 'utf8');

// Fix the broken pattern: "export] as Product[]);" -> restore correct form
// Also find and fix the opening: "export const PRODUCTS = (["
// Revert to simple approach: fix declaration line and end

// Step 1: Fix broken "export] as Product[]);"
c = c.split('export] as Product[]);').join('] as Product[]);\n\nexport');

// Step 2: Check if opening was changed
if (c.includes('export const PRODUCTS = ([')) {
  c = c.split('export const PRODUCTS = ([').join('export const PRODUCTS: Product[] = [');
  // Also remove the extra as cast we tried to add
  const orbitStart = c.indexOf('export const ORBIT_COLLECTIONS');
  const endPos = c.lastIndexOf('] as Product[]);\n\n', orbitStart);
  if (endPos !== -1) {
    c = c.slice(0, endPos) + '];\n\n' + c.slice(endPos + '] as Product[]);\n\n'.length);
  }
}

fs.writeFileSync('src/data/mockData.ts', c);
console.log('Fixed broken cast pattern');

// Verify structure
const productsDecl = c.indexOf('export const PRODUCTS: Product[] = [');
const orbitDecl = c.indexOf('export const ORBIT_COLLECTIONS');
console.log('PRODUCTS declaration found at:', productsDecl);
console.log('ORBIT_COLLECTIONS found at:', orbitDecl);
console.log('lv- count:', (c.match(/partnerBrandId: 'lavita'/g)||[]).length);
