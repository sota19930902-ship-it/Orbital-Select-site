const https = require('https');

https.get('https://orbital-select-site.vercel.app/', (res) => {
  let body = '';
  res.on('data', chunk => body += chunk);
  res.on('end', () => {
    console.log('=== JUKE 周辺のHTMLスニペット (2000文字) ===');
    const idx = body.indexOf('JUKE');
    if (idx !== -1) {
      console.log(body.substring(idx - 400, idx + 600));
    } else {
      console.log('JUKE not found');
    }
    
    console.log('\n=== 本番HTML内の footer 付近のリンク ===');
    const privacyIdx = body.indexOf('privacy-policy');
    if (privacyIdx !== -1) {
      console.log(body.substring(privacyIdx - 200, privacyIdx + 300));
    } else {
      console.log('privacy-policy not found');
    }
    
    console.log('\n=== 価格帯ガイドの見出し付近 ===');
    const priceIdx = body.indexOf('価格帯ガイド');
    if (priceIdx !== -1) {
      console.log(body.substring(priceIdx - 100, priceIdx + 300));
    } else {
      console.log('価格帯ガイド not found');
    }
  });
});
