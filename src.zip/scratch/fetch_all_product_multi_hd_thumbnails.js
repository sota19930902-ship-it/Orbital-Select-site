const fs = require('fs');
const https = require('https');

function fetchHtml(urlStr) {
  return new Promise((resolve) => {
    const options = {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'ja,en-US;q=0.9,en;q=0.8'
      }
    };
    https.get(urlStr, options, (res) => {
      if ((res.statusCode === 301 || res.statusCode === 302) && res.headers.location) {
        let loc = res.headers.location;
        if (!loc.startsWith('http')) {
          loc = (urlStr.includes('masterwal') ? 'https://www.masterwal.jp' : 'https://online.actus-interior.com') + (loc.startsWith('/') ? '' : '/') + loc;
        }
        return resolve(fetchHtml(loc));
      }
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(data));
    }).on('error', () => resolve(''));
  });
}

async function main() {
  let content = fs.readFileSync('src/data/mockData.ts', 'utf8');

  // Extract products
  const productBlocks = [];
  const blockRegex = /\{\s*id:\s*['"]([^'"]+)['"][\s\S]*?\n  \},?/g;

  let match;
  const targetProducts = [];

  while ((match = blockRegex.exec(content)) !== null) {
    const fullBlock = match[0];
    const id = match[1];
    const urlMatch = fullBlock.match(/url:\s*['"]([^'"]+)['"]/);

    if (urlMatch && (id.startsWith('ac-') || id.startsWith('mw-'))) {
      targetProducts.push({
        id,
        url: urlMatch[1],
        block: fullBlock
      });
    }
  }

  console.log(`Found ${targetProducts.length} ACTUS and MASTERWAL products to fetch HD multi-angle thumbnails.`);

  for (const prod of targetProducts.slice(0, 30)) {
    console.log(`Fetching multi-angle HD thumbnails for [${prod.id}] ${prod.url.slice(0, 55)}...`);
    const html = await fetchHtml(prod.url);
    if (!html) continue;

    let galleryImages = [];

    if (prod.id.startsWith('ac-')) {
      // ACTUS gallery images
      const matches = html.match(/\/contents\/images\/goods\/[^\s"'<>]+/gi) || [];
      const hdUrls = matches
        .map(path => {
          let full = path.startsWith('http') ? path : 'https://online.actus-interior.com' + path;
          return full.replace(/\/detail\/S\//, '/detail/L/');
        })
        .filter(url => !url.includes('loader') && (url.includes('_main') || url.includes('_01') || url.includes('_02') || url.includes('_03') || url.includes('_04') || url.includes('_800x800')));
      
      galleryImages = Array.from(new Set(hdUrls)).slice(0, 4);
    } else if (prod.id.startsWith('mw-')) {
      // MASTERWAL gallery images
      const matches = html.match(/\/img\/goods\/[^\s"'<>]+/gi) || [];
      const hdUrls = matches
        .map(path => {
          let full = path.startsWith('http') ? path : 'https://www.masterwal.jp' + path;
          return full.replace(/\/img\/goods\/S\//, '/img/goods/L/');
        })
        .filter(url => !url.includes('no_image') && (url.endsWith('.jpg') || url.endsWith('.png') || url.endsWith('.jpeg')));

      galleryImages = Array.from(new Set(hdUrls)).slice(0, 4);
    }

    if (galleryImages.length > 0) {
      console.log(`   Found ${galleryImages.length} HD gallery images.`);
      const newImagesArrayStr = `images: [\n      ${galleryImages.map(img => `'${img}'`).join(',\n      ')}\n    ],`;
      content = content.replace(prod.block, prod.block.replace(/images:\s*\[[^\]]*\]\s*,?/, newImagesArrayStr));
    }
  }

  fs.writeFileSync('src/data/mockData.ts', content);
  console.log('Successfully updated mockData.ts with HD multi-angle thumbnails for all products!');
}

main();
