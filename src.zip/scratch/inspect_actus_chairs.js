const fs = require('fs');

const content = fs.readFileSync('src/data/mockData.ts', 'utf8');

const actusChairMatches = content.match(/\{\s*id:\s*['"]ac-[^'"]+['"][\s\S]*?category:\s*['"]chair['"][\s\S]*?\n  \},?/gi);
console.log('Found ACTUS chairs count:', actusChairMatches ? actusChairMatches.length : 0);

if (actusChairMatches) {
  actusChairMatches.forEach(block => {
    const idMatch = block.match(/id:\s*['"]([^'"]+)['"]/);
    const nameMatch = block.match(/name:\s*['"]([^'"]+)['"]/);
    const imgMatch = block.match(/images:\s*\[['"]([^'"]+)['"]/);
    console.log(`ID: ${idMatch ? idMatch[1] : ''} | Name: ${nameMatch ? nameMatch[1] : ''}`);
    console.log(`   Img: ${imgMatch ? imgMatch[1] : 'NONE'}\n`);
  });
}
