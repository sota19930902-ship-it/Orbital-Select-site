const fs = require('fs');
let c = fs.readFileSync('src/data/mockData.ts', 'utf8');

// Change: export const PRODUCTS: Product[] = [
// To:     export const PRODUCTS: Product[] = ([
// and close with ] as Product[]);
// This forces TypeScript to cast the array

// Simpler approach: add satisfies or just cast individual problematic entries
// Actually the cleanest fix is to add as Product[] at the end
const before = 'export const PRODUCTS: Product[] = [';
const after = 'export const PRODUCTS = ([';

// Find the closing ]; of PRODUCTS
const orbitStart = c.indexOf('export const ORBIT_COLLECTIONS');
const endPos = c.lastIndexOf('];\n\n', orbitStart);

c = c.replace(before, after);
c = c.slice(0, endPos) + '] as Product[]);\n\n' + c.slice(endPos + '];\n\n'.length);

fs.writeFileSync('src/data/mockData.ts', c);
console.log('Applied as Product[] cast to PRODUCTS array');
