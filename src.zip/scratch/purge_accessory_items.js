const fs = require('fs');

let content = fs.readFileSync('src/data/mockData.ts', 'utf8');

// Find items that are felt leg caps or non-furniture accessories
const feltBlockRegex = /\{\s*id:\s*['"]mw-dcft-ft['"][\s\S]*?\n  \},?/g;
content = content.replace(feltBlockRegex, '');

fs.writeFileSync('src/data/mockData.ts', content);
console.log('Purged felt leg accessory items from mockData.ts!');
