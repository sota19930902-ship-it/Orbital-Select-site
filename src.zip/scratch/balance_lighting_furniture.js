/**
 * 現在521件のPRODUCTS配列から照明を削減して500件に調整
 * 照明上限: 150件（中高価格帯を優先して残す）
 * 家具系は全件保持
 */

const fs = require('fs');

// エスケープ対応パーサー
function extractObjectBlocks(text) {
  const blocks = [];
  let depth = 0, inStr = false, strCh = '', objStart = -1, i = 0;
  while (i < text.length) {
    const ch = text[i];
    if (inStr) {
      if (ch === '\\') { i += 2; continue; }
      if (ch === strCh) inStr = false;
      i++; continue;
    }
    if (ch === '"' || ch === "'") { inStr = true; strCh = ch; i++; continue; }
    if (ch === '{') { if (depth === 0) objStart = i; depth++; }
    else if (ch === '}') { depth--; if (depth === 0 && objStart >= 0) { blocks.push(text.substring(objStart, i+1)); objStart = -1; } }
    i++;
  }
  return blocks;
}

function extractField(block, field) {
  const re = new RegExp(`${field}:\\s*'([^']*)'`);
  const m = block.match(re);
  return m ? m[1] : '';
}

function extractNum(block, field) {
  const re = new RegExp(`${field}:\\s*([\\d.]+)`);
  const m = block.match(re);
  return m ? parseFloat(m[1]) : 0;
}

const content = fs.readFileSync('src/data/mockData.ts', 'utf8');
const prodMarker = 'export const PRODUCTS: Product[] = [';
const prodMarkerIdx = content.indexOf(prodMarker);
const prodArrayStartIdx = prodMarkerIdx + prodMarker.length - 1;

let depth = 0, inStr = false, strCh = '', prodArrayEndIdx = -1, pi = prodArrayStartIdx;
while (pi < content.length) {
  const ch = content[pi];
  if (inStr) { if (ch === '\\') { pi += 2; continue; } if (ch === strCh) inStr = false; pi++; continue; }
  if (ch === '"' || ch === "'") { inStr = true; strCh = ch; pi++; continue; }
  if (ch === '[') depth++;
  else if (ch === ']') { depth--; if (depth === 0) { prodArrayEndIdx = pi; break; } }
  pi++;
}

const headerSection = content.substring(0, prodMarkerIdx);
const footerSection = content.substring(prodArrayEndIdx + 1);
const productsInner = content.substring(prodArrayStartIdx + 1, prodArrayEndIdx);

const allBlocks = extractObjectBlocks(productsInner);
console.log('Total blocks:', allBlocks.length);

// カテゴリ別に分類
const furnitureBlocks = allBlocks.filter(b => extractField(b, 'category') !== 'lighting');
const lightingBlocks = allBlocks.filter(b => extractField(b, 'category') === 'lighting');

console.log('Furniture blocks:', furnitureBlocks.length);
console.log('Lighting blocks:', lightingBlocks.length);

// 照明を価格帯優先でソートして150件に制限
function lightingScore(block) {
  const priceRangeId = extractField(block, 'priceRangeId');
  const price = extractNum(block, 'price');
  const rating = extractNum(block, 'rating');
  let score = 0;
  if (priceRangeId === 'over40') score = 4;
  else if (priceRangeId === '20to40') score = 3;
  else if (priceRangeId === '10to20') score = 2;
  else if (price >= 30000) score = 1.5;
  else score = 1;
  return score * 10 + rating;
}

const sortedLighting = [...lightingBlocks].sort((a, b) => lightingScore(b) - lightingScore(a));

// 目標: 家具 + 照明 = 500件以内
// 照明は最大 500 - furnitureBlocks.length 件
const TARGET = 500;
const maxLighting = Math.min(150, TARGET - furnitureBlocks.length);
console.log('Max lighting to keep:', maxLighting);

const selectedLighting = sortedLighting.slice(0, maxLighting);
console.log('Selected lighting:', selectedLighting.length);

// 価格帯分布確認
const lightPriceDist = {};
for (const b of selectedLighting) {
  const p = extractField(b, 'priceRangeId');
  lightPriceDist[p] = (lightPriceDist[p] || 0) + 1;
}
console.log('Selected lighting price distribution:', lightPriceDist);

// 最終結合
const finalBlocks = [...furnitureBlocks, ...selectedLighting];
console.log('\nFinal product count:', finalBlocks.length);

// カテゴリ・ブランド分布
const catDist = {}, brandDist = {}, priceDist = {};
for (const b of finalBlocks) {
  const cat = extractField(b, 'category');
  const brand = extractField(b, 'partnerBrandId');
  const price = extractField(b, 'priceRangeId');
  catDist[cat] = (catDist[cat]||0)+1;
  brandDist[brand] = (brandDist[brand]||0)+1;
  priceDist[price] = (priceDist[price]||0)+1;
}
console.log('Categories:', catDist);
console.log('Brands:', brandDist);
console.log('Price ranges:', priceDist);

// 家具 vs 照明比率
const totalFurniture = finalBlocks.filter(b => extractField(b, 'category') !== 'lighting').length;
const totalLighting = finalBlocks.filter(b => extractField(b, 'category') === 'lighting').length;
console.log(`\nFurniture: ${totalFurniture} (${Math.round(totalFurniture/finalBlocks.length*100)}%)`);
console.log(`Lighting: ${totalLighting} (${Math.round(totalLighting/finalBlocks.length*100)}%)`);

// 中高価格帯比率
const midHigh = finalBlocks.filter(b => ['10to20','20to40','over40'].includes(extractField(b, 'priceRangeId'))).length;
console.log(`Mid-high price: ${midHigh} (${Math.round(midHigh/finalBlocks.length*100)}%)`);

// ファイル書き込み
const newContent = headerSection + prodMarker + '\n' + finalBlocks.join(',\n') + '\n]' + footerSection;
const count = (newContent.match(/partnerBrandId:/g)||[]).length;
console.log('\nProducts in new file:', count);
fs.writeFileSync('src/data/mockData.ts', newContent);
console.log('✓ mockData.ts updated with balanced distribution');
