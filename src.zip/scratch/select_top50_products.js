/**
 * 売れ筋50点選定スクリプト
 * - ブランドごとにisTopRanked/isEditorsPick/isNewArrivalフラグ優先
 * - rating高い順でソート
 * - 合計50点になるよう選定
 */

const fs = require('fs');

// mockData.ts からPRODUCTSを抽出
let content = fs.readFileSync('src/data/mockData.ts', 'utf8');

// Find PRODUCTS array bounds
const startMarker = 'export const PRODUCTS: Product[] = [';
const startIdx = content.indexOf(startMarker);
if (startIdx < 0) {
  console.error('PRODUCTS not found!');
  process.exit(1);
}

// Find matching closing bracket
let depth = 0;
let endIdx = -1;
let inString = false;
let strChar = '';
let i = startIdx + startMarker.length - 1;

for (; i < content.length; i++) {
  const ch = content[i];
  if (inString) {
    if (ch === strChar && content[i-1] !== '\\') inString = false;
    continue;
  }
  if (ch === '"' || ch === "'") { inString = true; strChar = ch; continue; }
  if (ch === '[' || ch === '{') depth++;
  else if (ch === ']' || ch === '}') {
    depth--;
    if (depth === 0) { endIdx = i; break; }
  }
}

const beforeProducts = content.substring(0, startIdx);
const afterProducts = content.substring(endIdx + 1);

// Extract JSON-like product objects using regex-based parsing
// We'll parse by id: fields
const allProducts = [];
const productRegex = /\{\s*id:\s*'([^']+)'[\s\S]*?(?=,\s*\{\s*id:|$)/g;

// Instead, use a simpler approach: eval-friendly extraction
// Count by finding id: patterns and extracting object blocks
const idPositions = [];
const idRegex = /(?:^\s*|\n\s*)\{[\s\n]*id:\s*'([^']+)'/g;
let m;
const productsText = content.substring(startIdx + startMarker.length, endIdx);

// Find all product start positions
const allIdMatches = [...productsText.matchAll(/\n\s*\{\s*\n?\s*id:\s*'([^']+)'/g)];
console.log('Found', allIdMatches.length, 'products');

// Extract product metadata without full parsing
// We'll use simpler patterns to get key fields
const products = [];
for (let pi = 0; pi < allIdMatches.length; pi++) {
  const match = allIdMatches[pi];
  const id = match[1];
  const startPos = match.index;
  const endPos = pi < allIdMatches.length - 1 ? allIdMatches[pi+1].index : productsText.length;
  const block = productsText.substring(startPos, endPos);
  
  const getField = (field, isNum = false) => {
    const re = new RegExp(`${field}:\\s*${isNum ? '([\\d.]+)' : "'([^']*)'"}`, 'i');
    const m = block.match(re);
    return m ? (isNum ? parseFloat(m[1]) : m[1]) : (isNum ? 0 : '');
  };
  const getBool = (field) => new RegExp(`${field}:\\s*true`).test(block);
  
  products.push({
    id,
    name: getField('name'),
    brand: getField('brand'),
    partnerBrandId: getField('partnerBrandId'),
    category: getField('category'),
    price: getField('price', true),
    rating: getField('rating', true),
    reviewCount: getField('reviewCount', true),
    isTopRanked: getBool('isTopRanked'),
    isEditorsPick: getBool('isEditorsPick'),
    isNewArrival: getBool('isNewArrival'),
    startPos,
    endPos,
    blockLength: block.length,
  });
}

console.log('\n--- Products by brand ---');
const byBrand = {};
for (const p of products) {
  byBrand[p.partnerBrandId] = byBrand[p.partnerBrandId] || [];
  byBrand[p.partnerBrandId].push(p);
}
for (const [brand, prods] of Object.entries(byBrand)) {
  console.log(`${brand}: ${prods.length}`);
}

// Score each product for selection
const scored = products.map(p => ({
  ...p,
  score: (p.isTopRanked ? 3 : 0) + (p.isEditorsPick ? 2 : 0) + (p.isNewArrival ? 1 : 0) + p.rating
}));

// Sort each brand's products by score desc
const TARGET = 50;
const brandList = Object.keys(byBrand);

// Priority: pick flagged products first across all brands
// Then fill remaining slots from top-rated per brand

// Step 1: Pick all flagged items
const flagged = scored.filter(p => p.isTopRanked || p.isEditorsPick || p.isNewArrival)
  .sort((a, b) => b.score - a.score);

const selected = new Set();
for (const p of flagged) {
  if (selected.size >= TARGET) break;
  selected.add(p.id);
}

// Step 2: If we have slots, fill with top-rated per brand (balanced)
if (selected.size < TARGET) {
  const remaining = TARGET - selected.size;
  // Sort all unselected by score desc, but spread across brands
  const unselected = scored.filter(p => !selected.has(p.id)).sort((a, b) => b.score - a.score);
  
  // Round-robin across brands for balance
  const brandQueues = {};
  for (const p of unselected) {
    if (!brandQueues[p.partnerBrandId]) brandQueues[p.partnerBrandId] = [];
    brandQueues[p.partnerBrandId].push(p);
  }
  
  let added = 0;
  let iterations = 0;
  while (added < remaining && iterations < 1000) {
    iterations++;
    let anyAdded = false;
    for (const brand of brandList) {
      if (added >= remaining) break;
      const q = brandQueues[brand] || [];
      if (q.length > 0) {
        const p = q.shift();
        if (!selected.has(p.id)) {
          selected.add(p.id);
          added++;
          anyAdded = true;
        }
      }
    }
    if (!anyAdded) break;
  }
}

console.log('\n--- Selected 50 products ---');
const selectedProducts = scored.filter(p => selected.has(p.id));
const selectedByBrand = {};
for (const p of selectedProducts) {
  selectedByBrand[p.partnerBrandId] = selectedByBrand[p.partnerBrandId] || [];
  selectedByBrand[p.partnerBrandId].push(p.id);
}
for (const [brand, ids] of Object.entries(selectedByBrand)) {
  console.log(`${brand}: ${ids.length} products`);
}
console.log('Total selected:', selected.size);

// Write selected IDs to a file for use in filtering
const selectedIds = [...selected];
fs.writeFileSync('scratch/top50_ids.json', JSON.stringify(selectedIds, null, 2));
console.log('\nWritten top50_ids.json');
