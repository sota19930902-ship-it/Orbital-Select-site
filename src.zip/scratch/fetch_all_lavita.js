const fs = require('fs');
const https = require('https');

function fetchUrl(urlStr) {
  return new Promise((resolve) => {
    const options = {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'ja,en-US;q=0.9,en;q=0.8'
      }
    };
    https.get(urlStr, options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(data));
    }).on('error', () => resolve(''));
  });
}

async function main() {
  let page = 1;
  let allProducts = [];

  while (page <= 5) {
    console.log(`Fetching Shopify products.json page ${page}...`);
    const jsonStr = await fetchUrl(`https://lavita-shop.jp/products.json?limit=250&page=${page}`);
    if (!jsonStr) break;
    try {
      const parsed = JSON.parse(jsonStr);
      if (!parsed.products || parsed.products.length === 0) break;
      console.log(`  Page ${page}: ${parsed.products.length} products`);
      allProducts.push(...parsed.products);
      page++;
    } catch (e) {
      break;
    }
  }

  console.log(`Total La Vita products found: ${allProducts.length}`);
  fs.writeFileSync('scratch/lavita_all_raw.json', JSON.stringify(allProducts, null, 2));
}

main();
