const https = require('https');

function fetchHtml(urlStr) {
  return new Promise((resolve) => {
    const options = {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'ja,en-US;q=0.9,en;q=0.8'
      }
    };
    https.get(urlStr, options, (res) => {
      if ((res.statusCode === 301 || res.statusCode === 302) && res.headers.location) {
        let loc = res.headers.location;
        if (!loc.startsWith('http')) {
          loc = 'https://www.air-r.jp' + (loc.startsWith('/') ? '' : '/') + loc;
        }
        return resolve(fetchHtml(loc));
      }
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(data));
    }).on('error', () => resolve(''));
  });
}

async function main() {
  console.log('Testing air-r.jp category listing (category_id=10)...');
  const listingHtml = await fetchHtml('https://www.air-r.jp/products/list.php?category_id=10');
  console.log('Listing HTML len:', listingHtml.length);

  const detailMatches = listingHtml.match(/\/products\/detail\.php\?product_id=\d+/g) || listingHtml.match(/detail\.php\?product_id=\d+/g) || [];
  console.log('Detail link matches found:', detailMatches.length);
  const uniqueDetailLinks = Array.from(new Set(detailMatches)).slice(0, 5);
  console.log('Unique sample links:', uniqueDetailLinks);

  if (uniqueDetailLinks.length > 0) {
    let firstUrl = uniqueDetailLinks[0];
    if (!firstUrl.startsWith('http')) {
      firstUrl = 'https://www.air-r.jp' + (firstUrl.startsWith('/') ? '' : '/products/') + firstUrl;
    }
    console.log('\nFetching sample detail page:', firstUrl);
    const detailHtml = await fetchHtml(firstUrl);
    console.log('Detail HTML len:', detailHtml.length);

    const titleMatch = detailHtml.match(/<title>([^<]+)<\/title>/i);
    const ogImg = detailHtml.match(/property="og:image"\s+content="([^"]+)"/i) || detailHtml.match(/src="([^"]*\/upload\/save_image\/[^"]+)"/i);
    const ogDesc = detailHtml.match(/property="og:description"\s+content="([^"]+)"/i) || detailHtml.match(/name="description"\s+content="([^"]+)"/i);
    const priceMatch = detailHtml.match(/¥\s*([\d,]+)/) || detailHtml.match(/([\d,]+)\s*円/);

    console.log('Title:', titleMatch ? titleMatch[1] : 'NONE');
    console.log('Image:', ogImg ? ogImg[1] : 'NONE');
    console.log('Description:', ogDesc ? ogDesc[1].slice(0, 100) + '...' : 'NONE');
    console.log('Price:', priceMatch ? priceMatch[1] : 'NONE');
  }
}

main();
