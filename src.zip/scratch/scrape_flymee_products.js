/**
 * FLYMEe各カテゴリページのHTMLから window.__PRODUCTS__ を抽出して
 * ちょうど200件の売れ筋商品データを収集し、mockData.tsに追加するスクリプト (Multi-page support)
 * 
 * 取得カテゴリ目標 (合計200件):
 * - sofa (40件)
 * - chair (40件)
 * - table (40件)
 * - bed (25件)
 * - storage (25件)
 * - tv-board (15件)
 * - desk (15件)
 */

const fs = require('fs');
const https = require('https');

// ──────────────────────────────────────────────────────
// HTTPSフェッチ（Promiseラッパー）
// ──────────────────────────────────────────────────────
function fetchUrl(url) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml',
        'Accept-Language': 'ja,en-US;q=0.9,en;q=0.8',
      },
      timeout: 15000,
    }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return resolve(fetchUrl(res.headers.location));
      }
      
      let data = '';
      res.setEncoding('utf8');
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve({ status: res.statusCode, body: data }));
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
  });
}

// ──────────────────────────────────────────────────────
// __PRODUCTS__ JSON の抽出
// ──────────────────────────────────────────────────────
function extractProductsJson(html) {
  const marker = 'window.__PRODUCTS__ = ';
  const idx = html.indexOf(marker);
  if (idx === -1) return null;
  
  const jsonStart = html.indexOf('{', idx + marker.length);
  if (jsonStart === -1) return null;
  
  let depth = 0;
  let inStr = false;
  let strCh = '';
  let jsonEnd = -1;
  
  for (let i = jsonStart; i < html.length; i++) {
    const ch = html[i];
    if (inStr) {
      if (ch === '\\') { i++; continue; }
      if (ch === strCh) inStr = false;
      continue;
    }
    if (ch === '"' || ch === "'") { inStr = true; strCh = ch; continue; }
    if (ch === '{' || ch === '[') depth++;
    else if (ch === '}' || ch === ']') {
      depth--;
      if (depth === 0) { jsonEnd = i; break; }
    }
  }
  
  if (jsonEnd === -1) return null;
  
  try {
    const jsonStr = html.substring(jsonStart, jsonEnd + 1);
    return JSON.parse(jsonStr);
  } catch (e) {
    console.error('JSON parse error:', e.message);
    return null;
  }
}

// ──────────────────────────────────────────────────────
// カテゴリ設定 (合計 200件)
// ──────────────────────────────────────────────────────
const CATEGORIES = [
  { name: 'sofa',    jpName: 'ソファ',         baseUrl: 'https://flymee.jp/category/sofa/',    target: 40, room: 'living',  taste: 'minimal' },
  { name: 'chair',   jpName: 'チェア・椅子',   baseUrl: 'https://flymee.jp/category/chair/',   target: 40, room: 'dining',  taste: 'minimal' },
  { name: 'table',   jpName: 'テーブル',       baseUrl: 'https://flymee.jp/category/table/',   target: 40, room: 'dining',  taste: 'minimal' },
  { name: 'bed',     jpName: 'ベッド',         baseUrl: 'https://flymee.jp/category/bed/',     target: 25, room: 'bedroom', taste: 'hotel' },
  { name: 'storage', jpName: '収納家具',       baseUrl: 'https://flymee.jp/category/storage/', target: 25, room: 'living',  taste: 'minimal' },
  { name: 'tv-board',jpName: 'テレビボード',   baseUrl: 'https://flymee.jp/category/tv-board/',target: 15, room: 'living',  taste: 'minimal' },
  { name: 'desk',    jpName: 'デスク・机',     baseUrl: 'https://flymee.jp/category/desk/',    target: 15, room: 'study',   taste: 'minimal' },
];

function getPriceRangeId(price) {
  if (price < 100000) return 'under10';
  if (price < 200000) return '10to20';
  if (price < 400000) return '20to40';
  return 'over40';
}

function inferTaste(productName, brandName) {
  const text = (productName + ' ' + brandName).toLowerCase();
  if (/北欧|nordic|scandinavian|muuto|hay|fritz hansen|&tradition/i.test(text)) return 'nordic';
  if (/vintage|industrial|crash gate|journal standard|a\.depeche/i.test(text)) return 'vintage';
  if (/hotel|luxury|minotti|boconcept|ligne roset|cassina|b&b italia|flexform/i.test(text)) return 'hotel';
  return 'minimal';
}

function makeProductBlock(item, catConfig, index) {
  const safeStr = str => (str || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/\n/g, ' ').replace(/\r/g, '');
  
  const productId = item.product_id;
  const imgPath = item.img_path || '';
  const imageUrl = imgPath ? `https://static2.flymee.jp/${imgPath}` : 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1200&q=90';
  const productUrl = item.url || `https://flymee.jp/product/${productId}/`;
  const brandName = item.brand_shop_name || 'FLYMEe';
  const price = item.min_price || 100000;
  const priceRangeId = getPriceRangeId(price);
  const taste = inferTaste(item.name, brandName);
  const category = catConfig.name;
  const room = catConfig.room;
  
  const catDescMap = {
    'sofa': `${brandName}のデザイナーズソファ。スタイリッシュな空間を演出する人気モデル`,
    'chair': `${brandName}の洗練されたチェア。座り心地と美しさを両立したデザイン`,
    'table': `${brandName}の高品質テーブル。素材と造形美が際立つ空間の主役`,
    'bed': `${brandName}のプレミアムベッドフレーム。上質な眠りを約束する美しい設計`,
    'storage': `${brandName}の収納家具。機能美と洗練されたフォルムで空間を整える`,
    'tv-board': `${brandName}のテレビボード。リビングを美しく格上げする収納デザイン`,
    'desk': `${brandName}の上質デスク。集中と創造を高める洗練されたワークスペース`,
  };
  
  const subtitle = catDescMap[category] || `${brandName}の人気商品`;
  
  const descMap = {
    'sofa': `FLYMEeで人気の${brandName}製ソファ。高品質な素材と優れたデザインで、リビングを格別な空間へと変える。機能性と美しさを兼ね備えた、こだわりのある方への一脚。`,
    'chair': `${brandName}の人気チェア。エルゴノミクス設計と洗練されたフォルムが、毎日の生活に快適さと美しさをもたらす。FLYMEeで選ばれる理由がここにある。`,
    'table': `${brandName}の人気テーブル。厳選された素材と精緻な仕上げが、食卓や作業空間に高級感をもたらす。FLYMEeの中でも特に人気のモデル。`,
    'bed': `${brandName}の人気ベッドフレーム。上質な素材と美しいデザインが、毎夜の睡眠を特別な体験へ。心地よく目覚める朝を叶えてくれる。`,
    'storage': `${brandName}の収納家具。インテリアに溶け込む洗練されたデザインで、整理整頓をスタイリッシュに実現する。`,
    'tv-board': `${brandName}のテレビボード。リビングのフォーカルポイントになる洗練されたデザインで、電子機器も美しく収納。`,
    'desk': `${brandName}の人気デスク。仕事や勉強の質を高める洗練された作業スペース。素材と設計のこだわりが集中力をサポートする。`,
  };
  
  const description = descMap[category] || `${brandName}の人気商品。FLYMEeで高評価を得ている洗練されたデザイン。`;
  
  const matsMap = {
    'sofa': ['高品質ファブリック / 本革 / ウッドフレーム'],
    'chair': ['成形合板 / スチール / ファブリック / 本革'],
    'table': ['天然木無垢材 / セラミック / ガラス / スチール'],
    'bed': ['天然木 / メタルフレーム / 本革 / ファブリック'],
    'storage': ['天然木突板 / スチール / ガラス扉'],
    'tv-board': ['天然木 / MDF / スチール'],
    'desk': ['天然木 / スチール / ガラス'],
  };
  
  const materials = matsMap[category] || ['天然木 / スチール'];
  const matsStr = materials.map(m => `'${safeStr(m)}'`).join(', ');
  
  const tagsMap = {
    'sofa': ['フライミー', 'FLYMEe', brandName, 'ソファ', 'デザイナーズソファ'],
    'chair': ['フライミー', 'FLYMEe', brandName, 'チェア', 'デザイナーズチェア'],
    'table': ['フライミー', 'FLYMEe', brandName, 'テーブル', 'ダイニングテーブル'],
    'bed': ['フライミー', 'FLYMEe', brandName, 'ベッド', 'ベッドフレーム'],
    'storage': ['フライミー', 'FLYMEe', brandName, '収納', 'シェルフ'],
    'tv-board': ['フライミー', 'FLYMEe', brandName, 'テレビボード', 'TVボード'],
    'desk': ['フライミー', 'FLYMEe', brandName, 'デスク', 'ワークデスク'],
  };
  
  const tags = tagsMap[category] || ['フライミー', 'FLYMEe', brandName];
  const tagsStr = tags.map(t => `'${safeStr(t)}'`).join(', ');
  
  const rating = (4.85 + (index % 12) * 0.01).toFixed(2);
  const reviewCount = 15 + (index * 7 % 80);
  
  const id = `fm2-${category.replace('-', '')}-${productId}`;
  
  return `  {
    id: '${id}',
    name: '${safeStr(item.name)}',
    subtitle: '${safeStr(subtitle)}',
    brand: 'FLYMEe',
    partnerBrandId: 'flymee',
    category: '${category}',
    taste: '${taste}',
    room: '${room}',
    price: ${price},
    priceRangeId: '${priceRangeId}',
    rating: ${rating},
    reviewCount: ${reviewCount},
    images: ['${imageUrl}'],
    description: '${safeStr(description)}',
    materials: [${matsStr}],
    dimensions: 'W600〜2400 × D600〜900 × H350〜2100 mm（商品により異なる）',
    color: 'ブラック / ホワイト / グレー / ナチュラル（カラーバリエーションあり）',
    sizeCategory: '${safeStr(catConfig.jpName)}',
    tags: [${tagsStr}],
    editorialComment: 'FLYMEeが誇る${safeStr(brandName)}の人気モデル。洗練されたデザインと高品質な素材が選ばれ続ける理由。',
    pros: ['洗練されたデザイン性', '高品質な素材と仕上げ', 'FLYMEeで高評価'],
    cons: ['配送・設置に特別手配が必要な場合あり'],
    targetUser: '本物のデザイナーズ家具で空間を格上げしたいこだわりのある方',
    shopLinks: [
      {
        name: 'FLYMEe 公式ストア',
        label: 'FLYMEe公式オンラインショップで見る',
        price: ${price},
        url: '${safeStr(productUrl)}',
        isOfficial: true,
      },
    ],
    isTopRanked: ${index < 5},
    isEditorsPick: ${price >= 200000 && index < 10},
    isNewArrival: false,
  }`;
}

function extractObjectBlocks(text) {
  const blocks = [];
  let depth = 0, inStr = false, strCh = '', objStart = -1, i = 0;
  while (i < text.length) {
    const ch = text[i];
    if (inStr) {
      if (ch === '\\') { i += 2; continue; }
      if (ch === strCh) inStr = false;
      i++; continue;
    }
    if (ch === '"' || ch === "'") { inStr = true; strCh = ch; i++; continue; }
    if (ch === '{') { if (depth === 0) objStart = i; depth++; }
    else if (ch === '}') { depth--; if (depth === 0 && objStart >= 0) { blocks.push(text.substring(objStart, i+1)); objStart = -1; } }
    i++;
  }
  return blocks;
}

function extractField(block, field) {
  const re = new RegExp(`${field}:\\s*'([^']*)'`);
  const m = block.match(re);
  return m ? m[1] : '';
}

async function main() {
  console.log('Starting FLYMEe product scraping for exactly 200 items...\n');
  
  const allScrapedProducts = [];
  const globalSeenIds = new Set();
  
  for (const catConfig of CATEGORIES) {
    console.log(`\nFetching category: ${catConfig.name} (target: ${catConfig.target})...`);
    let page = 1;
    let catCollected = 0;
    
    while (catCollected < catConfig.target && page <= 5) {
      const pageUrl = page === 1 ? catConfig.baseUrl : `${catConfig.baseUrl}${page}/`;
      console.log(`  Fetching page ${page}: ${pageUrl}`);
      
      try {
        const resp = await fetchUrl(pageUrl);
        if (resp.status !== 200) {
          console.error(`  HTTP ${resp.status} on page ${page}`);
          break;
        }
        
        const productsData = extractProductsJson(resp.body);
        if (!productsData || !productsData.data || productsData.data.length === 0) {
          console.log(`  No more product data on page ${page}`);
          break;
        }
        
        let newInPage = 0;
        for (const item of productsData.data) {
          if (!globalSeenIds.has(item.product_id)) {
            globalSeenIds.add(item.product_id);
            const block = makeProductBlock(item, catConfig, catCollected);
            allScrapedProducts.push(block);
            catCollected++;
            newInPage++;
            
            if (catCollected >= catConfig.target) break;
          }
        }
        
        console.log(`    Added ${newInPage} new items (Category Total: ${catCollected}/${catConfig.target})`);
        page++;
        await new Promise(r => setTimeout(r, 800));
        
      } catch (err) {
        console.error(`  Error fetching ${pageUrl}:`, err.message);
        break;
      }
    }
  }
  
  console.log('\n=== Scraping Summary ===');
  console.log('Total FLYMEe products collected:', allScrapedProducts.length);
  
  const catDist = {};
  for (const block of allScrapedProducts) {
    const cat = extractField(block, 'category');
    catDist[cat] = (catDist[cat] || 0) + 1;
  }
  console.log('Category distribution:', catDist);
  
  if (allScrapedProducts.length === 0) {
    console.error('ERROR: No products collected, aborting');
    process.exit(1);
  }
  
  // mockData.ts を更新
  const content = fs.readFileSync('src/data/mockData.ts', 'utf8');
  const prodMarker = 'export const PRODUCTS: Product[] = [';
  const prodMarkerIdx = content.indexOf(prodMarker);
  const prodArrayStartIdx = prodMarkerIdx + prodMarker.length - 1;
  
  let depth = 0, inStr = false, strCh = '', prodArrayEndIdx = -1, pi = prodArrayStartIdx;
  while (pi < content.length) {
    const ch = content[pi];
    if (inStr) { if (ch === '\\') { pi += 2; continue; } if (ch === strCh) inStr = false; pi++; continue; }
    if (ch === '"' || ch === "'") { inStr = true; strCh = ch; pi++; continue; }
    if (ch === '[') depth++;
    else if (ch === ']') { depth--; if (depth === 0) { prodArrayEndIdx = pi; break; } }
    pi++;
  }
  
  const headerSection = content.substring(0, prodMarkerIdx);
  const footerSection = content.substring(prodArrayEndIdx + 1);
  const productsInner = content.substring(prodArrayStartIdx + 1, prodArrayEndIdx);
  
  const existingBlocks = extractObjectBlocks(productsInner);
  console.log('Existing total products in mockData:', existingBlocks.length);
  
  // 既存のFLYMEeブランド商品をすべて置き換え (新しい200点にする)
  const nonFlymeeBlocks = existingBlocks.filter(b => extractField(b, 'partnerBrandId') !== 'flymee');
  console.log('Non-FLYMEe products kept:', nonFlymeeBlocks.length);
  
  const finalBlocks = [...nonFlymeeBlocks, ...allScrapedProducts];
  console.log(`\nFinal total product count: ${finalBlocks.length} (FLYMEe: ${allScrapedProducts.length})`);
  
  const finalCatDist = {};
  const finalBrandDist = {};
  for (const b of finalBlocks) {
    const cat = extractField(b, 'category');
    const brand = extractField(b, 'partnerBrandId');
    finalCatDist[cat] = (finalCatDist[cat] || 0) + 1;
    finalBrandDist[brand] = (finalBrandDist[brand] || 0) + 1;
  }
  console.log('Final categories:', finalCatDist);
  console.log('Final brands:', finalBrandDist);
  
  const newContent = headerSection + prodMarker + '\n' + finalBlocks.join(',\n') + '\n]' + footerSection;
  const count = (newContent.match(/partnerBrandId:/g) || []).length;
  console.log('\nProducts in new file:', count);
  
  fs.writeFileSync('src/data/mockData.ts', newContent);
  console.log('✓ mockData.ts updated with exactly 200 FLYMEe products!');
}

main().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
