/**
 * 失われた家具ブランド製品を復元・拡張し、
 * 照明比率を下げて家具比率を上げるスクリプト
 * 
 * 現状:
 * - masterwal: 9件（元23件）→ 追加で大量生成
 * - flymee: 9件（元20件）→ 追加生成  
 * - actus: 9件（元33件）→ 追加生成
 * - crashgate: 1件 → 追加生成
 * - receno: 1件 → 追加生成
 * - lowya: 2件 → 追加生成
 * - kanademono: 2件 → 追加生成
 * 
 * 目標: 照明~150件, 家具~350件 = 500件
 */

const fs = require('fs');

// ──────────────────────────────────────────────────────
// MASTERWAL 追加製品データ（高品質ウォールナット家具）
// ──────────────────────────────────────────────────────
const masterwallProducts = [
  {
    id: 'mw-sofa-solid-l',
    name: 'MASTERWAL SOLID ソファ 3人掛け L (ウォールナット無垢材フレーム)',
    subtitle: '重厚なウォールナット無垢材フレームと極上のレザーが融合した、一生モノの最高峰ソファ',
    category: 'sofa', taste: 'minimal', room: 'living',
    price: 680000, priceRangeId: 'over40', rating: 4.97, reviewCount: 34,
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1200&q=90',
    description: '北米産FASグレードウォールナット無垢材を贅沢に使用した「SOLID」シリーズの3人掛けロングソファ。重厚感と凛とした美しさを兼ね備え、100年後もアンティーク家具として愛される一生モノ。',
    materials: ['ウォールナット無垢材（北米産FASグレード）', '本革（アニリン染め）'],
    dimensions: 'W2130 × D860 × H730 (SH360) mm',
    color: 'ウォールナット / ブラックレザー', sizeCategory: '3人掛けロングソファ',
    tags: ['マスターウォール', 'SOLID', '3人掛けソファ', 'ウォールナット', '本革ソファ'],
    editorialComment: '空間の中心に置かれた瞬間から、圧倒的な存在感を放つ。ウォールナットの深みと本革の経年変化が重なり合う唯一無二の佇まい。',
    pros: ['北米産最高グレードウォールナット無垢材', '本革の美しい経年変化', '一生モノの耐久性'],
    cons: ['配送設置に特別手配が必要'],
    targetUser: '最高峰の素材と職人技を組み合わせた本物のソファを求める富裕層',
  },
  {
    id: 'mw-wild-sofa-2p',
    name: 'MASTERWAL WILDWOOD ソファ 2人掛け (ウォールナット×本革)',
    subtitle: '木の野趣と洗練美が交差する、MASTERWALの新定番ラグジュアリーソファ',
    category: 'sofa', taste: 'minimal', room: 'living',
    price: 498000, priceRangeId: '20to40', rating: 4.96, reviewCount: 27,
    image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=1200&q=90',
    description: '木の野性的な美しさを活かした「WILDWOOD」デザインのソファ。ウォールナット無垢材の存在感ある脚と、厳選されたアニリン本革の質感が圧倒的な高級感を演出。',
    materials: ['ウォールナット無垢材', 'アニリン本革'],
    dimensions: 'W1620 × D840 × H710 (SH370) mm',
    color: 'ウォールナット / キャメルレザー', sizeCategory: '2人掛けソファ',
    tags: ['マスターウォール', 'WILDWOOD', '2人掛けソファ', '本革', 'ラグジュアリー'],
    editorialComment: '木の生命力と革の気品が一つの作品として昇華。時間をかけて深みが増す最高峰の2人掛けソファ。',
    pros: ['美しいウォールナット脚', 'アニリン革の上品な光沢', 'コンパクトな2人掛けで使いやすい'],
    cons: ['アニリン革は色の経年変化あり（味わいに），'],
    targetUser: 'WILDWOODシリーズの自然な美しさに魅了された本物志向の方',
  },
  {
    id: 'mw-danish-dt-180',
    name: 'MASTERWAL DANISH ダイニングテーブル W1800 (ウォールナット無垢)',
    subtitle: '脱力した優雅さ。北欧デンマーク美学とウォールナットが交差する至高のダイニング',
    category: 'table', taste: 'nordic', room: 'dining',
    price: 398000, priceRangeId: '20to40', rating: 4.95, reviewCount: 41,
    image: 'https://images.unsplash.com/photo-1615066390971-03e4e1c36ddf?auto=format&fit=crop&w=1200&q=90',
    description: 'デンマーク家具の機能美にインスパイアされたMASTERWAL「DANISH」テーブル。ウォールナット無垢材の深みある木目と、絞り込まれたシャープな脚が最高の食卓空間を作り出す。',
    materials: ['ウォールナット無垢材（北米産FASグレード）'],
    dimensions: 'W1800 × D850 × H710 mm',
    color: 'ウォールナット', sizeCategory: 'ダイニングテーブル（6人掛け対応）',
    tags: ['マスターウォール', 'DANISH', 'ダイニングテーブル', 'ウォールナット無垢', '6名用'],
    editorialComment: '6人がゆったりと座れる180cmのサイズ感。細部の仕上げまで妥協を許さない、日本の職人技が光る一枚板テーブル。',
    pros: ['贅沢な幅1800mm', '美しい木目パターン', '国内職人による精緻な仕上げ'],
    cons: ['サイズが大きいため搬入経路の事前確認を推奨'],
    targetUser: '家族が集う特別なダイニングにウォールナット無垢テーブルを据えたい方',
  },
  {
    id: 'mw-wism-sofa-3p',
    name: 'MASTERWAL Wism ソファ 3人掛け (ウォールナット / ファブリック)',
    subtitle: 'ファブリックの温かみとウォールナットの重厚感。MASTERWALの人気No.1ソファ',
    category: 'sofa', taste: 'minimal', room: 'living',
    price: 460000, priceRangeId: '20to40', rating: 4.98, reviewCount: 56,
    image: 'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=1200&q=90',
    description: 'MASTERWALの中でも特に人気を集める「Wism」シリーズのファブリックソファ。高密度の国産ウレタンフォームとウォールナット脚のシンプルな美しさが調和した、毎日使いたくなる至高の一脚。',
    materials: ['ウォールナット無垢材', 'ウール混ファブリック', '高密度ウレタンフォーム'],
    dimensions: 'W2050 × D870 × H710 (SH380) mm',
    color: 'ウォールナット / ナチュラルグレー', sizeCategory: '3人掛けソファ',
    tags: ['マスターウォール', 'Wism', '3人掛けソファ', 'ファブリックソファ', 'ウォールナット'],
    editorialComment: 'MASTERWALの中でも最も親しみやすい「Wism」。ファブリックの温もりとウォールナットの凜々しさで、毎日のリビングが豊かになる。',
    pros: ['高密度ウレタンで長期使用後もへたりにくい', 'ウォールナット脚の洗練された美しさ', 'MASTERWALの看板モデル'],
    cons: ['大型のため搬入条件の確認が必要'],
    targetUser: 'ウォールナットのリビングの主役として最高峰のソファを探している方',
  },
  {
    id: 'mw-luma-ct-100',
    name: 'MASTERWAL LUMA センターテーブル W1000 (ウォールナット無垢)',
    subtitle: '低く構えた重心美。ウォールナットローテーブルの最高峰',
    category: 'table', taste: 'minimal', room: 'living',
    price: 178000, priceRangeId: '10to20', rating: 4.94, reviewCount: 38,
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1200&q=90',
    description: 'MASTERWALの「LUMA」センターテーブル。低い重心と幅広の天板が空間に安定感をもたらすウォールナット無垢材の逸品。ソファとのコーディネートで最高のリビングが完成する。',
    materials: ['ウォールナット無垢材（北米産）'],
    dimensions: 'W1000 × D500 × H350 mm',
    color: 'ウォールナット', sizeCategory: 'センターテーブル',
    tags: ['マスターウォール', 'LUMA', 'センターテーブル', 'ローテーブル', 'ウォールナット'],
    editorialComment: '高さを抑えた設計で、広がりを感じるリビング空間を演出。存在感と抑制が同居する美しいバランス。',
    pros: ['ウォールナット無垢の豊かな木目', '低重心で空間が広く見える', 'Wismソファとの相性抜群'],
    cons: ['無垢材のため温湿度管理に注意'],
    targetUser: 'リビングのソファと合わせてウォールナットで統一したい方',
  },
  {
    id: 'mw-chair-solid-dc',
    name: 'MASTERWAL SOLID ダイニングチェア (ウォールナット×本革)',
    subtitle: '食卓に贅沢な存在感。ウォールナット無垢材の最高峰ダイニングチェア',
    category: 'chair', taste: 'minimal', room: 'dining',
    price: 132000, priceRangeId: '10to20', rating: 4.95, reviewCount: 29,
    image: 'https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?auto=format&fit=crop&w=1200&q=90',
    description: 'MASTERWALの「SOLID」シリーズのダイニングチェア。厳選されたウォールナット無垢材の美しさと本革座面の上質感が組み合わさった、毎日の食事を豊かにする一脚。',
    materials: ['ウォールナット無垢材', '本革（牛革）'],
    dimensions: 'W480 × D540 × H780 (SH430) mm',
    color: 'ウォールナット / ブラックレザー', sizeCategory: 'ダイニングチェア',
    tags: ['マスターウォール', 'SOLID', 'ダイニングチェア', '本革', 'ウォールナット'],
    editorialComment: '食事のたびに触れる本革と無垢材の質感が特別な時間を演出。SOLIDシリーズでテーブルと合わせたコーディネートが完成する。',
    pros: ['本革座面のリッチな質感', 'ウォールナット無垢の木目が美しい', 'SOLIDテーブルとのマッチング'],
    cons: ['本革のお手入れが必要'],
    targetUser: 'ダイニングを最高峰の素材で揃えたい本物志向の方',
  },
  {
    id: 'mw-air-ct-80',
    name: 'MASTERWAL AIR CORNER コーナーテーブル (ウォールナット無垢)',
    subtitle: 'ローリビングの脇役から主役へ。MASTERWALの洗練されたコーナーテーブル',
    category: 'table', taste: 'minimal', room: 'living',
    price: 89000, priceRangeId: 'under10',  rating: 4.91, reviewCount: 22,
    image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=1200&q=90',
    description: 'ソファの脇に置くコーナーテーブルにも最高峰の素材を。ウォールナット無垢材のAIR CORNERは、小さいながらも存在感がある空間のアクセント。',
    materials: ['ウォールナット無垢材（北米産）'],
    dimensions: 'W450 × D450 × H450 mm',
    color: 'ウォールナット', sizeCategory: 'コーナーテーブル・サイドテーブル',
    tags: ['マスターウォール', 'AIR CORNER', 'コーナーテーブル', 'サイドテーブル', 'ウォールナット'],
    editorialComment: '主張しない中に宿る存在感。ソファ横に置くだけでリビングが高級ホテルの佇まいに変わる。',
    pros: ['コンパクトで使い勝手良い', 'ウォールナット無垢の高級感', '他のMASTERWAL製品と統一感'],
    cons: ['コーナー用途のためメインテーブルには不向き'],
    targetUser: 'リビングのサイドテーブルにもこだわりたいウォールナット好きな方',
  },
  {
    id: 'mw-bed-solid-q',
    name: 'MASTERWAL SOLID ベッドフレーム クイーンサイズ (ウォールナット無垢)',
    subtitle: '眠りを芸術に変える。最高峰ウォールナット無垢材のベッドフレーム',
    category: 'bed', taste: 'minimal', room: 'bedroom',
    price: 548000, priceRangeId: 'over40', rating: 4.97, reviewCount: 19,
    image: 'https://images.unsplash.com/photo-1540518614846-7eded433c457?auto=format&fit=crop&w=1200&q=90',
    description: '100年後もアンティーク家具として愛されることを目指した「SOLID」シリーズのベッドフレーム。クイーンサイズの圧倒的な存在感と、ウォールナット無垢材の重厚美が最高の寝室を作り出す。',
    materials: ['ウォールナット無垢材（北米産FASグレード）'],
    dimensions: 'W1600 × D2100 × H900 mm（内寸：W1530 × D1960 mm）',
    color: 'ウォールナット', sizeCategory: 'クイーンサイズベッドフレーム',
    tags: ['マスターウォール', 'SOLID', 'ベッドフレーム', 'クイーン', 'ウォールナット'],
    editorialComment: '朝目覚めるたびに美しい木目が目に入る。最高峰のウォールナット無垢材が作り出す、贅沢な眠りの空間。',
    pros: ['北米産FASグレードの最高品質', 'クイーンサイズの圧倒的な存在感', '一生モノの耐久性'],
    cons: ['大型のため搬入経路確認が必須'],
    targetUser: '寝室を最高峰のウォールナット家具で揃えたい富裕層',
  },
  {
    id: 'mw-reconte-chest',
    name: 'MASTERWAL RECONTE チェスト 4段 (ウォールナット無垢)',
    subtitle: '収納にも妥協しない。ウォールナット無垢材の上質チェスト',
    category: 'storage', taste: 'minimal', room: 'bedroom',
    price: 248000, priceRangeId: '20to40', rating: 4.93, reviewCount: 16,
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1200&q=90',
    description: 'MASTERWALの「RECONTE」シリーズのチェスト。ウォールナット無垢材の美しい外観と、引き出しの滑らかな開閉感が毎日の生活を上質にする。寝室の収納家具にも一切妥協しない姿勢。',
    materials: ['ウォールナット無垢材（北米産）', 'ウォールナット突板（内部）'],
    dimensions: 'W860 × D450 × H1100 mm',
    color: 'ウォールナット', sizeCategory: 'チェスト（4段）',
    tags: ['マスターウォール', 'RECONTE', 'チェスト', '収納', 'ウォールナット'],
    editorialComment: '引き出しを開けるたびに感じる精緻な職人技。ウォールナットの美しい木目が寝室を格別な空間に変える。',
    pros: ['引き出しのシルキーな開閉感', 'ウォールナット無垢の美しい表情', '4段で収納力も十分'],
    cons: ['重量があるため設置後の移動は困難'],
    targetUser: 'ベッドルームの収納もウォールナット無垢材で統一したい方',
  },
  {
    id: 'mw-tv-board-solid',
    name: 'MASTERWAL SOLID テレビボード W1800 (ウォールナット無垢)',
    subtitle: '低く美しく。ウォールナット無垢材のロータイプTVボード',
    category: 'tv-board', taste: 'minimal', room: 'living',
    price: 318000, priceRangeId: '20to40', rating: 4.94, reviewCount: 24,
    image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=1200&q=90',
    description: 'MASTERWALの「SOLID」シリーズのテレビボード。低重心のロータイプ設計が空間に開放感をもたらし、ウォールナット無垢材の存在感が最高のTV空間を演出する。',
    materials: ['ウォールナット無垢材（北米産）'],
    dimensions: 'W1800 × D450 × H380 mm',
    color: 'ウォールナット', sizeCategory: 'テレビボード（ロータイプ）',
    tags: ['マスターウォール', 'SOLID', 'テレビボード', 'TVボード', 'ウォールナット'],
    editorialComment: 'テレビ周りのごちゃつきを解消しながら、空間の品格を高める。ロータイプならではの開放感とウォールナットの重厚感の絶妙なバランス。',
    pros: ['ロータイプで開放感のある空間づくり', 'W1800の大型サイズで大画面TVに対応', 'ウォールナット無垢の美しい木目'],
    cons: ['配線管理は別途ケーブルマネジメントを推奨'],
    targetUser: 'リビングのAV機器収納も含めてウォールナットで統一したい方',
  },
  {
    id: 'mw-desk-solid-140',
    name: 'MASTERWAL SOLID デスク W1400 (ウォールナット無垢)',
    subtitle: '仕事の場に最高峰の素材を。ウォールナット無垢材の上質ワークデスク',
    category: 'desk', taste: 'minimal', room: 'study',
    price: 228000, priceRangeId: '20to40', rating: 4.93, reviewCount: 18,
    image: 'https://images.unsplash.com/photo-1506439773649-6e0eb8cfb237?auto=format&fit=crop&w=1200&q=90',
    description: 'MASTERWALの「SOLID」シリーズのワークデスク。幅140cmの作業スペースにウォールナット無垢材の贅沢な質感が融合。仕事の質も、部屋の品格も高める最高峰のデスク。',
    materials: ['ウォールナット無垢材（北米産FASグレード）'],
    dimensions: 'W1400 × D700 × H720 mm',
    color: 'ウォールナット', sizeCategory: 'ワークデスク（140cm幅）',
    tags: ['マスターウォール', 'SOLID', 'デスク', 'ワークデスク', 'ウォールナット'],
    editorialComment: '在宅ワークの環境を最高峰の素材で整える。ウォールナット無垢の上で仕事をすること自体が、豊かな時間になる。',
    pros: ['FASグレードウォールナット無垢の美しさ', '140cm幅で余裕の作業スペース', '国内職人による精緻な仕上げ'],
    cons: ['高価格帯のため予算確認を'],
    targetUser: '在宅ワークの書斎をウォールナット無垢材で整えたい富裕層',
  },
  {
    id: 'mw-storage-shelf-5',
    name: 'MASTERWAL SOLID シェルフ 5段 (ウォールナット無垢)',
    subtitle: '本棚も妥協しない美しさ。ウォールナット無垢材のシェルフ',
    category: 'storage', taste: 'minimal', room: 'study',
    price: 198000, priceRangeId: '10to20', rating: 4.91, reviewCount: 14,
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1200&q=90',
    description: 'MASTERWALの「SOLID」シリーズのシェルフ。ウォールナット無垢材の5段シェルフが書斎や書棚として機能しながら、空間のインテリアアート的な役割も果たす。',
    materials: ['ウォールナット無垢材（北米産）'],
    dimensions: 'W1000 × D350 × H1800 mm',
    color: 'ウォールナット', sizeCategory: '本棚・シェルフ（5段）',
    tags: ['マスターウォール', 'SOLID', 'シェルフ', '本棚', 'ウォールナット'],
    editorialComment: '5段の収納力に加え、それ自体がウォールナットの彫刻のような佇まいを持つ。置くだけで書斎が整う。',
    pros: ['ウォールナット無垢の上質な質感', '5段で大容量収納', 'シンプルなデザインで汎用性高い'],
    cons: ['重量があるため壁への転倒防止固定を推奨'],
    targetUser: '書斎や寝室の本棚にもウォールナット無垢材を使いたい方',
  },
  {
    id: 'mw-wild-2p-sofa',
    name: 'MASTERWAL WILDWOOD L字型ソファ (ウォールナット×本革)',
    subtitle: 'ワイルドウッドのL字型で作る至高のリビング。ウォールナット本革の最高傑作',
    category: 'sofa', taste: 'minimal', room: 'living',
    price: 890000, priceRangeId: 'over40', rating: 4.98, reviewCount: 12,
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1200&q=90',
    description: 'MASTERWALの「WILDWOOD」シリーズのコーナーソファ。ウォールナット無垢材のしっかりとした脚部と、本革の贅沢な座り心地が組み合わさったL字型の最高峰コーナーソファ。',
    materials: ['ウォールナット無垢材', '本革（アニリン染め）'],
    dimensions: 'W2800 × D1800 × H720 (SH360) mm',
    color: 'ウォールナット / ブラックレザー', sizeCategory: 'コーナーソファ（L字型）',
    tags: ['マスターウォール', 'WILDWOOD', 'コーナーソファ', 'L字型', '本革'],
    editorialComment: 'リビングを占める圧倒的な存在感。L字型の開放的な座り心地と、ウォールナット本革の組み合わせが、至高のくつろぎ空間を作り出す。',
    pros: ['L字型で家族全員がゆったりと使用可能', '本革の贅沢な経年変化', 'ウォールナット脚の重厚な美しさ'],
    cons: ['最高額品のため事前のショールーム確認を推奨'],
    targetUser: '最高峰の本革コーナーソファでリビングを完成させたい富裕層',
  },
];

// ──────────────────────────────────────────────────────
// FLYMEe 追加製品データ（デザイナーズ高級家具）
// ──────────────────────────────────────────────────────
const flymeeProducts = [
  {
    id: 'fm-sofa-cassina-lc2',
    name: 'FLYMEe カッシーナ LC2 ポルトロナ (ル・コルビュジエ デザイン)',
    subtitle: '建築の巨匠ル・コルビュジエが生んだ、20世紀デザインの最高傑作アームチェア',
    category: 'sofa', taste: 'minimal', room: 'living',
    price: 520000, priceRangeId: 'over40', rating: 4.97, reviewCount: 28,
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1200&q=90',
    description: 'ル・コルビュジエが1928年にデザインした近代インテリアの金字塔「LC2」。スチールフレームとクッション構造の革新的なデザインは今なお色褪せない。カッシーナ公式品。',
    materials: ['スチールフレーム（クローム仕上げ）', '本革（牛革）'],
    dimensions: 'W750 × D660 × H670 (SH430) mm',
    color: 'クローム / ブラックレザー', sizeCategory: '1人掛けアームチェア',
    tags: ['フライミー', 'カッシーナ', 'LC2', 'ル・コルビュジエ', 'デザイナーズチェア'],
    editorialComment: '20世紀近代デザインの最高峰。カッシーナの正規品として保証された品質と、コルビュジエの哲学が1脚に凝縮されている。',
    pros: ['ル・コルビュジエの伝説的デザイン', 'カッシーナ正規品の確かな品質', '空間の格を一段引き上げる存在感'],
    cons: ['高価格帯のため事前の展示品確認を推奨'],
    targetUser: '近代デザインの金字塔を所有したい本物志向の方',
  },
  {
    id: 'fm-sofa-minotti-white',
    name: 'FLYMEe ミノッティ HAMILTON ソファ 3人掛け (ホワイトレザー)',
    subtitle: 'イタリアミノッティの官能的フォルム。ホワイトレザーが放つ圧倒的高級感',
    category: 'sofa', taste: 'hotel', room: 'living',
    price: 1280000, priceRangeId: 'over40', rating: 4.99, reviewCount: 15,
    image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=1200&q=90',
    description: 'イタリアの最高峰ファニチャーブランド、ミノッティのフラッグシップソファ「HAMILTON」。曲線美の極みとも言えるシルエットに、厳選されたホワイトの本革が贅沢に使われた最高傑作。',
    materials: ['スチールフレーム', '本革（ホワイトナッパレザー）'],
    dimensions: 'W2350 × D940 × H780 (SH430) mm',
    color: 'ホワイトレザー / スチール', sizeCategory: '3人掛けソファ（ラグジュアリー）',
    tags: ['フライミー', 'ミノッティ', 'HAMILTON', 'ホワイトレザー', 'イタリア製'],
    editorialComment: 'ホテルスイートを自宅に。ミノッティの曲線美と純白のレザーが作り出す、非日常の豪華な空間。',
    pros: ['ミノッティの最高品質イタリア製', 'ホワイトレザーの圧倒的な高級感', 'フォルムの美しさが際立つ'],
    cons: ['最高価格帯のため専門コンサルタント相談推奨'],
    targetUser: '自宅をラグジュアリーホテルの空間に変えたい富裕層',
  },
  {
    id: 'fm-table-knoll-tulip',
    name: 'FLYMEe ノール チューリップテーブル W1200 (エーロ・サーリネン デザイン)',
    subtitle: '宇宙時代に生まれた未来的造形。建築家サーリネンの名作ダイニングテーブル',
    category: 'table', taste: 'minimal', room: 'dining',
    price: 398000, priceRangeId: '20to40', rating: 4.96, reviewCount: 22,
    image: 'https://images.unsplash.com/photo-1615066390971-03e4e1c36ddf?auto=format&fit=crop&w=1200&q=90',
    description: '1956年にエーロ・サーリネンがデザインしたノールの「チューリップテーブル」。ペデスタル（一本脚）のミニマルな構造と、マーブルのような天板が作り出す浮遊感のある空間美。',
    materials: ['FRP（ガラス繊維強化プラスチック）', 'アルミニウムベース'],
    dimensions: 'W1200 × D1200 × H730 mm',
    color: 'ホワイト / アルミニウム', sizeCategory: 'ラウンドダイニングテーブル',
    tags: ['フライミー', 'ノール', 'チューリップ', 'サーリネン', 'デザイナーズテーブル'],
    editorialComment: '1960年代の宇宙時代の美意識が詰まった名作。一本脚の構造が食卓周りのスペースを最大化し、美しく広がりを感じる食事空間を作る。',
    pros: ['60年以上愛されるタイムレスデザイン', '一本脚で椅子の配置が自由', 'ノール公式品の確かな品質'],
    cons: ['丸型のため長方形空間にはレイアウトを工夫'],
    targetUser: 'デザイナーズ名作家具でダイニングを特別な空間にしたい方',
  },
  {
    id: 'fm-chair-eames-lounge',
    name: 'FLYMEe イームズ ラウンジチェア＆オットマン (ウォールナット × 本革)',
    subtitle: '20世紀デザインの頂点。イームズが生んだ至高のラウンジチェア',
    category: 'chair', taste: 'minimal', room: 'living',
    price: 489000, priceRangeId: '20to40', rating: 4.98, reviewCount: 45,
    image: 'https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?auto=format&fit=crop&w=1200&q=90',
    description: '1956年のデザインから変わることなく愛され続けるチャールズ＆レイ・イームズの「ラウンジチェア＆オットマン」。成形合板とレザーの完璧な組み合わせが圧倒的な快適さと美しさを誇る。',
    materials: ['ウォールナット成形合板', '本革（バイカーレザー）'],
    dimensions: 'W830 × D810 × H850 (SH380) mm',
    color: 'ウォールナット / ブラックレザー', sizeCategory: 'ラウンジチェア（1人掛け）',
    tags: ['フライミー', 'イームズ', 'ラウンジチェア', 'オットマン', 'デザイナーズチェア'],
    editorialComment: '世界で最も愛されるラウンジチェア。ウォールナットの温もりと本革の高級感が、読書や音楽を聴く至上の時間を作り出す。',
    pros: ['20世紀最高峰のチェアデザイン', 'オットマン付きで最高のくつろぎ', 'ウォールナット×本革の贅沢な組み合わせ'],
    cons: ['大型のためスペースを要する'],
    targetUser: '現代デザインの最高峰を自宅のリビングに取り入れたい方',
  },
  {
    id: 'fm-bed-flexform-q',
    name: 'FLYMEe フレックスフォーム SLEEP ベッドフレーム クイーン (本革)',
    subtitle: 'イタリア最高峰フレックスフォームの眠り。本革で包まれた至高のベッド',
    category: 'bed', taste: 'hotel', room: 'bedroom',
    price: 980000, priceRangeId: 'over40', rating: 4.97, reviewCount: 11,
    image: 'https://images.unsplash.com/photo-1540518614846-7eded433c457?auto=format&fit=crop&w=1200&q=90',
    description: 'イタリアの最高峰アップホルスタリーブランド「FLEXFORM」のベッドフレーム。全面を上質な本革で包み込んだヘッドボードと、睡眠工学に基づいた設計が圧倒的な睡眠体験を生み出す。',
    materials: ['スチールフレーム', '本革（フルグレインレザー）', '高密度ウレタン'],
    dimensions: 'W1780 × D2300 × H1200 mm（内寸クイーン）',
    color: 'チョコレートブラウン / グレーシルバー', sizeCategory: 'ベッドフレーム（クイーン）',
    tags: ['フライミー', 'フレックスフォーム', 'ベッドフレーム', '本革', 'イタリア製'],
    editorialComment: '眠ることをラグジュアリーな体験に変える。フレックスフォームが追求した最高の睡眠品質と、本革の官能的な質感が完璧な寝室を作る。',
    pros: ['フレックスフォームの最高品質', '本革の圧倒的な高級感', 'クイーンサイズで最大限のゆとり'],
    cons: ['最高価格帯・大型のため専門コンサルタント相談を推奨'],
    targetUser: '最高峰の睡眠環境を追求する富裕層',
  },
  {
    id: 'fm-storage-porro-system',
    name: 'FLYMEe PORRO ストレージシステム (イタリア製 ウォールユニット)',
    subtitle: 'イタリア工芸の粋。PORRO社のモジュラーストレージシステム',
    category: 'storage', taste: 'minimal', room: 'living',
    price: 680000, priceRangeId: 'over40', rating: 4.95, reviewCount: 9,
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1200&q=90',
    description: 'イタリアのラグジュアリー家具ブランド「PORRO」のモジュラー収納システム。壁面に沿って延びるウォールユニットが圧倒的な収納力と同時に、芸術的な存在感でリビングを支配する。',
    materials: ['天然木ベニア（ウォールナット）', 'ガラス扉（透明/スモーク）'],
    dimensions: 'W3000 × D450 × H2100 mm（カスタマイズ可能）',
    color: 'ウォールナット / ブラックフレーム', sizeCategory: '壁面収納システム',
    tags: ['フライミー', 'PORRO', 'ウォールユニット', 'ストレージシステム', 'イタリア製'],
    editorialComment: '壁面全体をアートとして機能させるモジュラーシステム。PORROの高い工芸技術と洗練されたデザインが最高の収納空間を作る。',
    pros: ['壁面全体を活用した大容量収納', 'イタリア最高峰の工芸品質', 'モジュラー設計でカスタマイズ自由'],
    cons: ['設置に専門工事が必要'],
    targetUser: 'リビングの収納と空間美を同時に追求したい富裕層',
  },
  {
    id: 'fm-desk-minotti-write',
    name: 'FLYMEe ミノッティ WRITE デスク (イタリア製 ウォールナット)',
    subtitle: '書くことを特別にする。ミノッティの至高のライティングデスク',
    category: 'desk', taste: 'hotel', room: 'study',
    price: 348000, priceRangeId: '20to40', rating: 4.95, reviewCount: 13,
    image: 'https://images.unsplash.com/photo-1506439773649-6e0eb8cfb237?auto=format&fit=crop&w=1200&q=90',
    description: 'ミノッティの「WRITE」デスクは、書斎に最高の格を与える傑作。ウォールナット突板の美しい天板と、スチールフレームのシャープな脚部が生み出す洗練されたコントラストが際立つ。',
    materials: ['ウォールナット突板', 'スチールフレーム（マットブラック）'],
    dimensions: 'W1600 × D720 × H750 mm',
    color: 'ウォールナット / マットブラック', sizeCategory: 'ライティングデスク',
    tags: ['フライミー', 'ミノッティ', 'デスク', 'ライティングデスク', 'イタリア製'],
    editorialComment: '書斎にミノッティを置く贅沢。ウォールナットとスチールのコントラストが、仕事と芸術の間にある空間を作り出す。',
    pros: ['ミノッティの精緻なイタリア製品質', 'ウォールナット×スチールの洗練コントラスト', '160cm幅の作業スペース'],
    cons: ['高価格帯のため事前相談推奨'],
    targetUser: '仕事の空間も最高峰のデザイナーズ家具で整えたい富裕層',
  },
  {
    id: 'fm-chair-knoll-saarinen',
    name: 'FLYMEe ノール サーリネン チューリップアームチェア (ホワイト)',
    subtitle: '一本脚の彫刻的美しさ。チューリップテーブルとのベストペアリング',
    category: 'chair', taste: 'minimal', room: 'dining',
    price: 198000, priceRangeId: '10to20', rating: 4.95, reviewCount: 31,
    image: 'https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?auto=format&fit=crop&w=1200&q=90',
    description: 'サーリネン「チューリップテーブル」と同じデザインDNAを持つアームチェア。FRPの流れるような曲線とファブリック座面が、宇宙時代の未来的フォルムを体現する名作。',
    materials: ['FRP（ガラス繊維強化プラスチック）', 'ファブリック（クッション）'],
    dimensions: 'W650 × D580 × H810 (SH475) mm',
    color: 'ホワイト', sizeCategory: 'アームチェア（ダイニング）',
    tags: ['フライミー', 'ノール', 'チューリップチェア', 'サーリネン', 'デザイナーズチェア'],
    editorialComment: 'チューリップテーブルとペアリングで完成する宇宙時代の食卓。一本脚の彫刻的なフォルムが周囲の全てを引き立てる。',
    pros: ['チューリップテーブルとの完璧なマッチング', '流れるような曲線美', 'ノール公式品の確かな品質'],
    cons: ['ファブリックはメンテナンスが必要'],
    targetUser: 'チューリップテーブルに合わせてトータルコーディネートしたい方',
  },
  {
    id: 'fm-sofa-bb-italy-cloud',
    name: 'FLYMEe B&B ITALIA CLOUD ソファ 2.5人掛け',
    subtitle: 'B&B ITALIA の雲のような極上の座り心地。リビングを優雅に包む',
    category: 'sofa', taste: 'hotel', room: 'living',
    price: 750000, priceRangeId: 'over40', rating: 4.98, reviewCount: 17,
    image: 'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=1200&q=90',
    description: 'イタリアの名門B&B ITALIAの「CLOUD」ソファ。名前の通り、雲の中に沈み込むような最高の包容力と、流れるようなシルエットが一体となった圧倒的な上質感。',
    materials: ['スチールフレーム', '高弾力ウレタン', '本革（フルグレイン）'],
    dimensions: 'W2100 × D1000 × H680 (SH430) mm',
    color: 'グレーレザー / マットシルバー', sizeCategory: '2.5人掛けソファ',
    tags: ['フライミー', 'B&B ITALIA', 'CLOUD', 'ソファ', 'イタリア製'],
    editorialComment: 'B&B ITALIAの最高傑作「CLOUD」。沈み込む瞬間から別世界へ。究極の包容力が最高のくつろぎ空間を約束する。',
    pros: ['B&B ITALIA最高品質のイタリア製', '極上の座り心地', '美しい流線型シルエット'],
    cons: ['最高価格帯のためショールーム確認を推奨'],
    targetUser: 'B&B ITALIAで最上のリビングを作りたい富裕層',
  },
  {
    id: 'fm-table-fiam-aria',
    name: 'FLYMEe FIAM ARIA ガラスダイニングテーブル (シルバー脚)',
    subtitle: '透過する光が生み出す空間美。FIAMの曲げガラス技術の傑作',
    category: 'table', taste: 'minimal', room: 'dining',
    price: 560000, priceRangeId: 'over40', rating: 4.96, reviewCount: 14,
    image: 'https://images.unsplash.com/photo-1615066390971-03e4e1c36ddf?auto=format&fit=crop&w=1200&q=90',
    description: 'イタリアのガラス家具の最高峰「FIAM」の「ARIA」テーブル。独自の曲げガラス技術で成形された天板が、光を透過して空間に軽やかな美しさをもたらす。',
    materials: ['強化ガラス（曲げ加工）', 'ステンレス脚（シルバー）'],
    dimensions: 'W1800 × D900 × H730 mm',
    color: 'ガラスクリア / シルバー', sizeCategory: 'ガラスダイニングテーブル',
    tags: ['フライミー', 'FIAM', 'ガラステーブル', 'ダイニングテーブル', 'イタリア製'],
    editorialComment: '光が透過し、宙に浮くような幻想的なテーブル。FIAMの曲げガラス技術が、食卓に類まれなる美学と軽快さをもたらす。',
    pros: ['FIAM独自曲げガラスの美しさ', '光を通す透明感で空間が広く見える', 'イタリア最高品質'],
    cons: ['ガラス製のためメンテナンスと取り扱いに注意'],
    targetUser: 'ガラスの透明感と優雅なシルエットのダイニングを求める方',
  },
  {
    id: 'fm-chair-arper-catifa',
    name: 'FLYMEe ARPER Catifa 53 チェア (イタリア製)',
    subtitle: '機能と美が融合した現代のダイニングチェア。ARPERの洗練された名作',
    category: 'chair', taste: 'minimal', room: 'dining',
    price: 88000, priceRangeId: 'under10', rating: 4.92, reviewCount: 38,
    image: 'https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?auto=format&fit=crop&w=1200&q=90',
    description: 'イタリアのARPERが手がける「Catifa 53」チェア。有機的なシェル形状が身体を自然に包み込む機能美と、豊富なカラーバリエーションで空間にアクセントを与える人気モデル。',
    materials: ['ポリプロピレン（シェル）', 'アルミニウム脚'],
    dimensions: 'W545 × D520 × H780 (SH465) mm',
    color: 'ホワイト / ブラック / チャコール（多色展開）', sizeCategory: 'ダイニングチェア',
    tags: ['フライミー', 'ARPER', 'Catifa', 'ダイニングチェア', 'イタリア製'],
    editorialComment: '軽やかで多色展開。シェルの有機的なフォルムが食卓に現代的な活気をもたらす。',
    pros: ['軽量で扱いやすい', '豊富なカラーで個性的なコーディネート', 'イタリア製の高い品質'],
    cons: ['スタッキング時の安定性に注意'],
    targetUser: 'ダイニングチェアに個性と現代デザインを求める方',
  },
];

// ──────────────────────────────────────────────────────
// CRASH GATE 追加製品データ（ヴィンテージ・インダストリアル）
// ──────────────────────────────────────────────────────
const crashgateProducts = [
  {
    id: 'cg-sofa-opiam-3p',
    name: 'CRASH GATE OPIAM ソファ 3人掛け (オイルレザー × アイアン)',
    subtitle: '総オイルレザーとアイアンフレーム。使い込むほど味わう本格インダストリアルソファ',
    category: 'sofa', taste: 'vintage', room: 'living',
    price: 288000, priceRangeId: '20to40', rating: 4.93, reviewCount: 47,
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1200&q=90',
    description: 'CRASH GATEの代表作「OPIAM」3人掛けソファ。経年変化が個性になるオイルレザーと、無骨なアイアンフレームの組み合わせ。使い込むほどに深みが増す本格インダストリアル家具。',
    materials: ['総オイルレザー（牛革）', 'アイアンフレーム（ブラック）'],
    dimensions: 'W2050 × D890 × H750 (SH420) mm',
    color: 'ブラウンオイルレザー / マットブラック', sizeCategory: '3人掛けソファ',
    tags: ['クラッシュゲート', 'OPIAM', '3人掛けソファ', 'オイルレザー', 'インダストリアル'],
    editorialComment: '男前インテリアの真骨頂。時間をかけてレザーとアイアンが育つ経年変化が、世界で唯一の一脚を完成させる。',
    pros: ['経年変化が個性になるオイルレザー', '無骨なアイアンフレームの存在感', '圧倒的なインダストリアル感'],
    cons: ['オイルレザーは定期的なオイルケアが必要'],
    targetUser: '使い込むほど味わいが増すインダストリアルソファを求める方',
  },
  {
    id: 'cg-table-agra-dt-180',
    name: 'CRASH GATE AGRA ダイニングテーブル W1800 (古材オーク × アイアン)',
    subtitle: '古木の時間を纏う。ヴィンテージオーク天板とアイアン脚のインダストリアル食卓',
    category: 'table', taste: 'vintage', room: 'dining',
    price: 198000, priceRangeId: '10to20', rating: 4.91, reviewCount: 38,
    image: 'https://images.unsplash.com/photo-1615066390971-03e4e1c36ddf?auto=format&fit=crop&w=1200&q=90',
    description: 'CRASH GATEの「AGRA」ダイニングテーブル。アップサイクルされた古材オーク天板のヴィンテージ感と、頑強なアイアン脚の組み合わせが、唯一無二の食卓を作り出す。',
    materials: ['古材オーク無垢材（アップサイクル）', 'アイアン脚（マットブラック）'],
    dimensions: 'W1800 × D900 × H720 mm',
    color: 'ヴィンテージオーク / マットブラック', sizeCategory: 'ダイニングテーブル',
    tags: ['クラッシュゲート', 'AGRA', 'ダイニングテーブル', '古材', 'アイアン'],
    editorialComment: '古材の傷や節が物語る時間の重さ。世界に一つしかない天板の表情が、毎日の食卓を特別な場所にする。',
    pros: ['古材ならではの唯一無二の表情', 'アイアン脚の無骨な頑丈さ', 'ヴィンテージインテリアに最適'],
    cons: ['古材の節・傷は品質の証（個体差あり）'],
    targetUser: '本格的なヴィンテージ・インダストリアルの食空間を作りたい方',
  },
  {
    id: 'cg-sofa-2p-leather',
    name: 'CRASH GATE BRONX 2人掛けソファ (オイルレザー)',
    subtitle: '無骨さの中に宿る優雅さ。BRONXコレクションのコンパクトな2人掛け',
    category: 'sofa', taste: 'vintage', room: 'living',
    price: 198000, priceRangeId: '10to20', rating: 4.89, reviewCount: 52,
    image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=1200&q=90',
    description: 'CRASH GATEの「BRONX」コレクションの2人掛けソファ。程よいコンパクトさにオイルレザーの存在感が詰まった、インダストリアルインテリアの定番モデル。',
    materials: ['総オイルレザー（牛革）', 'スチールフレーム（ブラック）'],
    dimensions: 'W1560 × D870 × H740 (SH400) mm',
    color: 'オイルブラウン / ブラック', sizeCategory: '2人掛けソファ',
    tags: ['クラッシュゲート', 'BRONX', '2人掛けソファ', 'オイルレザー', 'ヴィンテージ'],
    editorialComment: 'コンパクトながらも存在感は抜群。OPIAMと違う設計でオイルレザーのパティナが楽しめる。',
    pros: ['コンパクトで置きやすい', 'オイルレザーの深い経年変化', 'CRASH GATEの定番モデル'],
    cons: ['オイルレザーメンテナンスが必要'],
    targetUser: 'インダストリアルインテリアにコンパクトなソファを探している方',
  },
  {
    id: 'cg-chair-lounge-oak',
    name: 'CRASH GATE TRUNK ラウンジチェア (オーク × ヴィンテージレザー)',
    subtitle: '古木と革が育む上質な佇まい。TRUNKラウンジチェアの無骨な優雅さ',
    category: 'chair', taste: 'vintage', room: 'living',
    price: 98000, priceRangeId: 'under10', rating: 4.88, reviewCount: 34,
    image: 'https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?auto=format&fit=crop&w=1200&q=90',
    description: 'CRASH GATEの「TRUNK」コレクションのラウンジチェア。古木オーク材のフレームとヴィンテージ加工のレザー座面が、インダストリアルインテリアに深みを加える。',
    materials: ['古木オーク無垢材', 'ヴィンテージ加工レザー（牛革）'],
    dimensions: 'W720 × D760 × H820 (SH420) mm',
    color: 'オーク / キャメルレザー', sizeCategory: 'ラウンジチェア',
    tags: ['クラッシュゲート', 'TRUNK', 'ラウンジチェア', 'オーク', 'ヴィンテージ'],
    editorialComment: '読書や音楽鑑賞のための一脚。古木の表情とヴィンテージレザーが、時間の流れを感じさせる唯一無二の椅子。',
    pros: ['オーク古木の個性的な表情', 'ヴィンテージレザーの深み', 'CRASH GATEらしいアイコニックデザイン'],
    cons: ['古木の節・傷は品質の証（個体差あり）'],
    targetUser: 'リビングのくつろぎコーナーにインダストリアルチェアを置きたい方',
  },
  {
    id: 'cg-storage-shelf-iron',
    name: 'CRASH GATE LANDER シェルフ W1200 (アイアン × ウッド)',
    subtitle: '鉄と木の荒削りなコントラスト。インダストリアル書棚の決定版',
    category: 'storage', taste: 'vintage', room: 'living',
    price: 98000, priceRangeId: 'under10', rating: 4.87, reviewCount: 29,
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1200&q=90',
    description: 'CRASH GATEの「LANDER」シェルフ。アイアンフレームとオーク無垢棚板の組み合わせが、インダストリアルインテリアに最適な収納美を提供する。',
    materials: ['アイアンフレーム（マットブラック）', 'オーク無垢棚板'],
    dimensions: 'W1200 × D350 × H1800 mm',
    color: 'マットブラック / ナチュラルオーク', sizeCategory: 'シェルフ・書棚',
    tags: ['クラッシュゲート', 'LANDER', 'シェルフ', 'アイアン', 'インダストリアル'],
    editorialComment: '本・雑貨・グリーンを並べるだけで男前インテリアが完成。アイアンとオーク木の荒削りなコントラストが部屋のフォーカルポイントになる。',
    pros: ['アイアン×オークの無骨なコントラスト', '幅1200cmで大容量収納', 'インダストリアルインテリアの定番'],
    cons: ['アイアンフレームは重量があるため移動に注意'],
    targetUser: 'インダストリアルな収納棚でリビングや書斎を引き締めたい方',
  },
  {
    id: 'cg-tvboard-vintage',
    name: 'CRASH GATE UNION テレビボード W1600 (古材 × アイアン)',
    subtitle: '古材の時間とアイアンの強さ。インダストリアルTVボードの最高峰',
    category: 'tv-board', taste: 'vintage', room: 'living',
    price: 148000, priceRangeId: '10to20', rating: 4.9, reviewCount: 33,
    image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=1200&q=90',
    description: 'CRASH GATEの「UNION」テレビボード。古材オーク天板とアイアンフレームを組み合わせたW1600の大型TVボードが、インダストリアルリビングの完成度を高める。',
    materials: ['古材オーク（アップサイクル）', 'アイアンフレーム（ブラック）'],
    dimensions: 'W1600 × D420 × H400 mm',
    color: 'ヴィンテージオーク / マットブラック', sizeCategory: 'テレビボード',
    tags: ['クラッシュゲート', 'UNION', 'テレビボード', '古材', 'インダストリアル'],
    editorialComment: '古材の傷や節が持つ物語が、TVを中心としたインダストリアルリビングに深みを加える。',
    pros: ['古材の唯一無二の表情', 'アイアンの無骨な強さ', 'W1600の大型サイズで大画面TVに対応'],
    cons: ['古材の個体差による見た目の違いがある'],
    targetUser: 'インダストリアルな雰囲気のTVボードを探している方',
  },
  {
    id: 'cg-table-ct-iron-80',
    name: 'CRASH GATE MANOR センターテーブル (アイアン × ガラス天板)',
    subtitle: 'ガラスとアイアンの荒削りな美学。インダストリアルリビングの主役テーブル',
    category: 'table', taste: 'vintage', room: 'living',
    price: 78000, priceRangeId: 'under10', rating: 4.86, reviewCount: 41,
    image: 'https://images.unsplash.com/photo-1615066390971-03e4e1c36ddf?auto=format&fit=crop&w=1200&q=90',
    description: 'CRASH GATEの「MANOR」センターテーブル。アイアンフレームとガラス天板の組み合わせが、インダストリアルスタイルに独特の透明感と重厚感を同時にもたらす。',
    materials: ['アイアンフレーム（ブラック）', '強化ガラス天板（クリア）'],
    dimensions: 'W1200 × D600 × H420 mm',
    color: 'マットブラック / クリアガラス', sizeCategory: 'センターテーブル・ガラス',
    tags: ['クラッシュゲート', 'MANOR', 'センターテーブル', 'ガラス', 'アイアン'],
    editorialComment: 'ガラスを通した空間の透過感と、アイアンの鉄の塊感が作る絶妙なコントラスト。インダストリアルリビングに欠かせない一台。',
    pros: ['ガラスで空間が広く見える', 'アイアンの無骨な重量感', '比較的手頃な価格でCRASH GATEを体験'],
    cons: ['ガラス天板はメンテナンスが必要'],
    targetUser: 'インダストリアルなセンターテーブルをコスパよく取り入れたい方',
  },
];

// ──────────────────────────────────────────────────────
// Re:CENO 追加製品データ（北欧・ナチュラルヴィンテージ）
// ──────────────────────────────────────────────────────
const recenoProducts = [
  {
    id: 'rc-sofa-lato-3p',
    name: 'Re:CENO LATO ソファ 3人掛け (ファブリック / オーク脚)',
    subtitle: 'ナチュラルヴィンテージの温もり。Re:CENOらしさが詰まった北欧ソファ',
    category: 'sofa', taste: 'nordic', room: 'living',
    price: 178000, priceRangeId: '10to20', rating: 4.91, reviewCount: 68,
    image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=1200&q=90',
    description: 'Re:CENOの定番「LATO」ソファの3人掛け。北欧の自然素材をイメージしたナチュラルファブリックとオーク無垢脚が、温もりのあるリビング空間を作り出す。',
    materials: ['オーク無垢脚', 'ウール混ファブリック', '高密度ウレタン'],
    dimensions: 'W1920 × D870 × H730 (SH390) mm',
    color: 'ナチュラルグレー / オーク', sizeCategory: '3人掛けソファ',
    tags: ['リセノ', 'LATO', '3人掛けソファ', 'ナチュラル', '北欧'],
    editorialComment: 'ナチュラルヴィンテージの世界観を体現するLATOソファ。毎日が心地よくなる温もりと、部屋に自然に溶け込む素材感が魅力。',
    pros: ['北欧ナチュラルの温かい雰囲気', 'オーク脚の自然な風合い', '心地よい座り心地'],
    cons: ['ファブリックは汚れに注意'],
    targetUser: '北欧の温もりと心地よさを重視するファミリー層',
  },
  {
    id: 'rc-table-ander-dt',
    name: 'Re:CENO ANDER ダイニングテーブル W1400 (オーク無垢)',
    subtitle: '経年変化を楽しむ北欧の食卓。Re:CENOの定番オークダイニング',
    category: 'table', taste: 'nordic', room: 'dining',
    price: 128000, priceRangeId: '10to20', rating: 4.90, reviewCount: 54,
    image: 'https://images.unsplash.com/photo-1615066390971-03e4e1c36ddf?auto=format&fit=crop&w=1200&q=90',
    description: 'Re:CENOの「ANDER」ダイニングテーブル。オーク無垢材の自然な木目と節が、家族の食卓に温もりをもたらす。使い込むほどに深みが増す経年変化を楽しめる本格的な木製テーブル。',
    materials: ['オーク無垢材（北欧産）'],
    dimensions: 'W1400 × D800 × H720 mm',
    color: 'ナチュラルオーク', sizeCategory: 'ダイニングテーブル（4〜6人）',
    tags: ['リセノ', 'ANDER', 'ダイニングテーブル', 'オーク', '北欧'],
    editorialComment: '北欧の豊かな森を想わせるオーク無垢材。経年変化と共に深みを増す天板が、家族の歴史を刻んでいく食卓に。',
    pros: ['オーク無垢の豊かな木目', '経年変化を楽しめる', '4〜6人の食卓に最適なサイズ'],
    cons: ['無垢材のため温湿度管理に注意'],
    targetUser: '家族で毎日使うダイニングに本物のオーク材テーブルを置きたい方',
  },
  {
    id: 'rc-chair-gino-dc',
    name: 'Re:CENO GINO ダイニングチェア (ファブリック × オーク無垢)',
    subtitle: '毎日座りたくなるナチュラル感。ANDERテーブルと絶妙なハーモニー',
    category: 'chair', taste: 'nordic', room: 'dining',
    price: 45000, priceRangeId: 'under10', rating: 4.88, reviewCount: 92,
    image: 'https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?auto=format&fit=crop&w=1200&q=90',
    description: 'Re:CENOの「GINO」ダイニングチェア。オーク無垢脚とファブリック座面のシンプルな組み合わせが、食卓の温もりを高める。ANDERテーブルとのコーディネートが人気。',
    materials: ['オーク無垢材', 'ウール混ファブリック（カバーリング）'],
    dimensions: 'W490 × D530 × H800 (SH430) mm',
    color: 'ナチュラルオーク / グレー', sizeCategory: 'ダイニングチェア',
    tags: ['リセノ', 'GINO', 'ダイニングチェア', 'オーク', 'カバーリング'],
    editorialComment: 'ANDERテーブルとのセットで完成する北欧の食卓。カバーリング仕様でお手入れも安心。',
    pros: ['カバーリングで清潔管理が楽', 'オーク脚の自然な温もり', '手頃な価格でRe:CENOを体験'],
    cons: ['ファブリック色によって汚れが目立つ場合あり'],
    targetUser: 'ANDERテーブルと合わせてRe:CENOで統一したい北欧ファン',
  },
  {
    id: 'rc-sofa-lato-2p',
    name: 'Re:CENO LATO ソファ 2人掛け (オイルレザー × オーク脚)',
    subtitle: 'ナチュラルヴィンテージとレザーの出会い。2人掛けの上質な選択',
    category: 'sofa', taste: 'vintage', room: 'living',
    price: 148000, priceRangeId: '10to20', rating: 4.89, reviewCount: 43,
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1200&q=90',
    description: 'Re:CENOの「LATO」ソファのオイルレザーバージョン2人掛け。温もりのあるオーク脚と、経年変化が美しいオイルレザーの組み合わせが、ナチュラルヴィンテージの空間を引き立てる。',
    materials: ['オーク無垢脚', 'オイルレザー（牛革）'],
    dimensions: 'W1540 × D860 × H730 (SH390) mm',
    color: 'キャメルレザー / オーク', sizeCategory: '2人掛けソファ',
    tags: ['リセノ', 'LATO', '2人掛けソファ', 'オイルレザー', 'ナチュラルヴィンテージ'],
    editorialComment: 'ファブリックとはまた違う、オイルレザーのリッチな存在感。使い込むほどにキャラメル色に深まる経年変化が愛着を育てる。',
    pros: ['オイルレザーの美しい経年変化', 'オーク脚との自然なコンビ', '2人掛けで置きやすいサイズ'],
    cons: ['オイルレザーは定期的なケアが必要'],
    targetUser: 'ナチュラルヴィンテージに上質なレザーを取り入れたい方',
  },
  {
    id: 'rc-bed-folk-d',
    name: 'Re:CENO FOLK ベッドフレーム ダブル (オーク × アイアン)',
    subtitle: '自然素材と鉄。FOLKシリーズが作る心地よい眠りの空間',
    category: 'bed', taste: 'nordic', room: 'bedroom',
    price: 128000, priceRangeId: '10to20', rating: 4.90, reviewCount: 37,
    image: 'https://images.unsplash.com/photo-1540518614846-7eded433c457?auto=format&fit=crop&w=1200&q=90',
    description: 'Re:CENOの「FOLK」ベッドフレーム。オーク無垢材のヘッドボードとアイアン脚の組み合わせが、ナチュラルヴィンテージの寝室をトータルコーディネートする。',
    materials: ['オーク無垢材（ヘッドボード）', 'アイアン脚'],
    dimensions: 'W1430 × D2100 × H800 mm（内寸ダブル）',
    color: 'ナチュラルオーク / ブラック', sizeCategory: 'ベッドフレーム（ダブル）',
    tags: ['リセノ', 'FOLK', 'ベッドフレーム', 'ダブル', 'ナチュラル'],
    editorialComment: 'オークのヘッドボードが就寝前の時間に温かみを添える。シンプルな構造が場所を選ばず使いやすい。',
    pros: ['オーク無垢のナチュラルな温もり', 'ダブルサイズで2人でゆったり', 'シンプルで合わせやすいデザイン'],
    cons: ['アイアン脚は床への傷つきに注意（フェルト等を推奨）'],
    targetUser: 'ナチュラルヴィンテージの寝室をトータルコーディネートしたい方',
  },
  {
    id: 'rc-storage-enkel',
    name: 'Re:CENO ENKEL サイドボード W1400 (オーク × アイアン)',
    subtitle: 'ダイニング収納を美しく格上げ。ENKELサイドボードの洗練された佇まい',
    category: 'storage', taste: 'nordic', room: 'dining',
    price: 138000, priceRangeId: '10to20', rating: 4.89, reviewCount: 31,
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1200&q=90',
    description: 'Re:CENOの「ENKEL」サイドボード。オーク突板とアイアンフレームの組み合わせが、食器や雑貨の収納に実用性と美しさをもたらすダイニングの脇役。',
    materials: ['オーク突板', 'アイアン脚（マットブラック）'],
    dimensions: 'W1400 × D420 × H750 mm',
    color: 'ナチュラルオーク / マットブラック', sizeCategory: 'サイドボード（食器棚）',
    tags: ['リセノ', 'ENKEL', 'サイドボード', 'オーク', '北欧収納'],
    editorialComment: '食器や食品のストックをまとめながら、ダイニングにナチュラルな落ち着きをもたらす。',
    pros: ['収納力と美しさの両立', 'オーク×アイアンのナチュラルコントラスト', 'テーブルと統一感のあるデザイン'],
    cons: ['扉付きのため物の取り出しが少し手間'],
    targetUser: 'ダイニングの収納もナチュラルヴィンテージで揃えたい方',
  },
];

// ──────────────────────────────────────────────────────
// LOWYA 追加製品データ（エントリー〜ミドル価格帯）
// ──────────────────────────────────────────────────────
const lowyaProducts = [
  {
    id: 'ly-sofa-l-gray',
    name: 'LOWYA L字型ソファ 6点セット (モダン / マイクロファイバー)',
    subtitle: '広いリビングを贅沢に使う。LOWYAのL字型ソファが作る開放的な空間',
    category: 'sofa', taste: 'modern', room: 'living',
    price: 79800, priceRangeId: 'under10', rating: 4.75, reviewCount: 218,
    image: 'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=1200&q=90',
    description: 'LOWYAのL字型6点セットソファ。モダンなデザインと手頃な価格で、広々としたリビングコーナーを実現。マイクロファイバー素材で肌触りも良く、日常使いに最適。',
    materials: ['マイクロファイバー（ファブリック）', 'スチール脚'],
    dimensions: 'W2900 × D1700 × H740 (SH380) mm',
    color: 'グレー / ブラック', sizeCategory: 'L字型コーナーソファ',
    tags: ['ロウヤ', 'L字型ソファ', 'コーナーソファ', 'マイクロファイバー', 'コスパ'],
    editorialComment: 'コスパを最大化しながら、L字型の贅沢な座り心地を実現。家族みんながくつろぐ理想のリビングコーナーに。',
    pros: ['L字型で家族全員がゆったり使用可能', '手頃な価格設定', 'マイクロファイバーで肌触り良い'],
    cons: ['高価格帯モデルと比べて素材感に差がある'],
    targetUser: 'コスパを重視しながらL字型ソファを探している方',
  },
  {
    id: 'ly-table-mortar-dt',
    name: 'LOWYA モルタル調ダイニングテーブル W1600 (アイアン脚)',
    subtitle: 'トレンドのモルタル調天板×アイアン脚。コスパ抜群のホテルライクダイニング',
    category: 'table', taste: 'modern', room: 'dining',
    price: 39800, priceRangeId: 'under10', rating: 4.72, reviewCount: 156,
    image: 'https://images.unsplash.com/photo-1615066390971-03e4e1c36ddf?auto=format&fit=crop&w=1200&q=90',
    description: 'LOWYAのモルタル調メラミン天板ダイニングテーブル。最近人気のインダストリアル系インテリアに合わせやすいデザインを、手頃な価格で実現。',
    materials: ['メラミン化粧板（モルタル調）', 'スチール脚（マットブラック）'],
    dimensions: 'W1600 × D800 × H720 mm',
    color: 'モルタルグレー / マットブラック', sizeCategory: 'ダイニングテーブル（4〜6人）',
    tags: ['ロウヤ', 'モルタル調', 'ダイニングテーブル', 'アイアン脚', 'コスパ'],
    editorialComment: 'プチプラでホテルライクなダイニング空間を実現。モルタル調の表面が水や汚れに強く、毎日の食事でも安心して使える。',
    pros: ['モルタル調でトレンドのインテリアに対応', '水・汚れに強いメラミン天板', '手頃な価格'],
    cons: ['メラミン天板のため高級素材感には差がある'],
    targetUser: 'コスパよくモダンなダイニングを作りたい方',
  },
  {
    id: 'ly-bed-storage-d',
    name: 'LOWYA 収納付きベッドフレーム ダブル (ガス圧リフトアップ)',
    subtitle: '収納力を両立したコスパ最強のベッド。ガス圧でラクラク開閉',
    category: 'bed', taste: 'modern', room: 'bedroom',
    price: 59800, priceRangeId: 'under10', rating: 4.77, reviewCount: 187,
    image: 'https://images.unsplash.com/photo-1540518614846-7eded433c457?auto=format&fit=crop&w=1200&q=90',
    description: 'LOWYAの収納付きベッドフレーム（ダブル）。ガス圧リフトアップ式の大容量収納が、寝室のデッドスペースを有効活用。シンプルモダンなデザインで様々なインテリアに調和。',
    materials: ['MDF（メラミン化粧板）', 'スチール支持構造'],
    dimensions: 'W1450 × D2130 × H850 mm（内寸ダブル）',
    color: 'ホワイト / ブラック / ブラウン', sizeCategory: 'ベッドフレーム（ダブル）',
    tags: ['ロウヤ', '収納付きベッド', 'ガス圧', 'ダブル', 'コスパ'],
    editorialComment: '収納力と価格のバランスが最高。リフトアップ式で重い荷物の出し入れもラクラク。一人暮らしから家族まで使いやすい万能ベッド。',
    pros: ['大容量収納でスペースを有効活用', 'ガス圧式でラクラク開閉', 'コスパ最高のエントリーベッド'],
    cons: ['素材感は高価格帯に比べシンプル'],
    targetUser: '予算を抑えながら収納力と使いやすさを重視したい方',
  },
  {
    id: 'ly-desk-pc-w120',
    name: 'LOWYA PCデスク W1200 (モルタル調天板 / スチールフレーム)',
    subtitle: 'テレワークの定番に。コスパ抜群のモダンPCデスク',
    category: 'desk', taste: 'modern', room: 'study',
    price: 22800, priceRangeId: 'under10', rating: 4.73, reviewCount: 312,
    image: 'https://images.unsplash.com/photo-1506439773649-6e0eb8cfb237?auto=format&fit=crop&w=1200&q=90',
    description: 'LOWYAのPCデスク（W1200）。モルタル調のモダンな天板と、スチールフレームが作るホテルライクなデスク環境を手頃な価格で実現。テレワーク・在宅勤務に最適。',
    materials: ['メラミン化粧板（モルタル調）', 'スチールフレーム'],
    dimensions: 'W1200 × D600 × H720 mm',
    color: 'モルタルグレー / ブラック', sizeCategory: 'PCデスク（120cm幅）',
    tags: ['ロウヤ', 'PCデスク', 'テレワーク', 'モルタル調', 'コスパ'],
    editorialComment: '在宅ワークの質をトレンドのモルタル調デザインで手頃に向上。W1200の作業スペースで快適な仕事環境が整う。',
    pros: ['モルタル調でモダンなデスク環境', 'W1200で作業スペース十分', 'コスパ最高'],
    cons: ['メラミン天板のため傷に注意'],
    targetUser: 'コスパよくオシャレな在宅ワーク環境を整えたい方',
  },
  {
    id: 'ly-storage-tv-w180',
    name: 'LOWYA テレビボード W1800 (ミラー扉 / ホワイト)',
    subtitle: 'ミラー扉で空間が広く見える。LOWYAの大型TVボード',
    category: 'tv-board', taste: 'modern', room: 'living',
    price: 49800, priceRangeId: 'under10', rating: 4.71, reviewCount: 143,
    image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=1200&q=90',
    description: 'LOWYAのミラー扉付きテレビボード（W1800）。ミラー素材の扉が空間に奥行き感をもたらし、インテリアを洗練されたスタイリッシュな印象に。大容量収納で機器周りもすっきり。',
    materials: ['MDF（白ラッカー塗装）', 'ミラーガラス扉'],
    dimensions: 'W1800 × D400 × H500 mm',
    color: 'ホワイト / ミラー', sizeCategory: 'テレビボード（ロータイプ）',
    tags: ['ロウヤ', 'テレビボード', 'ミラー扉', 'ホワイト', 'コスパ'],
    editorialComment: 'ミラーの反射で部屋が広く見える。スタイリッシュなホワイトカラーが明るいリビングを演出。コスパ抜群の大型TVボード。',
    pros: ['ミラー扉で空間が広く見える', 'ホワイトで明るいリビングに', '大容量収納'],
    cons: ['ミラーは指紋がつきやすいため拭き掃除が必要'],
    targetUser: 'ホワイトで統一した明るいリビングを低予算で作りたい方',
  },
];

// ──────────────────────────────────────────────────────
// KANADEMONO 追加製品データ（カスタムオーダー家具）
// ──────────────────────────────────────────────────────
const kanedemonoProducts = [
  {
    id: 'km-desk-mortar-w140',
    name: 'KANADEMONO モルタル天板 × THE STANDARD 脚 デスク W1400',
    subtitle: 'ミリ単位でオーダー。モルタル調とブラックアイアンが作る最高のデスク',
    category: 'desk', taste: 'minimal', room: 'study',
    price: 62000, priceRangeId: 'under10', rating: 4.95, reviewCount: 78,
    image: 'https://images.unsplash.com/photo-1506439773649-6e0eb8cfb237?auto=format&fit=crop&w=1200&q=90',
    description: 'KANADEMONOのモルタル調天板とTHE STANDARD脚の組み合わせデスク。1cm単位でサイズオーダーが可能で、自分だけの完璧なデスクを実現。ホテルライクなミニマリストに最適。',
    materials: ['モルタル調メラミン天板', 'スチール脚（マットブラック）'],
    dimensions: 'W1400 × D700 × H720 mm（サイズカスタマイズ可）',
    color: 'モルタルグレー / マットブラック', sizeCategory: 'ワークデスク（オーダー可）',
    tags: ['かなでもの', 'モルタル天板', 'デスク', 'オーダー', 'ホテルライク'],
    editorialComment: '「このサイズがない」を解決するKANADEMONOのオーダーシステム。モルタル調の質感がホームオフィスをプロの仕事場に変える。',
    pros: ['1cm単位のサイズオーダー対応', 'モルタル調でホテルライクなデスク環境', 'ブラックアイアンとのシャープなコントラスト'],
    cons: ['オーダーのため納期がかかる（2〜4週間程度）'],
    targetUser: '自分だけのオーダーデスクでホームオフィスを完璧にしたい方',
  },
  {
    id: 'km-table-oak-dt-160',
    name: 'KANADEMONO ラバーウッド無垢板 × THE STANDARD 脚 ダイニングテーブル W1600',
    subtitle: '天板×脚の自由な組み合わせ。オーク系天然木の食卓カスタマイズ',
    category: 'table', taste: 'minimal', room: 'dining',
    price: 78000, priceRangeId: 'under10', rating: 4.93, reviewCount: 62,
    image: 'https://images.unsplash.com/photo-1615066390971-03e4e1c36ddf?auto=format&fit=crop&w=1200&q=90',
    description: 'KANADEMONOのラバーウッド無垢板天板とTHE STANDARD脚のダイニングテーブル。天板の種類・サイズ・脚の高さを自由にカスタマイズして、自分だけの理想の食卓を作れる。',
    materials: ['ラバーウッド無垢板', 'スチール脚（マットブラック）'],
    dimensions: 'W1600 × D800 × H720 mm（サイズカスタマイズ可）',
    color: 'ナチュラルウッド / マットブラック', sizeCategory: 'ダイニングテーブル（4〜6人）',
    tags: ['かなでもの', 'ラバーウッド', 'ダイニングテーブル', 'オーダー', 'カスタマイズ'],
    editorialComment: 'ぴったりのサイズが見つからない、そんな悩みをKANADEMONOが解決。ラバーウッドの温もりとマットブラック脚の洗練が作る、自分だけの食卓。',
    pros: ['自由なサイズカスタマイズ', 'ラバーウッド無垢の温かい質感', 'コストパフォーマンスに優れる'],
    cons: ['オーダーのため納期が必要'],
    targetUser: '食卓のサイズや素材にこだわりを持つ方',
  },
  {
    id: 'km-shelf-pipe-5tier',
    name: 'KANADEMONO スチールパイプ シェルフ 5段 (ブラック)',
    subtitle: 'ミニマルインダストリアルの定番棚。KANADEMONOのパイプシェルフ',
    category: 'storage', taste: 'minimal', room: 'study',
    price: 34800, priceRangeId: 'under10', rating: 4.90, reviewCount: 86,
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1200&q=90',
    description: 'KANADEMONOのスチールパイプシェルフ。ミニマルなブラックパイプフレームが書籍や雑貨を美しく見せる。オープンシェルフならではの軽やかさと実用性が両立する。',
    materials: ['スチールパイプ（マットブラック）', 'スチール棚板'],
    dimensions: 'W900 × D350 × H1600 mm',
    color: 'マットブラック', sizeCategory: 'シェルフ（5段・オープン）',
    tags: ['かなでもの', 'シェルフ', 'スチールパイプ', 'インダストリアル', '収納'],
    editorialComment: 'オープンシェルフに並べるだけでインテリアが完成。ミニマルなブラックパイプが何を置いても美しく見せる魔法。',
    pros: ['ミニマルなブラックで何にでも合う', 'オープンで中身が見やすい', 'リーズナブルな価格'],
    cons: ['オープンシェルフのためほこりが溜まりやすい'],
    targetUser: 'ミニマルインテリアの収納棚を探している方',
  },
];

// ──────────────────────────────────────────────────────
// ブロック生成ヘルパー
// ──────────────────────────────────────────────────────
function makeBlock(item, brandId, brandName, affBaseUrl) {
  const safeEscape = str => (str || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/\n/g, ' ');
  const imgStr = `'${item.image}'`;
  const tagsStr = item.tags.map(t => `'${safeEscape(t)}'`).join(', ');
  const matsStr = item.materials.map(m => `'${safeEscape(m)}'`).join(', ');
  const prosStr = item.pros.map(p => `'${safeEscape(p)}'`).join(', ');
  const consStr = item.cons.map(c => `'${safeEscape(c)}'`).join(', ');
  
  const url = `${affBaseUrl}/?utm_source=orbital_select&utm_medium=affiliate&q=${encodeURIComponent(item.name.substring(0,30))}`;
  
  return `  {
    id: '${item.id}',
    name: '${safeEscape(item.name)}',
    subtitle: '${safeEscape(item.subtitle)}',
    brand: '${brandName}',
    partnerBrandId: '${brandId}',
    category: '${item.category}',
    taste: '${item.taste}',
    room: '${item.room}',
    price: ${item.price},
    priceRangeId: '${item.priceRangeId}',
    rating: ${item.rating},
    reviewCount: ${item.reviewCount},
    images: [${imgStr}],
    description: '${safeEscape(item.description)}',
    materials: [${matsStr}],
    dimensions: '${safeEscape(item.dimensions)}',
    color: '${safeEscape(item.color)}',
    sizeCategory: '${safeEscape(item.sizeCategory)}',
    tags: [${tagsStr}],
    editorialComment: '${safeEscape(item.editorialComment)}',
    pros: [${prosStr}],
    cons: [${consStr}],
    targetUser: '${safeEscape(item.targetUser)}',
    shopLinks: [
      {
        name: '${brandName} 公式ストア',
        label: '${brandName}公式オンラインショップで見る',
        price: ${item.price},
        url: '${url}',
        isOfficial: true,
      },
    ],
    isTopRanked: ${item.rating >= 4.97},
    isEditorsPick: ${item.rating >= 4.95 && item.price >= 100000},
    isNewArrival: false,
  }`;
}

// ブランド設定
const configs = {
  masterwal: { name: 'MASTERWAL', url: 'https://www.masterwal.jp', items: masterwallProducts },
  flymee: { name: 'FLYMEe', url: 'https://flymee.jp', items: flymeeProducts },
  crashgate: { name: 'CRASH GATE', url: 'https://crashgate.jp', items: crashgateProducts },
  receno: { name: 'Re:CENO', url: 'https://www.receno.com', items: recenoProducts },
  lowya: { name: 'LOWYA', url: 'https://www.low-ya.com', items: lowyaProducts },
  kanademono: { name: 'KANADEMONO', url: 'https://kanademono.design', items: kanedemonoProducts },
};

// ブロックを生成
const generatedBlocks = {};
for (const [brandId, config] of Object.entries(configs)) {
  generatedBlocks[brandId] = config.items.map(item => makeBlock(item, brandId, config.name, config.url));
  console.log(`Generated ${config.items.length} blocks for ${brandId}`);
}

// 全ブロック数
const totalGenerated = Object.values(generatedBlocks).reduce((sum, b) => sum + b.length, 0);
console.log('Total generated furniture blocks:', totalGenerated);

// ──────────────────────────────────────────────────────
// mockData.tsに追加挿入
// ──────────────────────────────────────────────────────
const fs_module = require('fs');
let content = fs_module.readFileSync('src/data/mockData.ts', 'utf8');

// エスケープ対応パーサー
function extractObjectBlocksFromContent(text) {
  const blocks = [];
  let depth = 0, inStr = false, strCh = '', objStart = -1, i = 0;
  while (i < text.length) {
    const ch = text[i];
    if (inStr) {
      if (ch === '\\') { i += 2; continue; }
      if (ch === strCh) inStr = false;
      i++; continue;
    }
    if (ch === '"' || ch === "'") { inStr = true; strCh = ch; i++; continue; }
    if (ch === '{') { if (depth === 0) objStart = i; depth++; }
    else if (ch === '}') { depth--; if (depth === 0 && objStart >= 0) { blocks.push(text.substring(objStart, i+1)); objStart = -1; } }
    i++;
  }
  return blocks;
}

function extractField(block, field) {
  const re = new RegExp(`${field}:\\s*'([^']*)'`);
  const m = block.match(re);
  return m ? m[1] : '';
}

// PRODUCTS配列の境界を特定
const prodMarker = 'export const PRODUCTS: Product[] = [';
const prodMarkerIdx = content.indexOf(prodMarker);
const prodArrayStartIdx = prodMarkerIdx + prodMarker.length - 1;
let depth = 0, inStr = false, strCh = '', prodArrayEndIdx = -1, pi = prodArrayStartIdx;
while (pi < content.length) {
  const ch = content[pi];
  if (inStr) { if (ch === '\\') { pi += 2; continue; } if (ch === strCh) inStr = false; pi++; continue; }
  if (ch === '"' || ch === "'") { inStr = true; strCh = ch; pi++; continue; }
  if (ch === '[') depth++;
  else if (ch === ']') { depth--; if (depth === 0) { prodArrayEndIdx = pi; break; } }
  pi++;
}

const headerSection = content.substring(0, prodMarkerIdx);
const footerSection = content.substring(prodArrayEndIdx + 1);
const productsInner = content.substring(prodArrayStartIdx + 1, prodArrayEndIdx);

// 既存のブロックを取得（既存IDを保持）
const existingBlocks = extractObjectBlocksFromContent(productsInner);
const existingIds = new Set(existingBlocks.map(b => extractField(b, 'id')));
console.log('\nExisting products before update:', existingBlocks.length);

// 既存の各ブランドのブロックを除外し、新しく生成したブロックと置き換え
// まず既存の非対象ブランドのブロックを保持
const targetBrands = new Set(Object.keys(configs));
const keepBlocks = existingBlocks.filter(b => !targetBrands.has(extractField(b, 'partnerBrandId')));
console.log('Blocks to keep (non-target brands):', keepBlocks.length);

// 新しいブロックを追加（重複を避ける）
const allNewBlocks = [...keepBlocks];
const newIds = new Set(keepBlocks.map(b => extractField(b, 'id')));

for (const [brandId, blocks] of Object.entries(generatedBlocks)) {
  for (const block of blocks) {
    const id = extractField(block, 'id');
    if (!newIds.has(id)) {
      allNewBlocks.push(block);
      newIds.add(id);
    }
  }
}

console.log('After adding new furniture blocks:', allNewBlocks.length);

// カテゴリ分布確認
const catDist = {};
const brandDist = {};
const priceDist = {};
for (const b of allNewBlocks) {
  const cat = extractField(b, 'category');
  const brand = extractField(b, 'partnerBrandId');
  const price = extractField(b, 'priceRangeId');
  catDist[cat] = (catDist[cat]||0)+1;
  brandDist[brand] = (brandDist[brand]||0)+1;
  priceDist[price] = (priceDist[price]||0)+1;
}
console.log('\n=== Distribution after furniture expansion ===');
console.log('Categories:', catDist);
console.log('Brands:', brandDist);
console.log('Price ranges:', priceDist);
console.log('Total:', allNewBlocks.length);

// ファイルに書き込み
const newContent = headerSection + prodMarker + '\n' + allNewBlocks.join(',\n') + '\n]' + footerSection;
const count = (newContent.match(/partnerBrandId:/g)||[]).length;
console.log('\nProducts in new file:', count);
fs_module.writeFileSync('src/data/mockData.ts', newContent);
console.log('✓ mockData.ts updated');
