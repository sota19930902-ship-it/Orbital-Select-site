/**
 * Air Rhizome等の商品名正規化による厳密重複検出・排除スクリプト
 */

const fs = require('fs');
const path = require('path');

const mockDataPath = path.join(__dirname, '../src/data/mockData.ts');
let content = fs.readFileSync(mockDataPath, 'utf8');

function extractObjectBlocks(text) {
  const blocks = [];
  let depth = 0, inStr = false, strCh = '', objStart = -1, i = 0;
  while (i < text.length) {
    const ch = text[i];
    if (inStr) {
      if (ch === '\\') { i += 2; continue; }
      if (ch === strCh) inStr = false;
      i++; continue;
    }
    if (ch === '"' || ch === "'") { inStr = true; strCh = ch; i++; continue; }
    if (ch === '{') { if (depth === 0) objStart = i; depth++; }
    else if (ch === '}') { depth--; if (depth === 0 && objStart >= 0) { blocks.push(text.substring(objStart, i+1)); objStart = -1; } }
    i++;
  }
  return blocks;
}

function extractField(block, field) {
  const re = new RegExp(`${field}:\\s*'([^']*)'`);
  const m = block.match(re);
  return m ? m[1] : '';
}

const prodMarker = 'export const PRODUCTS: Product[] = [';
const prodMarkerIdx = content.indexOf(prodMarker);
const prodArrayStartIdx = prodMarkerIdx + prodMarker.length - 1;

let depth = 0, inStr = false, strCh = '', prodArrayEndIdx = -1, pi = prodArrayStartIdx;
while (pi < content.length) {
  const ch = content[pi];
  if (inStr) { if (ch === '\\') { pi += 2; continue; } if (ch === strCh) inStr = false; pi++; continue; }
  if (ch === '"' || ch === "'") { inStr = true; strCh = ch; pi++; continue; }
  if (ch === '[' ) depth++;
  else if (ch === ']') { depth--; if (depth === 0) { prodArrayEndIdx = pi; break; } }
  pi++;
}

const headerSection = content.substring(0, prodMarkerIdx);
const footerSection = content.substring(prodArrayEndIdx + 1);
const productsInner = content.substring(prodArrayStartIdx + 1, prodArrayEndIdx);

const allBlocks = extractObjectBlocks(productsInner);

function normalizeName(name) {
  return name.toLowerCase()
    .replace(/air\s*rhizome|エアリゾーム/gi, '')
    .replace(/[【】\s\-\/]/g, '')
    .trim();
}

const seenKeys = new Map();
const finalBlocks = [];
let dupCount = 0;

for (const block of allBlocks) {
  const id = extractField(block, 'id');
  const name = extractField(block, 'name');
  const normKey = normalizeName(name);
  
  if (seenKeys.has(normKey)) {
    dupCount++;
    console.log(`Removed duplicate item: ${id} (${name}) -> matches existing ${seenKeys.get(normKey)}`);
    continue;
  }
  
  seenKeys.set(normKey, id);
  finalBlocks.push(block);
}

console.log(`\nStrict deduplication finished. Total removed: ${dupCount}`);
console.log(`Final total products: ${finalBlocks.length}`);

const newContent = headerSection + prodMarker + '\n' + finalBlocks.join(',\n') + '\n]' + footerSection;
fs.writeFileSync(mockDataPath, newContent);
console.log('✓ mockData.ts updated');
