const fs = require('fs');

let content = fs.readFileSync('src/data/mockData.ts', 'utf8');

const productBlocks = [];
const blockRegex = /\{\s*id:\s*['"]([^'"]+)['"][\s\S]*?\n  \},?/g;

let match;
let totalProducts = 0;
let productsWithMultiAngle = 0;
let mismatchesFound = 0;

while ((match = blockRegex.exec(content)) !== null) {
  totalProducts++;
  const fullBlock = match[0];
  const id = match[1];
  const nameMatch = fullBlock.match(/name:\s*['"]([^'"]+)['"]/);
  const imgMatch = fullBlock.match(/images:\s*\[([\s\S]*?)\]/);

  const name = nameMatch ? nameMatch[1] : '';
  const images = imgMatch ? imgMatch[1].split(',').map(s => s.trim().replace(/['"]/g, '')).filter(Boolean) : [];

  if (images.length >= 2) {
    productsWithMultiAngle++;
  }

  const primaryImg = images[0] || '';
  if (primaryImg.includes('felt') || primaryImg.includes('DCFT') || primaryImg.includes('loader')) {
    mismatchesFound++;
    console.log(`Mismatch found in [${id}] ${name}: ${primaryImg}`);
  }
}

console.log(`\n=== PRODUCT IMAGE AUDIT REPORT ===`);
console.log(`Total registered products: ${totalProducts}`);
console.log(`Products with Multi-Angle HD Images (2+ images): ${productsWithMultiAngle} (${((productsWithMultiAngle / totalProducts) * 100).toFixed(1)}%)`);
console.log(`Mismatches / Accessory Image Errors Found: ${mismatchesFound}`);
