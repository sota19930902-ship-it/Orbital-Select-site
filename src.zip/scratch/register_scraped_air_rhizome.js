const fs = require('fs');

const items = JSON.parse(
  fs.readFileSync('scratch/air_rhizome_scraped_data.json', 'utf8')
);

let content = fs.readFileSync('src/data/mockData.ts', 'utf8');

// 1. Re-add Air Rhizome brand object to BRANDS array
const airRhizomeBrand = `  {
    id: 'air_rhizome',
    name: 'Air Rhizome Interior',
    logo: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80',
    description: '北欧ナチュラル＆アクセシブルな高コスパ家具。洗練されたデザインと快適な暮らしを提案。',
    affiliateUrl: 'https://www.air-r.jp/?utm_source=orbital_select&utm_medium=affiliate',
    category: ['sofa', 'table', 'chair', 'storage', 'lighting'],
    origin: 'Japan / Nordic Design',
    priceRange: '¥3,000 〜 ¥60,000',
    features: ['北欧ナチュラル', '高コストパフォーマンス', '豊富なカラーバリエーション', '組み立て簡単'],
    bannerUrl: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=1200&q=90',
  },`;

if (!content.includes("id: 'air_rhizome'")) {
  const brandStartPos = content.indexOf('export const BRANDS: PartnerBrand[] = [');
  const brandEndPos = content.indexOf('];', brandStartPos);
  content = content.slice(0, brandEndPos) + airRhizomeBrand + '\n' + content.slice(brandEndPos);
}

// 2. Append 30 scraped Air Rhizome products to PRODUCTS array
const orbitPos = content.indexOf('export const ORBIT_COLLECTIONS');
const productStartPos = content.indexOf('export const PRODUCTS: Product[] = [');

let productSection = content.slice(productStartPos, orbitPos);
const productEndArrayPos = productSection.lastIndexOf('];');

const newProductCodeBlocks = items.map((item, index) => {
  let subtitle = `エアリゾーム公式通販で人気の${item.subCatName}`;
  if (item.category === 'sofa') subtitle = '北欧ナチュラルの柔らかな座り心地。心地よいリビングを創る人気ソファ';
  else if (item.category === 'chair') subtitle = '暮らしに寄り添う快適デザイン。高コスパな大人気チェア';
  else if (item.category === 'storage') subtitle = '空間をすっきり見せる収納美。北欧モダンの洗練ラック';
  else if (item.category === 'lighting') subtitle = 'お部屋の雰囲気を一変させる温もりの北欧デザイナーズライティング';

  return `  {
    id: '${item.id}',
    name: '${item.name.replace(/'/g, "\\'")}',
    subtitle: '${subtitle}',
    brand: 'Air Rhizome Interior',
    partnerBrandId: 'air_rhizome',
    category: '${item.category}',
    taste: '${index % 2 === 0 ? 'nordic' : 'minimal'}',
    room: '${item.room}',
    price: ${item.price},
    priceRangeId: '${item.priceRangeId}',
    rating: ${(4.84 + (index % 15) * 0.01).toFixed(2)},
    reviewCount: ${28 + index * 4},
    images: ['${item.images[0]}'],
    description: '${item.description.replace(/'/g, "\\'").replace(/\n/g, ' ')}',
    materials: ['天然木（アッシュ / パイン / オーク） / スチール / 高耐久ファブリック'],
    dimensions: 'W450〜1800 × D450〜900 × H400〜850 mm',
    color: 'ナチュラル / ブラウン / ホワイト / グレー',
    sizeCategory: '${item.subCatName}',
    tags: ['エアリゾーム', 'Air Rhizome', '北欧家具', '${item.subCatName}'],
    editorialComment: 'エアリゾームならではの高いコストパフォーマンスと洗練された北欧ナチュラルデザイン。',
    pros: ['北欧ナチュラルの高いデザイン性', '圧倒的なコストパフォーマンス'],
    cons: ['注文集中時は発送状況の確認を推奨'],
    targetUser: '手頃な価格で北欧風の洗練されたお部屋を手軽にコーディネートしたい方',
    shopLinks: [
      {
        name: 'Air Rhizome 公式ストア',
        label: 'Air Rhizome公式オンラインショップで見る',
        price: ${item.price},
        url: '${item.affiliateUrl}',
        isOfficial: true,
      },
    ],
  },`;
}).join('\n');

const cleanedProductSection = productSection.slice(0, productEndArrayPos) +
  `\n  // Air Rhizome Scraped Category Products (30 Items)\n` +
  newProductCodeBlocks +
  `\n];\n\n`;

const finalContent = content.slice(0, productStartPos) + cleanedProductSection + content.slice(orbitPos);

fs.writeFileSync('src/data/mockData.ts', finalContent);
console.log(`Successfully registered Air Rhizome brand & ${items.length} scraped products into mockData.ts!`);
