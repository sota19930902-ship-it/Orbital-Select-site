const https = require('https');

function fetchHtml(urlStr) {
  return new Promise((resolve) => {
    const options = {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'ja,en-US;q=0.9,en;q=0.8'
      }
    };
    https.get(urlStr, options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(data));
    }).on('error', () => resolve(''));
  });
}

async function main() {
  const html = await fetchHtml('https://www.air-r.jp/products/detail.php?product_id=6220');
  
  // Find price
  const priceMatches = html.match(/class="[^"]*price[^"]*"[\s\S]*?([\d,]+)\s*円/i) || 
                       html.match(/([\d,]+)\s*円\s*\(税込\)/i) || 
                       html.match(/円\s*\(税込\s*([\d,]+)\s*円\)/i) ||
                       html.match(/¥\s*([\d,]+)/) ||
                       html.match(/([\d,]+)\s*円/);

  console.log('Price match:', priceMatches ? priceMatches[0] : 'NONE');

  // Find all save_image URLs for multi-angle HD images
  const imgs = html.match(/\/upload\/save_image\/[^\s"'<>\)]+/gi) || [];
  const fullImgs = Array.from(new Set(imgs)).map(path => path.startsWith('http') ? path : 'https://www.air-r.jp' + path);
  console.log('Found save_images count:', fullImgs.length);
  console.log('Top 4 save_images:', fullImgs.slice(0, 4));
}

main();
