const fs = require('fs');
let c = fs.readFileSync('src/data/mockData.ts', 'utf8');

// Fix the broken "export\n\nst ORBIT_COLLECTIONS" -> "export const ORBIT_COLLECTIONS"
c = c.split('export\n\nst ORBIT_COLLECTIONS').join('export const ORBIT_COLLECTIONS');
c = c.split('export\nst ORBIT_COLLECTIONS').join('export const ORBIT_COLLECTIONS');
c = c.split('exportst ORBIT_COLLECTIONS').join('export const ORBIT_COLLECTIONS');

// Also fix any other broken "export\n\nst" patterns
c = c.split('export\n\nst ').join('export const ');
c = c.split('export\nst ').join('export const ');

fs.writeFileSync('src/data/mockData.ts', c);

// Verify
const orbitPos = c.indexOf('export const ORBIT_COLLECTIONS');
console.log('ORBIT_COLLECTIONS:', orbitPos > 0 ? 'FOUND at ' + orbitPos : 'NOT FOUND');
const lvCount = (c.match(/partnerBrandId: 'lavita'/g)||[]).length;
console.log('La Vita products:', lvCount);
