const fs = require('fs');

const items = JSON.parse(fs.readFileSync('scratch/lavita_final.json', 'utf8'));

// Generate TypeScript product entries WITHOUT using fix_mockdata_newlines.js
// All strings are already single-line and properly escaped here

function escStr(s) {
  return String(s)
    .replace(/\\/g, '\\\\')
    .replace(/'/g, "\\'")
    .replace(/\r?\n/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

const taste = ['nordic', 'hotel', 'minimal', 'vintage'];

const blocks = items.map((item, index) => {
  const t = taste[index % taste.length];
  const r = item.category === 'chair' ? 'dining' : 'living';
  const rating = (4.85 + (index % 15) * 0.01).toFixed(2);
  const reviewCount = 20 + (index % 50);

  const name = escStr(`La Vita ${item.title}`);
  const subtitle = escStr(item.subtitle);
  const desc = escStr(item.description);

  const imagesStr = item.images.map(img => `'${escStr(img)}'`).join(', ');

  return `  {
    id: '${item.id}',
    name: '${name}',
    subtitle: '${subtitle}',
    brand: 'La Vita',
    partnerBrandId: 'lavita',
    category: '${item.category}',
    taste: '${t}',
    room: '${r}',
    price: ${item.price},
    priceRangeId: '${item.priceRangeId}',
    rating: ${rating},
    reviewCount: ${reviewCount},
    images: [${imagesStr}],
    description: '${desc}',
    materials: ['アルミ塗装仕上げ / 手吹きガラス / 天然木'],
    dimensions: 'W150~600 x D150~600 x H250~1800 mm',
    color: 'ブラック / ホワイト / ナチュラル',
    sizeCategory: '名作デザイナーズ照明',
    tags: ['La Vita', 'ラヴィータ', '名作照明', 'デザイナーズ照明'],
    editorialComment: 'La Vita（ラヴィータ）が贈る至高の光演出。本物の名作照明が暮らしに豊かさをもたらす。',
    pros: ['世界的名作デザイナーズ照明', 'グレアフリーな優しい光演出'],
    cons: ['注文集中時は納期確認を推奨'],
    targetUser: '本物の名作ライティングと洗練された空間を追求する方',
    shopLinks: [
      {
        name: 'La Vita 公式ストア',
        label: 'La Vita公式オンラインショップで見る',
        price: ${item.price},
        url: '${escStr(item.affiliateUrl)}',
        isOfficial: true,
      },
    ],
  }`;
});

fs.writeFileSync('scratch/lavita_product_blocks.ts', blocks.join(',\n'));
console.log(`Generated ${blocks.length} product blocks`);
