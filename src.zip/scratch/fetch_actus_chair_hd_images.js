const fs = require('fs');
const https = require('https');

function fetchHtml(urlStr) {
  return new Promise((resolve) => {
    const options = {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'ja,en-US;q=0.9,en;q=0.8'
      }
    };
    https.get(urlStr, options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(data));
    }).on('error', () => resolve(''));
  });
}

async function main() {
  console.log('Fetching ACTUS Chair listing page...');
  const html = await fetchHtml('https://online.actus-interior.com/itemlist/furniture/chair/');
  
  // Find all chair item links
  const itemLinks = [];
  const linkRegex = /<a[^>]+href="([^"]*\/item\/(\d+)\/?)"[^>]*>([\s\S]*?)<\/a>/gi;
  let match;
  const seen = new Set();

  while ((match = linkRegex.exec(html)) !== null) {
    const url = match[1].startsWith('http') ? match[1] : 'https://online.actus-interior.com' + match[1];
    const id = match[2];
    if (seen.has(id)) continue;
    seen.add(id);

    const titleMatch = match[3].match(/alt="([^"]+)"/i) || match[3].match(/title="([^"]+)"/i);
    let title = titleMatch ? titleMatch[1] : '';
    if (title && !title.includes('カート') && !title.includes('お気に入り')) {
      itemLinks.push({ id, url, title });
    }
  }

  console.log(`Found ${itemLinks.length} ACTUS chair items.`);

  const chairHDMap = {};

  for (const item of itemLinks.slice(0, 10)) {
    console.log(`Fetching detail for chair [${item.id}] ${item.title.slice(0, 30)}...`);
    const detailHtml = await fetchHtml(item.url);
    
    // Find all images on the page
    const imgs = detailHtml.match(/\/contents\/images\/goods\/[^\s"'<>]+/gi) || [];
    const mainImgs = imgs.filter(img => img.includes('_main') || img.includes('_01') || img.includes('/L/'));
    
    let bestImg = mainImgs.length > 0 ? mainImgs[0] : (imgs.length > 0 ? imgs[0] : '');
    if (bestImg) {
      if (bestImg.startsWith('//')) bestImg = 'https:' + bestImg;
      else if (!bestImg.startsWith('http')) bestImg = 'https://online.actus-interior.com' + bestImg;
      bestImg = bestImg.replace(/\/detail\/S\//, '/detail/L/');
      chairHDMap[item.id] = { title: item.title, url: item.url, img: bestImg };
      console.log(`   Best HD Img: ${bestImg}`);
    }
  }

  fs.writeFileSync('scratch/actus_chairs_hd.json', JSON.stringify(chairHDMap, null, 2));
}

main();
