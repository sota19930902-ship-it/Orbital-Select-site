const fs = require('fs');

let content = fs.readFileSync('src/data/mockData.ts', 'utf8');

// 1. Delete all Air Rhizome products (ar-...)
const productRegex = /\{\s*id:\s*['"]ar-[^'"]+['"][\s\S]*?\n  \},?/g;
content = content.replace(productRegex, '');

// 2. Delete Air Rhizome brand from BRANDS array
const brandRegex = /\{\s*id:\s*['"]air_rhizome['"][\s\S]*?\n  \},?/g;
content = content.replace(brandRegex, '');

// 3. Delete brand comparison with Air Rhizome (masterwal-vs-air-rhizome)
const comparisonRegex = /\{\s*id:\s*['"]masterwal-vs-air-rhizome['"][\s\S]*?\n  \},?/g;
content = content.replace(comparisonRegex, '');

fs.writeFileSync('src/data/mockData.ts', content);
console.log('Successfully purged Air Rhizome products, brand entry, and comparisons from mockData.ts!');
