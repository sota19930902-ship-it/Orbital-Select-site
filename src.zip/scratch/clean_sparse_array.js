/**
 * mockData.tsのPRODUCTS配列からスパースエントリ（undefinedエントリ）を除去
 * 空白行や余分なコンマを整理する
 */

const fs = require('fs');
let c = fs.readFileSync('src/data/mockData.ts', 'utf8');

const startMarker = 'export const PRODUCTS: Product[] = [';
const startIdx = c.indexOf(startMarker);
if (startIdx < 0) { console.error('PRODUCTS not found'); process.exit(1); }

// Find the end of the PRODUCTS array
let depth = 0;
let endIdx = -1;
let inStr = false;
let strCh = '';

const searchFrom = startIdx + startMarker.length - 1; // position of '['
for (let i = searchFrom; i < c.length; i++) {
  const ch = c[i];
  if (inStr) {
    if (ch === strCh && c[i-1] !== '\\') inStr = false;
    continue;
  }
  if (ch === '"' || ch === "'") { inStr = true; strCh = ch; continue; }
  if (ch === '[') depth++;
  else if (ch === ']') {
    depth--;
    if (depth === 0) { endIdx = i; break; }
  }
}

console.log('Array starts at:', searchFrom, 'ends at:', endIdx);

const before = c.substring(0, startIdx);
const arrayContent = c.substring(searchFrom, endIdx + 1); // includes [ and ]
const after = c.substring(endIdx + 1);

// The issue is that the array has lines like "  " between items, which in JS/TS doesn't
// cause undefined, but TypeScript might be inferring it differently.
// Let's actually rebuild the array content cleanly.

// Extract inner content (between [ and ])
const innerContent = arrayContent.substring(1, arrayContent.length - 1);

// Find all product objects at depth 0
const products = [];
let d = 0;
let inS = false;
let sCh = '';
let objStart = -1;

for (let i = 0; i < innerContent.length; i++) {
  const ch = innerContent[i];
  if (inS) {
    if (ch === sCh && innerContent[i-1] !== '\\') inS = false;
    continue;
  }
  if (ch === '"' || ch === "'") { inS = true; sCh = ch; continue; }
  if (ch === '{') {
    if (d === 0) objStart = i;
    d++;
  } else if (ch === '}') {
    d--;
    if (d === 0 && objStart >= 0) {
      products.push(innerContent.substring(objStart, i + 1));
      objStart = -1;
    }
  }
}

console.log('Extracted', products.length, 'product objects');

// Rebuild cleanly
const cleanArray = '[\n' + products.map(p => '  ' + p).join(',\n') + '\n]';
const newContent = before + startMarker.replace(' = [', ' = ') + cleanArray + after;

console.log('Product count in new file:', (newContent.match(/partnerBrandId:/g) || []).length);

// Verify no sparse patterns
const sparseCheck = (newContent.match(/,\s*,/g) || []).length;
console.log('Sparse patterns:', sparseCheck);

fs.writeFileSync('src/data/mockData.ts', newContent);
console.log('✓ mockData.ts cleaned and written');
