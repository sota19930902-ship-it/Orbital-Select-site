const fs = require('fs');

let content = fs.readFileSync('src/data/mockData.ts', 'utf8');

const productBlocks = [];
const blockRegex = /\{\s*id:\s*['"]([^'"]+)['"][\s\S]*?\n  \},?/g;

let match;
let updatedCount = 0;

const fallbackMultiAngleSets = {
  sofa: [
    'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1200&q=90',
    'https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?auto=format&fit=crop&w=1200&q=90',
    'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=1200&q=90'
  ],
  table: [
    'https://images.unsplash.com/photo-1615066390971-03e4e1c36ddf?auto=format&fit=crop&w=1200&q=90',
    'https://images.unsplash.com/photo-1530018607912-eff2daa1bac4?auto=format&fit=crop&w=1200&q=90',
    'https://images.unsplash.com/photo-1604578762246-41134e37f9cc?auto=format&fit=crop&w=1200&q=90'
  ],
  chair: [
    'https://images.unsplash.com/photo-1580481072645-022f9a6d83d0?auto=format&fit=crop&w=1200&q=90',
    'https://images.unsplash.com/photo-1503602642458-232111445657?auto=format&fit=crop&w=1200&q=90',
    'https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?auto=format&fit=crop&w=1200&q=90'
  ],
  lighting: [
    'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=1200&q=90',
    'https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?auto=format&fit=crop&w=1200&q=90',
    'https://images.unsplash.com/photo-1524484485831-a92ffc0de03f?auto=format&fit=crop&w=1200&q=90'
  ],
  storage: [
    'https://images.unsplash.com/photo-1595428774223-ef52624120d2?auto=format&fit=crop&w=1200&q=90',
    'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1200&q=90',
    'https://images.unsplash.com/photo-1533090161767-e6ffed986c88?auto=format&fit=crop&w=1200&q=90'
  ],
  desk: [
    'https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?auto=format&fit=crop&w=1200&q=90',
    'https://images.unsplash.com/photo-1533090161767-e6ffed986c88?auto=format&fit=crop&w=1200&q=90',
    'https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?auto=format&fit=crop&w=1200&q=90'
  ]
};

while ((match = blockRegex.exec(content)) !== null) {
  const fullBlock = match[0];
  const id = match[1];
  const catMatch = fullBlock.match(/category:\s*['"]([^'"]+)['"]/);
  const imgMatch = fullBlock.match(/images:\s*\[([\s\S]*?)\]/);

  const cat = catMatch ? catMatch[1] : 'sofa';
  const existingImages = imgMatch ? imgMatch[1].split(',').map(s => s.trim().replace(/['"]/g, '')).filter(Boolean) : [];

  if (existingImages.length < 4) {
    const fallbackSet = fallbackMultiAngleSets[cat] || fallbackMultiAngleSets.sofa;
    const needed = 4 - existingImages.length;
    const additional = fallbackSet.slice(0, needed);
    const finalImages = [...existingImages, ...additional];

    const newImagesArrayStr = `images: [\n      ${finalImages.map(img => `'${img}'`).join(',\n      ')}\n    ],`;
    content = content.replace(fullBlock, fullBlock.replace(/images:\s*\[[\s\S]*?\]\s*,?/, newImagesArrayStr));
    updatedCount++;
  }
}

fs.writeFileSync('src/data/mockData.ts', content);
console.log(`Enriched ${updatedCount} products with 4 Multi-Angle Full HD images!`);
