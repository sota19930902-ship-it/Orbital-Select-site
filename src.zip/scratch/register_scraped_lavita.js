const fs = require('fs');

const items = JSON.parse(
  fs.readFileSync('scratch/lavita_scraped_data.json', 'utf8')
).filter(item => item.cleanTitle && item.cleanTitle.length > 2);

let content = fs.readFileSync('src/data/mockData.ts', 'utf8');

// Append scraped La Vita products to PRODUCTS array
const orbitPos = content.indexOf('export const ORBIT_COLLECTIONS');
const productStartPos = content.indexOf('export const PRODUCTS: Product[] = [');

let productSection = content.slice(productStartPos, orbitPos);
const productEndArrayPos = productSection.lastIndexOf('];');

const newProductCodeBlocks = items.map((item, index) => {
  let subtitle = '北欧デンマーク・イタリア名作照明。光と影が織りなす至高のデザイナーズライティング';
  if (item.cleanTitle.includes('FLOS')) subtitle = 'イタリア最高峰FLOS（フロス）。空間の主役となるタイムレスな名作照明';
  else if (item.cleanTitle.includes('ステルトン') || item.cleanTitle.includes('STELTON')) subtitle = '北欧デンマークSTELTON。ポータブルで美しいモダンライティング';
  else if (item.cleanTitle.includes('ヤコブソン') || item.cleanTitle.includes('JAKOBSSON')) subtitle = 'スウェーデンの巨匠ヤコブソン。パイン無垢材から漏れる温もりの光';

  return `  {
    id: '${item.id}',
    name: '${item.name.replace(/'/g, "\\'")}',
    subtitle: '${subtitle}',
    brand: 'La Vita',
    partnerBrandId: 'lavita',
    category: '${item.category}',
    taste: '${index % 2 === 0 ? 'hotel' : 'nordic'}',
    room: '${item.room}',
    price: ${item.price},
    priceRangeId: '${item.priceRangeId}',
    rating: ${(4.90 + (index % 10) * 0.01).toFixed(2)},
    reviewCount: ${35 + index * 5},
    images: [\n      ${item.images.map(img => `'${img}'`).join(',\n      ')}\n    ],
    description: '${item.description.replace(/'/g, "\\'").replace(/\n/g, ' ')}',
    materials: ['最高級アッシュ無垢材 / アルミ塗装仕上げ / 手吹き吹付けガラス'],
    dimensions: 'W200〜600 × D200〜600 × H250〜1800 mm',
    color: 'ブラック / サンド / チョコ / ナチュラルパイン',
    sizeCategory: '${item.subCatName}',
    tags: ['La Vita', 'ラヴィータ', '名作照明', 'デザイナーズ照明'],
    editorialComment: 'La Vita（ラヴィータ）が贈る至高の光演出。空間の表情を一瞬で変える本物の名作美。',
    pros: ['世界的名作デザイナーズ照明', 'グレアフリーな優しい光演出', '一生モノの資産価値'],
    cons: ['注文集中時は納期状況の確認を推奨'],
    targetUser: '本物の名作ライティングと洗練されたホテルライク空間を追求するオーナー',
    shopLinks: [
      {
        name: 'La Vita 公式ストア',
        label: 'La Vita公式オンラインショップで見る',
        price: ${item.price},
        url: '${item.affiliateUrl}',
        isOfficial: true,
      },
    ],
  },`;
}).join('\n');

const cleanedProductSection = productSection.slice(0, productEndArrayPos) +
  `\n  // La Vita Scraped Best-Selling Products\n` +
  newProductCodeBlocks +
  `\n];\n\n`;

const finalContent = content.slice(0, productStartPos) + cleanedProductSection + content.slice(orbitPos);

fs.writeFileSync('src/data/mockData.ts', finalContent);
console.log(`Successfully registered ${items.length} new La Vita products into mockData.ts!`);
