const fs = require('fs');

let content = fs.readFileSync('src/data/mockData.ts', 'utf8');

// Upgrade ACTUS detail/S/ -> detail/L/
let updatedContent = content
  .replace(/\/contents\/images\/goods\/detail\/S\//g, '/contents/images/goods/detail/L/')
  .replace(/\/img\/goods\/S\//g, '/img/goods/L/')
  .replace(/w=800&q=80/g, 'w=1200&q=90')
  .replace(/w=600&q=80/g, 'w=1200&q=90');

fs.writeFileSync('src/data/mockData.ts', updatedContent);
console.log('Successfully upgraded all ACTUS and MASTERWAL product image URLs to High-Res (Full HD Large)!');
