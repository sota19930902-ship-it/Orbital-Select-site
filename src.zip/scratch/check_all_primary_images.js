const fs = require('fs');
const content = fs.readFileSync('src/data/mockData.ts', 'utf8');

const matches = content.match(/\{\s*id:\s*['"]([^'"]+)['"][\s\S]*?\n  \},?/g) || [];
console.log('Total product blocks:', matches.length);

let issueCount = 0;
matches.forEach(block => {
  const idMatch = block.match(/id:\s*['"]([^'"]+)['"]/);
  const nameMatch = block.match(/name:\s*['"]([^'"]+)['"]/);
  const imgMatch = block.match(/images:\s*\[\s*['"]([^'"]+)['"]/);

  const id = idMatch ? idMatch[1] : '';
  const name = nameMatch ? nameMatch[1] : '';
  const img = imgMatch ? imgMatch[1] : '';

  if (img && (img.includes('2716743') || img.includes('cushion') || img.includes('DCFT') || img.includes('felt'))) {
    issueCount++;
    console.log(`Issue found in [${id}] ${name}: ${img}`);
  }
});

console.log(`Audit complete. Issue count: ${issueCount}`);
