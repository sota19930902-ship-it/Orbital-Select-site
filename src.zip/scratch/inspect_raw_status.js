const { execSync } = require('child_process');
const fs = require('fs');
const https = require('https');

function run(cmd) {
  try {
    return execSync(cmd, { encoding: 'utf8', stdio: 'pipe' });
  } catch (e) {
    return (e.stdout || '') + (e.stderr || '') + (e.message || '');
  }
}

console.log('=== 1. 現在のワーキングディレクトリと、Gitの状態 ===');
console.log('[pwd / Cwd]');
console.log(process.cwd());
console.log('\n[git status]');
console.log(run('git status'));
console.log('\n[git log --oneline -5]');
console.log(run('git log --oneline -5'));

console.log('\n=== 2. 修正が実際にファイルに存在するかの確認 ===');
console.log('[src/data/mockData.ts から category: \'lighting\' の検索 (Top 5)]');
if (fs.existsSync('src/data/mockData.ts')) {
  const mock = fs.readFileSync('src/data/mockData.ts', 'utf8');
  const lines = mock.split('\n');
  let count = 0;
  lines.forEach((line, idx) => {
    if (line.includes("category: 'lighting'") && count < 5) {
      console.log(`Line ${idx + 1}: ${line.trim()}`);
      count++;
    }
  });
} else {
  console.log('src/data/mockData.ts does not exist');
}

console.log('\n[privacy-policy の検索 in src/app]');
function searchDir(dir) {
  if (!fs.existsSync(dir)) return;
  const files = fs.readdirSync(dir);
  for (const f of files) {
    const full = dir + '/' + f;
    if (fs.statSync(full).isDirectory()) searchDir(full);
    else {
      const c = fs.readFileSync(full, 'utf8');
      if (c.includes('privacy-policy')) {
        console.log(`Found in: ${full}`);
      }
    }
  }
}
searchDir('src/app');

console.log('\n[ディレクトリ存在確認]');
console.log('src/app/privacy-policy exists:', fs.existsSync('src/app/privacy-policy'));
console.log('src/app/terms exists:', fs.existsSync('src/app/terms'));
console.log('src/app/disclaimer exists:', fs.existsSync('src/app/disclaimer'));

console.log('\n=== 3. 直近のコミットが実際にリモート（GitHub）にpushされているか ===');
console.log('[git log origin/main -1]');
console.log(run('git log origin/main -1'));
console.log('\n[git status -sb]');
console.log(run('git status -sb'));

console.log('\n=== 4. Vercelの最新デプロイ状況 ===');
console.log('[npx vercel ls]');
console.log(run('npx vercel ls'));
console.log('\n[npx vercel inspect https://orbital-select-site.vercel.app]');
console.log(run('npx vercel inspect https://orbital-select-site.vercel.app'));

console.log('\n=== 5. 本番URLから直接HTMLを取得して該当箇所が含まれているか確認 ===');
https.get('https://orbital-select-site.vercel.app/', (res) => {
  let body = '';
  res.on('data', chunk => body += chunk);
  res.on('end', () => {
    console.log('[privacy-policy in HTML]');
    const matches = body.match(/privacy-policy/g) || [];
    console.log(`Matches count: ${matches.length}`);
    
    console.log('\n[アフィリエイトプレースホルダー in HTML]');
    const phMatches = body.match(/アフィリエイトプレースホルダー/g) || [];
    console.log(`Matches count: ${phMatches.length}`);
    
    console.log('\n[JUKE in HTML]');
    const jukeIdx = body.indexOf('JUKE');
    if (jukeIdx !== -1) {
      console.log('JUKE snippet in HTML:\n', body.substring(jukeIdx - 100, jukeIdx + 200).replace(/\s+/g, ' '));
    } else {
      console.log('JUKE not found in HTML body');
    }
  });
});
