const fs = require('fs');

// lavita_product_blocks.txt の内容を調査
const blocksText = fs.readFileSync('scratch/lavita_product_blocks.txt', 'utf8');
console.log('Total length:', blocksText.length);

// IDの数を確認
const idMatches = blocksText.match(/id:\s*'lv-[^']+'/g);
console.log('lv- IDs found:', idMatches ? idMatches.length : 0);

// 最初のブロックを確認
const firstBlockStart = blocksText.indexOf('{');
const firstBlockEnd = firstBlockStart + 500;
console.log('First block start:', JSON.stringify(blocksText.substring(firstBlockStart, firstBlockEnd)));

// バックスラッシュの問題を確認
const escapeCount = (blocksText.match(/\\'/g) || []).length;
console.log('Escaped single quotes:', escapeCount);

// '{' と '}' の数
const opens = (blocksText.match(/\{/g) || []).length;
const closes = (blocksText.match(/\}/g) || []).length;
console.log('Opens:', opens, 'Closes:', closes, 'Diff:', opens - closes);

// 単純にid:の出現回数を確認
const allIds = (blocksText.match(/\bid:\s*'/g) || []).length;
console.log('All id: occurrences:', allIds);
