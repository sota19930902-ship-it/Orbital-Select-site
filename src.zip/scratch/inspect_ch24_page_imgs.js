const https = require('https');

https.get('https://online.actus-interior.com/item/2716743/', res => {
  let html = '';
  res.on('data', c => html += c);
  res.on('end', () => {
    console.log('HTML len:', html.length);
    const imgs = html.match(/\/contents\/images\/goods\/[^\s"'<>]+/gi);
    console.log('All goods images on 2716743 page:');
    if (imgs) {
      Array.from(new Set(imgs)).forEach(img => {
        let full = 'https://online.actus-interior.com' + img;
        full = full.replace(/\/detail\/S\//, '/detail/L/');
        console.log(' -', full);
      });
    }
  });
});
