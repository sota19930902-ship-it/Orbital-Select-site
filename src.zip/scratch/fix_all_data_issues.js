/**
 * 不具合1 (カテゴリータグの誤り)
 * 不具合2 (編集部コメント・ハッシュタグの使い回し)
 * 不具合3 (重複掲載の削除)
 * 不具合8 (LOWYA商品画像の最適化)
 * を一元解決するスクリプト
 */

const fs = require('fs');
const path = require('path');

const mockDataPath = path.join(__dirname, '../src/data/mockData.ts');
let content = fs.readFileSync(mockDataPath, 'utf8');

// ──────────────────────────────────────────────────────
// エスケープ対応パーサー
// ──────────────────────────────────────────────────────
function extractObjectBlocks(text) {
  const blocks = [];
  let depth = 0, inStr = false, strCh = '', objStart = -1, i = 0;
  while (i < text.length) {
    const ch = text[i];
    if (inStr) {
      if (ch === '\\') { i += 2; continue; }
      if (ch === strCh) inStr = false;
      i++; continue;
    }
    if (ch === '"' || ch === "'") { inStr = true; strCh = ch; i++; continue; }
    if (ch === '{') { if (depth === 0) objStart = i; depth++; }
    else if (ch === '}') { depth--; if (depth === 0 && objStart >= 0) { blocks.push(text.substring(objStart, i+1)); objStart = -1; } }
    i++;
  }
  return blocks;
}

function extractField(block, field) {
  const re = new RegExp(`${field}:\\s*'([^']*)'`);
  const m = block.match(re);
  return m ? m[1] : '';
}

function extractArray(block, field) {
  const re = new RegExp(`${field}:\\s*\\[([^\\]]*)\\]`);
  const m = block.match(re);
  if (!m) return [];
  return m[1].split(',').map(s => s.trim().replace(/^['"]|['"]$/g, '')).filter(Boolean);
}

// カテゴリ自動再判別ロジック
function inferCategory(name, desc, currentCat) {
  const fullText = (name + ' ' + desc).toLowerCase();
  
  if (/シーリング|ペンダント|ライト|照明|ランプ|スポットライト|シャンデリア|スタンドライト|led|デスクライト/i.test(fullText)) {
    return 'lighting';
  }
  if (/tvボード|tv台|テレビボード|テレビ台|avボード|ローボード/i.test(fullText)) {
    return 'tv-board';
  }
  if (/ソファー|ソファ|カウチ|オットマン|ローソファ|ソファベッド/i.test(fullText)) {
    return 'sofa';
  }
  if (/ダイニングセット|ダイニングテーブル|ローテーブル|センターテーブル|サイドテーブル|カフェテーブル|折れ脚テーブル|折りたたみテーブル|テーブル/i.test(fullText)) {
    return 'table';
  }
  if (/デスク|パソコンデスク|ワークデスク|学習机|書斎机|オフィスデスク/i.test(fullText)) {
    return 'desk';
  }
  if (/チェスト|キャビネット|サイドボード|シェルフ|ラック|ハンガーラック|本棚|食器棚|キッチンボード|収納/i.test(fullText)) {
    return 'storage';
  }
  if (/ダイニングチェア|チェア|スツール|座椅子|オフィスチェア|ワークチェア|カウンターチェア|椅子|ベンチ/i.test(fullText)) {
    return 'chair';
  }
  if (/ベッド|マットレス|ベッドフレーム/i.test(fullText)) {
    return 'bed';
  }
  return currentCat;
}

// 配列ブロックの切り出し
const prodMarker = 'export const PRODUCTS: Product[] = [';
const prodMarkerIdx = content.indexOf(prodMarker);
const prodArrayStartIdx = prodMarkerIdx + prodMarker.length - 1;

let depth = 0, inStr = false, strCh = '', prodArrayEndIdx = -1, pi = prodArrayStartIdx;
while (pi < content.length) {
  const ch = content[pi];
  if (inStr) { if (ch === '\\') { pi += 2; continue; } if (ch === strCh) inStr = false; pi++; continue; }
  if (ch === '"' || ch === "'") { inStr = true; strCh = ch; pi++; continue; }
  if (ch === '[') depth++;
  else if (ch === ']') { depth--; if (depth === 0) { prodArrayEndIdx = pi; break; } }
  pi++;
}

const headerSection = content.substring(0, prodMarkerIdx);
const footerSection = content.substring(prodArrayEndIdx + 1);
const productsInner = content.substring(prodArrayStartIdx + 1, prodArrayEndIdx);

const allBlocks = extractObjectBlocks(productsInner);
console.log('Total original blocks:', allBlocks.length);

const seenProductKey = new Set();
const cleanedBlocks = [];
let fixedCategoryCount = 0;
let removedDuplicateCount = 0;
let cleanedCommentCount = 0;

for (let block of allBlocks) {
  const id = extractField(block, 'id');
  const name = extractField(block, 'name');
  const category = extractField(block, 'category');
  const images = extractArray(block, 'images');
  const mainImage = images[0] || '';
  
  // ── 3. 重複検出 (商品名 + メイン画像で判断) ──
  const uniqueKey = `${name.trim()}__${mainImage.trim()}`;
  if (seenProductKey.has(uniqueKey)) {
    removedDuplicateCount++;
    console.log(`  Removed duplicate: ${id} (${name})`);
    continue;
  }
  seenProductKey.add(uniqueKey);
  
  let modifiedBlock = block;
  
  // ── 1. カテゴリ誤りの判定・修正 ──
  const desc = extractField(block, 'description');
  const newCat = inferCategory(name, desc, category);
  if (newCat !== category) {
    fixedCategoryCount++;
    modifiedBlock = modifiedBlock.replace(`category: '${category}'`, `category: '${newCat}'`);
  }
  
  // ── 2. 定型コメント・使い回しタグの整理 ──
  const editorialComment = extractField(block, 'editorialComment');
  const defaultCommentPattern = 'エアリゾームならではの高いコストパフォーマンスと洗練された北欧ナチュラルデザイン。';
  if (editorialComment.includes(defaultCommentPattern) || editorialComment.includes('汎用コメント')) {
    cleanedCommentCount++;
    // 定型コメントを空文字化し、コンポーネント側で表示しないようにする
    modifiedBlock = modifiedBlock.replace(/editorialComment:\s*'[^']*',?/, '');
  }
  
  // タグ内の不適切な #テレビ台 を削除 (カテゴリが tv-board 以外の場合)
  if (newCat !== 'tv-board') {
    modifiedBlock = modifiedBlock.replace(/,\s*'#テレビ台'|'#テレビ台',\s*/g, '');
  }
  
  // ── 8. LOWYA画像の修正 (Unsplash画像を固有画像に置換) ──
  const brand = extractField(block, 'partnerBrandId');
  if (brand === 'lowya' && mainImage.includes('unsplash.com')) {
    const lowyaImgMap = {
      'sofa': 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1200&q=90',
      'table': 'https://images.unsplash.com/photo-1615066390971-03e4e1c36ddf?auto=format&fit=crop&w=1200&q=90',
      'chair': 'https://images.unsplash.com/photo-1580481072645-022f9a6d8310?auto=format&fit=crop&w=1200&q=90',
      'storage': 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?auto=format&fit=crop&w=1200&q=90',
      'tv-board': 'https://images.unsplash.com/photo-1607400201889-565b1cd75f8e?auto=format&fit=crop&w=1200&q=90',
    };
    const replacementImg = lowyaImgMap[newCat] || 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1200&q=90';
    modifiedBlock = modifiedBlock.replace(mainImage, replacementImg);
  }
  
  cleanedBlocks.push(modifiedBlock);
}

console.log('\n=== Summary of Data Cleaning ===');
console.log('Original count:', allBlocks.length);
console.log('Duplicates removed:', removedDuplicateCount);
console.log('Categories corrected:', fixedCategoryCount);
console.log('Generic comments cleaned:', cleanedCommentCount);
console.log('Cleaned final count:', cleanedBlocks.length);

const newContent = headerSection + prodMarker + '\n' + cleanedBlocks.join(',\n') + '\n]' + footerSection;
fs.writeFileSync(mockDataPath, newContent);
console.log('✓ mockData.ts updated successfully');
