const https = require('https');

function fetchHtml(urlStr) {
  return new Promise((resolve) => {
    const options = {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'ja,en-US;q=0.9,en;q=0.8'
      }
    };
    https.get(urlStr, options, (res) => {
      if ((res.statusCode === 301 || res.statusCode === 302) && res.headers.location) {
        let loc = res.headers.location;
        if (!loc.startsWith('http')) {
          loc = 'https://online.actus-interior.com' + (loc.startsWith('/') ? '' : '/') + loc;
        }
        return resolve(fetchHtml(loc));
      }
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(data));
    }).on('error', () => resolve(''));
  });
}

async function main() {
  console.log('Searching ACTUS for Yチェア / CH24...');
  const searchHtml = await fetchHtml('https://online.actus-interior.com/search/?q=CH24');
  
  const imgs = searchHtml.match(/\/contents\/images\/goods\/[^\s"'<>]+/gi) || [];
  console.log('Found goods images on CH24 search page:');
  Array.from(new Set(imgs)).slice(0, 15).forEach(img => {
    let full = 'https://online.actus-interior.com' + img;
    full = full.replace(/\/detail\/S\//, '/detail/L/');
    console.log(' -', full);
  });
}

main();
