const fs = require('fs');

let content = fs.readFileSync('src/data/mockData.ts', 'utf8');

// Replace any line break inside single-quoted strings
content = content.replace(/'([^'\\]*(?:\\.[^'\\]*)*)'/g, (match, inner) => {
  const cleaned = inner.replace(/\r?\n/g, ' ').replace(/\s+/g, ' ');
  return `'${cleaned}'`;
});

fs.writeFileSync('src/data/mockData.ts', content);
console.log('Cleaned all internal string newlines in mockData.ts!');
