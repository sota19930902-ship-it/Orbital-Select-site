const fs = require('fs');

const content = fs.readFileSync('src/data/mockData.ts', 'utf8');

const imageRegex = /https?:\/\/[^\s"'\]\)]+/gi;
const matches = content.match(imageRegex) || [];

const smallUrls = matches.filter(url => 
  url.includes('/S/') || 
  url.includes('small') || 
  url.includes('_S_') ||
  url.includes('_80x80') ||
  url.includes('_200x200') ||
  url.includes('_400x400') ||
  url.includes('w=400') ||
  url.includes('w=600')
);

console.log(`Total image URLs found: ${matches.length}`);
console.log(`Small / Low-Res URLs found: ${smallUrls.length}`);

if (smallUrls.length > 0) {
  console.log('\nSmall URLs list:');
  smallUrls.forEach(url => console.log(' -', url));
}
