/**
 * mockData.tsのPRODUCTS配列を選定した50点のみに絞り込む
 * top50_ids.jsonを読み込んで対象IDのみ残す
 */

const fs = require('fs');

const selectedIds = new Set(JSON.parse(fs.readFileSync('scratch/top50_ids.json', 'utf8')));
console.log('Target IDs:', selectedIds.size);

let content = fs.readFileSync('src/data/mockData.ts', 'utf8');

// Find PRODUCTS array bounds
const startMarker = 'export const PRODUCTS: Product[] = [';
const startIdx = content.indexOf(startMarker);
if (startIdx < 0) {
  console.error('PRODUCTS not found!');
  process.exit(1);
}

const headerBeforeProducts = content.substring(0, startIdx);

// Find all product objects in the array
// Each product starts with "  {" after a newline, and has "id: 'xxx'"
const productsText = content.substring(startIdx + startMarker.length);

// We need to find the end of the PRODUCTS array
// Find matching ] considering nesting
let depth = 0;
let endOfArray = -1;
let inString = false;
let strChar = '';

for (let i = 0; i < productsText.length; i++) {
  const ch = productsText[i];
  if (inString) {
    if (ch === strChar && productsText[i-1] !== '\\') inString = false;
    continue;
  }
  if (ch === '"' || ch === "'") { inString = true; strChar = ch; continue; }
  if (ch === '[' || ch === '{') depth++;
  else if (ch === ']' || ch === '}') {
    depth--;
    if (depth < 0) { endOfArray = i; break; }
  }
}

const afterProducts = productsText.substring(endOfArray); // starts with ']'

// Now extract individual product blocks
// Find all product start positions using the pattern: newline + whitespace + { + newline + id:
const allIdMatches = [...productsText.substring(0, endOfArray).matchAll(/\n(\s*)\{\s*\n?\s*id:\s*'([^']+)'/g)];
console.log('Total products found:', allIdMatches.length);

const productBlocks = [];
const innerText = productsText.substring(0, endOfArray);

for (let pi = 0; pi < allIdMatches.length; pi++) {
  const match = allIdMatches[pi];
  const id = match[2];
  const blockStart = match.index; // position of the \n before {
  
  // Find end: next product start or end of array
  const nextStart = pi < allIdMatches.length - 1 ? allIdMatches[pi+1].index : innerText.length;
  const block = innerText.substring(blockStart, nextStart);
  
  productBlocks.push({ id, block });
}

console.log('Product blocks extracted:', productBlocks.length);

// Filter to selected only
const selectedBlocks = productBlocks.filter(p => selectedIds.has(p.id));
console.log('Selected blocks:', selectedBlocks.length);

// Show which brands are represented
const brandCount = {};
for (const pb of selectedBlocks) {
  const m = pb.block.match(/partnerBrandId:\s*'([^']+)'/);
  if (m) brandCount[m[1]] = (brandCount[m[1]] || 0) + 1;
}
console.log('By brand:', brandCount);

// Rebuild the file
const newProductsContent = selectedBlocks.map(p => p.block).join('');
const newContent = headerBeforeProducts + startMarker + newProductsContent + afterProducts;

console.log('\nOriginal size:', content.length, 'bytes');
console.log('New size:', newContent.length, 'bytes');

// Verify product count in new content
const newCount = (newContent.match(/partnerBrandId:/g) || []).length;
console.log('Products in new file:', newCount);

if (newCount >= 48 && newCount <= 52) {
  fs.writeFileSync('src/data/mockData.ts', newContent);
  console.log('✓ mockData.ts updated with', newCount, 'products');
} else {
  console.error('ERROR: Expected ~50 products, got', newCount, '- aborting');
  process.exit(1);
}
