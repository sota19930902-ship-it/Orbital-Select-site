const fs = require('fs');
const https = require('https');

function fetchUrl(urlStr) {
  return new Promise((resolve) => {
    const options = {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'ja,en-US;q=0.9,en;q=0.8'
      }
    };
    https.get(urlStr, options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(data));
    }).on('error', () => resolve(''));
  });
}

function cleanTitle(title) {
  return title
    .replace(/【正規品】/g, '')
    .replace(/【送料無料】/g, '')
    .replace(/3年保証/g, '')
    .replace(/【[^\]]*】/g, '')
    .replace(/\[正規品\]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function cleanDescription(bodyHtml) {
  if (!bodyHtml) return '';
  return bodyHtml
    .replace(/<[^>]+>/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&nbsp;/g, ' ')
    .replace(/&yen;/g, '¥')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 250);
}

function inferCategory(title) {
  const t = title;
  if (t.match(/チェア|スツール|椅子/)) return 'chair';
  if (t.match(/テーブル|デスク/) && !t.match(/ランプ|ライト|照明/)) return 'table';
  return 'lighting';
}

function inferPriceRange(price) {
  if (price >= 400000) return 'over40';
  if (price >= 200000) return '20to40';
  if (price >= 100000) return '10to20';
  return 'under10';
}

function slugifyId(handle) {
  return 'lv-' + handle.toLowerCase()
    .replace(/[\u3000-\u9fff\uff00-\uffef]/g, '') // strip CJK
    .replace(/[^a-z0-9\-]/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 60);
}

async function main() {
  // Fetch all products via Shopify API — paginate up to page 5 (max 1250 products)
  let page = 1;
  let allProducts = [];

  while (page <= 5) {
    console.log(`Fetching lavita-shop.jp products.json page ${page}...`);
    const jsonStr = await fetchUrl(`https://lavita-shop.jp/products.json?limit=250&page=${page}`);
    if (!jsonStr) break;
    try {
      const parsed = JSON.parse(jsonStr);
      if (!parsed.products || parsed.products.length === 0) break;
      allProducts.push(...parsed.products);
      if (parsed.products.length < 250) break; // last page
      page++;
    } catch (e) {
      break;
    }
  }

  console.log(`Total raw products fetched: ${allProducts.length}`);

  // Filter & transform
  const seenIds = new Set();
  const result = [];

  for (const p of allProducts) {
    // Skip products without images
    if (!p.images || p.images.length === 0) continue;

    const price = p.variants && p.variants[0] ? Math.round(parseFloat(p.variants[0].price)) : 0;
    if (price < 5000) continue; // Skip accessories / freebies

    // Skip obvious non-products
    const rawTitle = p.title || '';
    if (rawTitle.includes('交換用シェード') || rawTitle.includes('カタログ') || rawTitle.includes('パーツのみ')) continue;

    const id = slugifyId(p.handle);
    if (seenIds.has(id)) continue;
    seenIds.add(id);

    const title = cleanTitle(rawTitle);
    if (!title) continue;

    const images = p.images.map(img => img.src).slice(0, 4);
    const description = cleanDescription(p.body_html);
    const category = inferCategory(title);
    const priceRangeId = inferPriceRange(price);

    const productUrl = `https://lavita-shop.jp/products/${p.handle}`;
    const affiliateUrl = `${productUrl}?utm_source=orbital_select&utm_medium=affiliate`;

    // Determine subtleties from brand keywords in title
    let subtitle = '北欧デンマーク・イタリア名作照明。光と影が織りなす至高のデザイナーズライティング';
    if (title.includes('ルイスポールセン') || title.includes('Louis Poulsen')) {
      subtitle = 'ルイスポールセン正規品。PH5などデンマークが誇る不朽の名作ライティング';
    } else if (title.includes('フロス') || title.includes('FLOS')) {
      subtitle = 'イタリア照明の最高峰FLOS。空間の主役となるタイムレスなデザイナーズ照明';
    } else if (title.includes('ステルトン') || title.includes('STELTON')) {
      subtitle = 'デンマークSTELTON。充電式ポータブルで光と佇まいを自由にデザイン';
    } else if (title.includes('アルテミデ') || title.includes('Artemide')) {
      subtitle = 'イタリアArtemide。機能美と芸術が融合した世界的デザイナーズ照明';
    } else if (title.includes('ロッサウ') || title.includes('Rossau')) {
      subtitle = 'TOM ROSSAU。無垢素材の彫刻的光と影の表現が生む北欧デザインの至宝';
    } else if (title.includes('ヤコブソン') || title.includes('Jakobsson')) {
      subtitle = 'ヤコブソン。パイン無垢材から零れる温もりの光が部屋を包む北欧の名作';
    } else if (title.includes('アルコ') || title.includes('ARCO') || title.includes('フロアスタンド') || title.includes('フロア')) {
      subtitle = 'スタンドライトで空間に奥行きを。高い存在感とソフトな光演出';
    } else if (title.includes('ペンダント')) {
      subtitle = '空間にリズムと奥行きを与えるペンダントライト。照明そのものが彫刻となる';
    }

    result.push({
      id,
      title,
      subtitle,
      category,
      priceRangeId,
      price,
      images,
      description,
      productUrl,
      affiliateUrl,
    });
  }

  console.log(`Valid La Vita products after filtering: ${result.length}`);
  fs.writeFileSync('scratch/lavita_final.json', JSON.stringify(result, null, 2));
  console.log('Saved to scratch/lavita_final.json');
}

main();
