const https = require('https');

function fetchUrl(urlStr) {
  return new Promise((resolve) => {
    const options = {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'ja,en-US;q=0.9,en;q=0.8'
      }
    };
    https.get(urlStr, options, (res) => {
      if ((res.statusCode === 301 || res.statusCode === 302) && res.headers.location) {
        let loc = res.headers.location;
        if (!loc.startsWith('http')) {
          loc = 'https://lavita-shop.jp' + (loc.startsWith('/') ? '' : '/') + loc;
        }
        return resolve(fetchUrl(loc));
      }
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(data));
    }).on('error', () => resolve(''));
  });
}

async function main() {
  console.log('Testing Shopify products.json on lavita-shop.jp...');
  const jsonStr = await fetchUrl('https://lavita-shop.jp/products.json?limit=50');
  console.log('JSON len:', jsonStr.length);

  try {
    const parsed = JSON.parse(jsonStr);
    if (parsed && parsed.products) {
      console.log(`Found ${parsed.products.length} products in Shopify products.json API!`);
      parsed.products.slice(0, 5).forEach((p, idx) => {
        console.log(`\nProduct [${idx + 1}]: ${p.title}`);
        console.log('  Handle:', p.handle);
        console.log('  URL:', `https://lavita-shop.jp/products/${p.handle}`);
        console.log('  Price:', p.variants && p.variants[0] ? p.variants[0].price : 'N/A');
        console.log('  Images count:', p.images ? p.images.length : 0);
        console.log('  Primary Image:', p.images && p.images[0] ? p.images[0].src : 'N/A');
        console.log('  Body excerpt:', p.body_html ? p.body_html.replace(/<[^>]+>/g, ' ').slice(0, 100) + '...' : 'N/A');
      });
      return;
    }
  } catch (e) {
    console.log('JSON parse failed or not available:', e.message);
  }

  console.log('\nTesting HTML fallback on lavita-shop.jp/collections/all?sort_by=best-selling...');
  const html = await fetchUrl('https://lavita-shop.jp/collections/all?sort_by=best-selling');
  console.log('HTML len:', html.length);
  const links = html.match(/\/products\/[a-zA-Z0-9_\-]+/g) || [];
  console.log('Unique product links found in HTML:', Array.from(new Set(links)).slice(0, 10));
}

main();
