const fs = require('fs');
const https = require('https');

const categories = [
  { category_id: '10', category: 'sofa', room: 'living', subCatName: 'ソファ' },
  { category_id: '9', category: 'table', room: 'living', subCatName: 'テーブル' },
  { category_id: '95', category: 'chair', room: 'dining', subCatName: 'チェア・スツール' },
  { category_id: '13', category: 'storage', room: 'living', subCatName: 'ラック・収納' },
  { category_id: '7', category: 'storage', room: 'living', subCatName: 'テレビ台' },
  { category_id: '18', category: 'lighting', room: 'living', subCatName: '照明・ライト' }
];

function fetchHtml(urlStr) {
  return new Promise((resolve) => {
    const options = {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'ja,en-US;q=0.9,en;q=0.8'
      }
    };
    https.get(urlStr, options, (res) => {
      if ((res.statusCode === 301 || res.statusCode === 302) && res.headers.location) {
        let loc = res.headers.location;
        if (!loc.startsWith('http')) {
          loc = 'https://www.air-r.jp' + (loc.startsWith('/') ? '' : '/') + loc;
        }
        return resolve(fetchHtml(loc));
      }
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(data));
    }).on('error', () => resolve(''));
  });
}

function cleanTitle(raw) {
  return raw
    .replace(/\|\s*家具・インテリア通販\s*【公式】エアリゾーム.*/gi, '')
    .replace(/【公式】エアリゾーム.*/gi, '')
    .replace(/\s+/g, ' ')
    .trim();
}

async function scrapeItemDetail(productId, categoryInfo) {
  const url = `https://www.air-r.jp/products/detail.php?product_id=${productId}`;
  const html = await fetchHtml(url);
  if (!html) return null;

  const titleMatch = html.match(/<title>([^<]+)<\/title>/i);
  if (!titleMatch) return null;

  const rawTitle = titleMatch[1];
  const cleanedTitle = cleanTitle(rawTitle);

  // Price extraction
  const priceMatch = html.match(/id="price02_default">([\d,]+)/i) || 
                     html.match(/id="price02_dynamic">([\d,]+)/i) ||
                     html.match(/([\d,]+)\s*円\s*\(税込\)/i) ||
                     html.match(/¥\s*([\d,]+)/);

  let numericPrice = 19800;
  if (priceMatch) {
    numericPrice = parseInt(priceMatch[1].replace(/[^\d]/g, ''), 10);
  }

  // Image extraction
  const ogImgMatch = html.match(/property="og:image"\s+content="([^"]+)"/i);
  let mainImg = ogImgMatch ? ogImgMatch[1] : '';

  const saveImgs = html.match(/\/upload\/save_image\/[^\s"'<>\)]+/gi) || [];
  const fullSaveImgs = Array.from(new Set(saveImgs)).map(p => p.startsWith('http') ? p : 'https://www.air-r.jp' + p);

  if (!mainImg && fullSaveImgs.length > 0) {
    mainImg = fullSaveImgs[0];
  }

  if (!mainImg) return null;

  // Multi-angle images
  let images = Array.from(new Set([mainImg, ...fullSaveImgs])).slice(0, 4);

  // Description
  const ogDescMatch = html.match(/property="og:description"\s+content="([^"]+)"/i) || html.match(/name="description"\s+content="([^"]+)"/i);
  let desc = ogDescMatch ? ogDescMatch[1].trim() : `${cleanedTitle}。エアリゾームインテリア公式通販で大人気。`;

  let priceRangeId = 'under10';
  if (numericPrice >= 400000) priceRangeId = 'over40';
  else if (numericPrice >= 200000) priceRangeId = '20to40';
  else if (numericPrice >= 100000) priceRangeId = '10to20';

  return {
    id: `ar-${productId}`,
    name: cleanedTitle.startsWith('Air Rhizome') ? cleanedTitle : `Air Rhizome ${cleanedTitle}`,
    cleanTitle: cleanedTitle,
    category: categoryInfo.category,
    room: categoryInfo.room,
    price: numericPrice,
    priceRangeId,
    images,
    description: desc,
    url: url,
    affiliateUrl: `${url}&utm_source=orbital_select&utm_medium=affiliate`,
    subCatName: categoryInfo.subCatName
  };
}

async function main() {
  const allScrapedItems = [];
  const globalSeenIds = new Set();

  for (const cat of categories) {
    const listUrl = `https://www.air-r.jp/products/list.php?category_id=${cat.category_id}`;
    console.log(`\nFetching Air Rhizome category: ${cat.subCatName} (${listUrl})`);
    const listingHtml = await fetchHtml(listUrl);
    
    const detailMatches = listingHtml.match(/product_id=(\d+)/g) || [];
    const productIds = Array.from(new Set(detailMatches.map(m => m.replace('product_id=', ''))));

    console.log(`Found ${productIds.length} items in category ${cat.subCatName}`);

    let count = 0;
    for (const pId of productIds) {
      if (globalSeenIds.has(pId)) continue;
      globalSeenIds.add(pId);

      console.log(`Fetching detail for Air Rhizome [${pId}]...`);
      const detail = await scrapeItemDetail(pId, cat);
      if (detail && detail.images.length > 0) {
        allScrapedItems.push(detail);
        count++;
        if (count >= 5) break; // Top 5 per category
      }
    }
  }

  console.log(`\nTotal unique Air Rhizome category products scraped: ${allScrapedItems.length}`);
  fs.writeFileSync(
    'scratch/air_rhizome_scraped_data.json',
    JSON.stringify(allScrapedItems, null, 2)
  );
}

main();
