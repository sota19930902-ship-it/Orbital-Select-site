const fs = require('fs');
let c = fs.readFileSync('src/data/mockData.ts','utf8');
const before = (c.match(/room: 'work'/g)||[]).length;
c = c.split("room: 'work'").join("room: 'study'");
fs.writeFileSync('src/data/mockData.ts', c);
console.log('Fixed room:work -> room:study, count:', before);
