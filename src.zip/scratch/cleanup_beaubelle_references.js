const fs = require('fs');

function cleanFile(filePath, replacements) {
  if (!fs.existsSync(filePath)) return;
  let text = fs.readFileSync(filePath, 'utf8');
  replacements.forEach(([from, to]) => {
    text = text.replace(from, to);
  });
  fs.writeFileSync(filePath, text);
}

// 1. SearchSection.tsx
cleanFile('src/components/SearchSection.tsx', [
  [/<option value="beaubelle">BeauBelle（デザイン照明専門店）<\/option>/g, ''],
]);

// 2. TasteSection.tsx
cleanFile('src/components/TasteSection.tsx', [
  [/ACTUS \+ BeauBelle/g, 'ACTUS + La Vita'],
  [/BeauBelle \+ La Vita/g, 'La Vita + FLYMEe'],
]);

// 3. Hero.tsx
cleanFile('src/components/Hero.tsx', [
  [/・BeauBelle/g, ''],
  [/BeauBelle・/g, ''],
]);

// 4. Header.tsx
cleanFile('src/components/Header.tsx', [
  [/\/ BeauBelle /g, ''],
  [/BeauBelle \/ /g, ''],
]);

// 5. Footer.tsx
cleanFile('src/components/Footer.tsx', [
  [/<li><Link href="\/brands\/beaubelle"[^>]*>• BeauBelle \(照明専門店\)<\/Link><\/li>/g, ''],
]);

// 6. src/app/layout.tsx
cleanFile('src/app/layout.tsx', [
  [/、BeauBelle/g, ''],
  [/'BeauBelle',/g, ''],
]);

// 7. src/app/search/page.tsx
cleanFile('src/app/search/page.tsx', [
  [/、BeauBelle/g, ''],
]);

// 8. mockData.ts
cleanFile('src/data/mockData.ts', [
  [/BeauBelle/g, 'La Vita'],
  [/'beaubelle'/g, "'lavita'"],
]);

console.log('Cleaned up all BeauBelle references across components and data files!');
