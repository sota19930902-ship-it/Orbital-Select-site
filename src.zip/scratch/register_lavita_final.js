const fs = require('fs');

const items = JSON.parse(fs.readFileSync('scratch/lavita_final.json', 'utf8'));
let content = fs.readFileSync('src/data/mockData.ts', 'utf8');

// 1. Remove ALL existing lv- products first
const lvBlockRegex = /\{\s*id:\s*['"]lv-[^'"]+['"][\s\S]*?\n  \},?/g;
const beforeCount = (content.match(/id:\s*['"]lv-/g) || []).length;
content = content.replace(lvBlockRegex, '');
console.log(`Removed ${beforeCount} old lv- product entries.`);

// Also remove the La Vita comments
content = content.replace(/\n  \/\/ La Vita Scraped Best-Selling Products\n/g, '\n');

// 2. Determine insert point
const orbitPos = content.indexOf('export const ORBIT_COLLECTIONS');
const productStartPos = content.indexOf('export const PRODUCTS: Product[] = [');
let productSection = content.slice(productStartPos, orbitPos);
const productEndArrayPos = productSection.lastIndexOf('];');

// 3. Build product code blocks for all items
const taste = ['nordic', 'hotel', 'minimal', 'vintage'];
const rooms = ['living', 'bedroom', 'dining', 'work'];

const blocks = items.map((item, index) => {
  const t = taste[index % taste.length];
  const r = item.category === 'chair' ? 'dining' : 'living';
  const rating = (4.85 + (index % 15) * 0.01).toFixed(2);
  const reviewCount = 20 + (index % 50);

  // Safely escape single quotes in all string fields
  const safeName = `La Vita ${item.title}`.replace(/'/g, "\\'").replace(/\n/g, ' ');
  const safeSubtitle = item.subtitle.replace(/'/g, "\\'");
  const safeDesc = item.description.replace(/'/g, "\\'").replace(/\n/g, ' ');
  const safeLabel = `La Vita公式オンラインショップで見る`.replace(/'/g, "\\'");

  const imagesStr = item.images.map(img => `'${img}'`).join(', ');

  return `  {
    id: '${item.id}',
    name: '${safeName}',
    subtitle: '${safeSubtitle}',
    brand: 'La Vita',
    partnerBrandId: 'lavita',
    category: '${item.category}',
    taste: '${t}',
    room: '${r}',
    price: ${item.price},
    priceRangeId: '${item.priceRangeId}',
    rating: ${rating},
    reviewCount: ${reviewCount},
    images: [${imagesStr}],
    description: '${safeDesc}',
    materials: ['アルミ塗装仕上げ / 手吹きガラス / 天然木'],
    dimensions: 'W150~600 x D150~600 x H250~1800 mm',
    color: 'ブラック / ホワイト / ナチュラル',
    sizeCategory: '名作デザイナーズ照明',
    tags: ['La Vita', 'ラヴィータ', '名作照明', 'デザイナーズ照明'],
    editorialComment: 'La Vita（ラヴィータ）が贈る至高の光演出。本物の名作照明が暮らしに豊かさをもたらす。',
    pros: ['世界的名作デザイナーズ照明', 'グレアフリーな優しい光演出'],
    cons: ['注文集中時は納期確認を推奨'],
    targetUser: '本物の名作ライティングと洗練された空間を追求する方',
    shopLinks: [
      {
        name: 'La Vita 公式ストア',
        label: '${safeLabel}',
        price: ${item.price},
        url: '${item.affiliateUrl}',
        isOfficial: true,
      },
    ],
  }`;
});

const newSection = productSection.slice(0, productEndArrayPos) +
  `,\n  // ── La Vita Designer Lighting (${items.length} products)\n` +
  blocks.join(',\n') +
  '\n];\n\n';

const finalContent = content.slice(0, productStartPos) + newSection + content.slice(orbitPos);
fs.writeFileSync('src/data/mockData.ts', finalContent);
console.log(`Registered ${items.length} La Vita products into mockData.ts`);
