const fs = require('fs');

function cleanFile(filePath, replacements) {
  if (!fs.existsSync(filePath)) return;
  let text = fs.readFileSync(filePath, 'utf8');
  replacements.forEach(([from, to]) => {
    text = text.replace(from, to);
  });
  fs.writeFileSync(filePath, text);
}

// 1. mockData.ts
cleanFile('src/data/mockData.ts', [
  [/Air Rhizome Interior/g, 'ACTUS'],
  [/Air Rhizome/g, 'ACTUS'],
]);

// 2. SearchSection.tsx
cleanFile('src/components/SearchSection.tsx', [
  [/<option value="air_rhizome">Air Rhizome Interior（北欧・高コスパ）<\/option>/g, ''],
]);

// 3. TasteSection.tsx
cleanFile('src/components/TasteSection.tsx', [
  [/Air Rhizome \+ BeauBelle/g, 'ACTUS + BeauBelle'],
  [/MASTERWAL \+ Air Rhizome/g, 'MASTERWAL + ACTUS'],
]);

// 4. RankingSection.tsx
cleanFile('src/components/RankingSection.tsx', [
  [/、Air Rhizome/g, ''],
]);

// 5. Hero.tsx
cleanFile('src/components/Hero.tsx', [
  [/・Air Rhizome/g, ''],
]);

// 6. Header.tsx
cleanFile('src/components/Header.tsx', [
  [/\/ Air Rhizome /g, ''],
]);

// 7. Footer.tsx
cleanFile('src/components/Footer.tsx', [
  [/<li><Link href="\/brands\/air_rhizome"[^>]*>• Air Rhizome Interior<\/Link><\/li>/g, ''],
]);

// 8. src/app/layout.tsx
cleanFile('src/app/layout.tsx', [
  [/、Air Rhizome Interior/g, ''],
  [/'Air Rhizome',/g, ''],
]);

// 9. src/app/search/page.tsx
cleanFile('src/app/search/page.tsx', [
  [/、Air Rhizome/g, ''],
]);

// 10. src/app/journal/[id]/page.tsx
cleanFile('src/app/journal/[id]/page.tsx', [
  [/ファミリーダイニングにはAir Rhizome/g, 'ファミリーダイニングにはACTUS'],
]);

console.log('Cleaned up all Air Rhizome references from UI and pages!');
